# Experiment Configuration

## **Section** DEFAULT



## **Section** detector
Key, public detector: boolean. If true use 'det.txt' file(can be edited in 'tools/track.py') in each sub dataset folder, this can save much time when you do not modify behavior of detector. If false use detector to infer images in datasets.


Key, oracle: whether using ground truth for tracking.

Key, config path: relative path to detector's config file with regard to the root path of MO2Tracker

Key, weight path: relative path to detector's weight file with regard to the root path of MO2Tracker

Key, train/test/val ann path. Path to COCO format annotation file(.json)

```json

{
    "images": [
        {
            "id": 0,
            "frame_id": 0,
            "video_id": 0,
            "file_name": "relative/path/to/image/file",
        },
        {
            ...
        },
        ...,
    ],
    "videos": [
        {
            "id": 0,
            "name": "video0",
            "fps": 24.0,
            "width": 1920,
            "height": 1080,
            "seq_dir": "relative/path/to/subdataset"
        },
        {
            ...
        },
        ...,
    ],
    "categories": [
        {
            "id": 0,
            "name": label0,
        },
        {
            ...
        },
        ...,
    ],
    "annotations": [
        {
            "id": 0,
            "image_id": 0,
            "category_id": 0,
            "track_id": 0,
            "bbox": [left, top, width, height],
            "conf": 0.6,
        },
        {
            ...
        },
        ...,
    ]
}
```





## **Section** dataset


Key, format: choices are 'mot' and 'colonoscopy', 'colonoscopy' is a subclass of mot, which should have a 'lifespan.txt' file in root of each sub dataset. 'lifespan.txt' is a 'csv' format file containing to integers, the first number is the beginning frame at which the colonoscopy move into human's body(include), the second number is the ending frame at which the colonoscopy is leaving human's body. 

Key, dataset path: relative path to this dataset with regard to the root path of MO2Tracker

Key, ann path: relative path to annotation file with regard to dataset path

Key, rgb means: average rgb value of pixels of all images in dataset.

Key, rgb std: standard deviation value of pixels of all images in dataset.

## **Section** track

Key, features: features to be considered for data association. Choices are IoU, Conf, ReID, LBPSimilarity. Should be implemented in 'tracker/objectives.py' and imported in 'tools/track.py'

Key, predictor: Motion Predictor. Choices are KalmanFilter, ParticleFilter and ExtendedKalmanFilter.

Key, min_len: eliminate short clips, this is the threshold of 'short clips'

Key, frame_buffer: unmatched tracks are to keep certain frames.

Key, knee: Whether using Knee Oriented strategy.

Key, human inspired: Whether using Human Inspired strategy.

## **Section** features_args
Key, onnx_model_path: relative path to ReID model with regard to the root path of MO2Tracker

Key, input size: image embedding size to be input to ReID model.

Key, pf_coff: False positive threshold of each feature.(ordered)

## **Section** exp
Key, name: experiment name

## **Section** output
Key: path: relative path of the output files, including config file(this one) and track results.

Key, create video: Whether creating tracking video.
