import os.path
from PIL import Image
import numpy as np

from torch.utils.data.dataset import Dataset
from pycocotools.coco import COCO


class ColonDataset(Dataset):
    def __init__(self, data_dir, annotation_file, dataset_type='test', transform=None, public_detector: bool=False):
        self.data_dir = data_dir
        self.ann_dir = annotation_file
        self.dataset_type = dataset_type
        self.public_detector = public_detector
        # self.input_dim =
        self.transform = transform
        abs_ann_path = os.path.abspath(os.path.join(data_dir, annotation_file))
        # abs_ann_path = os.path.join(os.path.dirname(os.path.abspath("")), data_dir, annotation_file)
        self.coco = COCO(annotation_file=abs_ann_path)
        self.img_ids = self.coco.getImgIds()
        self.cls_ids = self.coco.getCatIds()
        self.cls_ids.sort()
        # 1st key: video_id
        # 2nd key: frame_id
        self.img_ids = sorted(self.img_ids, key=lambda img_id: self.coco.imgs[img_id]['frame_id'])
        self.img_ids = sorted(self.img_ids, key=lambda img_id: self.coco.imgs[img_id]['video_id'])

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, item):
        # get RGB image(numpy.ndarray) and other information about this pic.
        img_id = self.img_ids[item]
        img_info = self.coco.imgs[img_id]
        vid_id = img_info['video_id']
        vid_idx = list(filter(lambda x : self.coco.dataset['videos'][x]['id'] == vid_id,
                              range(len(self.coco.dataset['videos']))))[0]
        img_height = self.coco.dataset['videos'][vid_idx]['height']
        img_width = self.coco.dataset['videos'][vid_idx]['width']
        img_path = os.path.join(self.data_dir, img_info['file_name'])
        img_path = os.path.abspath(img_path)
        # img_content = np.array(Image.open(img_path).convert('RGB'), dtype=np.uint8)
        if not self.public_detector:
            img_content = np.array(Image.open(img_path).convert('RGB'), dtype=np.uint8)
        else:
            img_content = None
        img_frame_id = img_info['frame_id']
        img_video_id = img_info['video_id']
        other_info = [img_height, img_width, img_frame_id, img_video_id, img_path]
        anno = []
        if self.dataset_type == 'train':
            annos = self.coco.imgToAnns[img_id]
            for anno in annos:
                bbox = anno['bbox']
                cls_id = anno['category_id']
                if 'group_id' in anno:
                    trace_id = anno['group_id']
                elif 'instance_id' in anno:
                    trace_id = anno['instance_id']
                else:
                    raise KeyError("group id or instance id should be provided")
                one_bbox = bbox[:]
                one_bbox.append(cls_id)
                one_bbox.append(trace_id)
                anno.append(one_bbox)

        if self.transform is not None and not self.public_detector:
            img_content = self.transform(img_content)
        return img_content, other_info, anno
