from __future__ import division
from itertools import chain
from itertools import repeat
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from einops.layers.torch import Rearrange
from einops import rearrange
import math

from yoloob.utils.parse_config import parse_model_config
from yoloob.utils.utils import weights_init_normal, xyxy2xywh
from yoloob.lib.models.TransFuse import BiFusion_block, Vit_S


def create_modules(module_defs):
    """
    Constructs module list of layer blocks from module configuration in module_defs
    """
    hyperparams = module_defs.pop(0)
    hyperparams.update({
        'batch': int(hyperparams['batch']),
        'subdivisions': int(hyperparams['subdivisions']),
        'width': int(hyperparams['width']),
        'height': int(hyperparams['height']),
        'channels': int(hyperparams['channels']),
        'optimizer': hyperparams.get('optimizer'),
        'momentum': float(hyperparams['momentum']),
        'decay': float(hyperparams['decay']),
        'learning_rate': float(hyperparams['learning_rate']),
        'burn_in': int(hyperparams['burn_in']),
        'max_batches': int(hyperparams['max_batches']),
        'policy': hyperparams['policy'],
        'lr_steps': list(zip(map(int, hyperparams["steps"].split(",")),
                             map(float, hyperparams["scales"].split(",")))),
        'cls': float(hyperparams['cls']),
        'cls_pw': float(hyperparams['cls_pw']),
        'obj': float(hyperparams['obj']),
        'obj_pw': float(hyperparams['obj_pw']),
        'fl_gamma': float(hyperparams['fl_gamma']),
        'box': float(hyperparams['box'])
    })
    assert hyperparams["height"] == hyperparams["width"], \
        "Height and width should be equal! Non square images are padded with zeros."
    output_filters = [hyperparams["channels"]]
    module_list = nn.ModuleList()
    for module_i, module_def in enumerate(module_defs):
        modules = nn.Sequential()

        if module_def["type"] == "convolutional":
            bn = int(module_def["batch_normalize"])
            filters = int(module_def["filters"])
            kernel_size = int(module_def["size"])
            pad = (kernel_size - 1) // 2
            modules.add_module(
                f"conv_{module_i}",
                nn.Conv2d(
                    in_channels=output_filters[-1],
                    out_channels=filters,
                    kernel_size=kernel_size,
                    stride=int(module_def["stride"]),
                    padding=pad,
                    bias=not bn,
                ),
            )
            if bn:
                modules.add_module(f"batch_norm_{module_i}",
                                   nn.BatchNorm2d(filters, momentum=0.1, eps=1e-5))
            if module_def["activation"] == "leaky":
                # modules.add_module(f"leaky_{module_i}", nn.LeakyReLU(0.1))
                modules.add_module(f"leaky_{module_i}", nn.SiLU())
            if module_def["activation"] == "mish":
                modules.add_module(f"mish_{module_i}", Mish())

        elif module_def["type"] == "rearrange":
            modules.add_module(f"rearrange_{module_i}", Rearrange("b c (h w) p1 p2 -> b c (h p1) (w p2)", h=4, w=4))

        elif module_def["type"] == "bifusion":
            r_2 = int(module_def["r_2"])
            ch1 = output_filters[-1]
            ch2 = int(module_def["filters"])
            # fuse = BiFusion_block(ch_1=ch1, ch_2=ch2, r_2=r_2, ch_int=ch1, ch_out=ch1, drop_rate=0.1)
            filters = ch1
            modules.add_module(f"bifusion_{module_i}", BiFusion_block(ch_1=ch1, ch_2=ch2, r_2=r_2, ch_int=ch1,
                                                                      ch_out=ch1, drop_rate=0.1))

        elif module_def["type"] == "maxpool":
            kernel_size = int(module_def["size"])
            stride = int(module_def["stride"])
            if kernel_size == 2 and stride == 1:
                modules.add_module(f"_debug_padding_{module_i}", nn.ZeroPad2d((0, 1, 0, 1)))
            maxpool = nn.MaxPool2d(kernel_size=kernel_size, stride=stride,
                                   padding=int((kernel_size - 1) // 2))
            modules.add_module(f"maxpool_{module_i}", maxpool)

        elif module_def["type"] == "upsample":
            upsample = Upsample(size=int(module_def["size"]), mode="nearest")
            modules.add_module(f"upsample_{module_i}", upsample)

        elif module_def["type"] == "route":
            layers = [int(x) for x in module_def["layers"].split(",")]
            filters = sum([output_filters[1:][i] for i in layers]) // int(module_def.get("groups", 1))
            modules.add_module(f"route_{module_i}", nn.Sequential())

        elif module_def["type"] == "shortcut":
            filters = output_filters[1:][int(module_def["from"])]
            modules.add_module(f"shortcut_{module_i}", nn.Sequential())

        elif module_def["type"] == "spp":
            levels = module_def["levels"]
            spp = SPPLayer(levels, "max_pool")
            modules.add_module(f"spp_{module_i}", spp)

        elif module_def["type"] == "yolo":
            anchor_idxs = [int(x) for x in module_def["mask"].split(",")]
            # Extract anchors
            anchors = [int(x) for x in module_def["anchors"].split(",")]
            anchors = [(anchors[i], anchors[i + 1]) for i in range(0, len(anchors), 2)]
            anchors = [anchors[i] for i in anchor_idxs]
            num_classes = int(module_def["classes"])
            # Define detection layer
            yolo_layer = YOLOLayer(anchors, num_classes)
            modules.add_module(f"yolo_{module_i}", yolo_layer)

        elif module_def["type"] == "detect":
            nc = int(module_def["nc"])
            det_layer1 = [int(layer) for layer in module_def["det_layer1"].split(',')]
            det_layer2 = [int(layer) for layer in module_def["det_layer2"].split(',')]
            det_layer3 = [int(layer) for layer in module_def["det_layer3"].split(',')]
            det_layers = [det_layer1, det_layer2, det_layer3]
            ch = [int(c) for c in module_def["ch"].split(',')]
            det = Detect(nc=nc, det_layers=det_layers, ch=ch)
            det.stride = torch.tensor([8., 16., 32.])
            det.det_layers /= det.stride.view(-1, 1, 1)
            modules.add_module(f"detect_{module_i}", det)
        # Register module list and number of output filters
        module_list.append(modules)
        output_filters.append(filters)

    return hyperparams, module_list


class SPPLayer(torch.nn.Module):

    def __init__(self, num_levels, pool_type='max_pool'):
        super(SPPLayer, self).__init__()

        self.num_levels = num_levels
        self.pool_type = pool_type

    def forward(self, x):
        # num:样本数量 c:通道数 h:高 w:宽
        # num: the number of samples
        # c: the number of channels
        # h: height
        # w: width
        num, c, h, w = x.size()
        for level in self.num_levels:

            '''
            The equation is explained on the following site:
            http://www.cnblogs.com/marsggbo/p/8572846.html#autoid-0-0-0
            '''
            kernel_size = (math.ceil(h / level), math.ceil(w / level))
            stride = (math.ceil(h / level), math.ceil(w / level))
            pooling = (math.floor((kernel_size[0]*level-h+1)/2), math.floor((kernel_size[1]*level-w+1)/2))

            # 选择池化方式
            if self.pool_type == 'max_pool':
                tensor1 = F.max_pool2d(x, kernel_size=kernel_size, stride=stride, padding=pooling)
                kernel_size = tuple(i+2 for i in list(kernel_size))
                pooling = tuple(i+1 for i in list(pooling))
                tensor2 = F.max_pool2d(x, kernel_size=kernel_size, stride=stride, padding=pooling)
                kernel_size = tuple(i+2 for i in list(kernel_size))
                pooling = tuple(i+1 for i in list(pooling))
                tensor3 = F.max_pool2d(x, kernel_size=kernel_size, stride=stride, padding=pooling)
            else:
                tensor1 = F.avg_pool2d(x, kernel_size=kernel_size, stride=stride, padding=pooling)
                kernel_size = tuple(i+2 for i in list(kernel_size))
                pooling = tuple(i+1 for i in list(pooling))
                tensor2 = F.avg_pool2d(x, kernel_size=kernel_size, stride=stride, padding=pooling)
                kernel_size = tuple(i+2 for i in list(kernel_size))
                pooling = tuple(i+1 for i in list(pooling))
                tensor3 = F.avg_pool2d(x, kernel_size=kernel_size, stride=stride, padding=pooling)

            # 融合
            x = tensor1+tensor2+tensor3

        return x


class Upsample(nn.Module):
    """ nn.Upsample is deprecated """

    def __init__(self, size, mode="nearest"):
        super(Upsample, self).__init__()
        self.size = tuple(repeat(size, 2))
        self.mode = mode

    def forward(self, x):
        x = F.interpolate(x, size=self.size, mode=self.mode)
        return x


class Mish(nn.Module):
    """ The MISH activation function (https://github.com/digantamisra98/Mish) """

    def __init__(self):
        super(Mish, self).__init__()

    def forward(self, x):
        return x * torch.tanh(F.softplus(x))


# YoloLayer 根据上一层卷积结果回归出anchor
class YOLOLayer(nn.Module):
    """Detection layer"""

    def __init__(self, anchors, num_classes):
        super(YOLOLayer, self).__init__()
        self.num_anchors = len(anchors)
        self.num_classes = num_classes
        self.mse_loss = nn.MSELoss()
        self.bce_loss = nn.BCELoss()
        self.no = num_classes + 5  # number of outputs per anchor
        self.grid = torch.zeros(1)  # TODO

        anchors = torch.tensor(list(chain(*anchors))).float().view(-1, 2)
        self.register_buffer('anchors', anchors)
        self.register_buffer(
            'anchor_grid', anchors.clone().view(1, -1, 1, 1, 2))
        self.stride = None

    def forward(self, x, img_size):
        stride = img_size // x.size(2)
        self.stride = stride
        bs, _, ny, nx = x.shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
        x = x.view(bs, self.num_anchors, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

        if not self.training:  # inference
            if self.grid.shape[2:4] != x.shape[2:4]:
                self.grid = self._make_grid(nx, ny).to(x.device)

            x[..., 0:2] = (x[..., 0:2].sigmoid() + self.grid) * stride  # xy offset
            x[..., 2:4] = torch.exp(x[..., 2:4]) * self.anchor_grid  # wh scale
            x[..., 4:] = x[..., 4:].sigmoid()
            x = x.view(bs, -1, self.no)

        return x

    @staticmethod
    def _make_grid(nx=20, ny=20):
        yv, xv = torch.meshgrid([torch.arange(ny), torch.arange(nx)], indexing='ij')
        return torch.stack((xv, yv), 2).view((1, 1, ny, nx, 2)).float()


class Detect(nn.Module):
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter

    def __init__(self, nc=1, det_layers=(), ch=(), inplace=True):  # detection layer
        super().__init__()
        self.nc = nc  # number of classes
        self.no = nc + 5  # number of outputs per detection layers
        self.nl = len(det_layers)  # number of detection layers
        self.na = 1

        self.grid = [torch.zeros(1)] * self.nl  # init grid
        a = torch.tensor(det_layers).float().view(self.nl, -1, 2)[:, :self.na, :]
        self.register_buffer('det_layers', a)  # shape(nl,na,2)
        self.register_buffer('det_layers_grid', a.clone().view(self.nl, 1, -1, 1, 1, 2))  # shape(nl,1,na,1,1,2)
        self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in ch)  # output conv
        self.inplace = inplace  # use in-place ops (e.g. slice assignment)

    def forward(self, x):
        z = []  # inference output
        for i in range(self.nl):
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,85,80,80,)
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            if not self.training:  # inference
                # 从推理代码上看应该是没法达到论文描述的那种需求才是，这里还是在对每个cell做遍历对比
                if self.grid[i].shape[2:4] != x[i].shape[2:4] or self.onnx_dynamic:
                    self.grid[i] = self._make_grid(nx, ny).to(x[i].device)

                y = x[i].sigmoid()

                coord = torch.ones([bs, self.na, ny, nx], device=y.device)
                coord = coord.nonzero(as_tuple=False)
                x_coord = coord[:, 3]
                y_coord = coord[:, 2]

                power = 2 ** i

                ### self.det_layers_grid = self.anchor_grid
                s_gain = torch.ones_like(self.det_layers_grid[i, ..., 0]) * power
                dx1 = (y[..., 0] * 2) ** 2 * s_gain
                dy1 = (y[..., 1] * 2) ** 2 * s_gain
                dx2 = (y[..., 2] * 2) ** 2 * s_gain
                dy2 = (y[..., 3] * 2) ** 2 * s_gain

                y[..., 0] = (x_coord.view(bs, self.na, ny, nx) + 1 - (dx1)) * self.stride[i]
                y[..., 1] = (y_coord.view(bs, self.na, ny, nx) + 1 - (dy1)) * self.stride[i]
                y[..., 2] = (x_coord.view(bs, self.na, ny, nx) + (dx2)) * self.stride[i]
                y[..., 3] = (y_coord.view(bs, self.na, ny, nx) + (dy2)) * self.stride[i]

                xyxy = y[..., :4].view(-1, 4)
                xywh = xyxy2xywh(xyxy)
                y[..., :4] = xywh.view(bs, self.na, ny, nx, 4)

                pred = y.view(bs, -1, self.no)
                z.append(pred)

        # return x if self.training else (torch.cat(z, 1), x)
        return x if self.training else torch.cat(z, 1)

    @staticmethod
    def _make_grid(nx=20, ny=20):
        yv, xv = torch.meshgrid([torch.arange(ny), torch.arange(nx)])
        return torch.stack((xv, yv), 2).view((1, 1, ny, nx, 2)).float()


class Darknet(nn.Module):
    """YOLOv3 object detection model"""

    def __init__(self, config_path):
        super(Darknet, self).__init__()
        self.module_defs = parse_model_config(config_path)
        self.hyperparams, self.module_list = create_modules(self.module_defs)
        self.yolo_layers = [layer[0]
                            for layer in self.module_list if isinstance(layer[0], YOLOLayer)]
        self.seen = 0
        self.header_info = np.array([0, 0, 0, self.seen, 0], dtype=np.int32)
        self.stride = torch.tensor([8., 16., 32.])

        self.spp0 = SPPLayer([13], 'max_pool')
        self.spp1 = SPPLayer([26], 'max_pool')
        self.spp2 = SPPLayer([52], 'max_pool')

        # self.resize = Upsample(size=208)
        # self.vit = Vit_S()

    def forward(self, x):
        img_size = x.size(2)
        layer_outputs, yolo_outputs = [], []
        # x_2 = self.resize(x)
        # feats = self.vit(x_2)
        for i, (module_def, module) in enumerate(zip(self.module_defs, self.module_list)):
            if module_def["type"] in ["convolutional", "upsample", "maxpool"]:
                x = module(x)
            # elif module_def["type"] == "bifusion":
            #     feat = feats[int(module_def["layer"])]
            #     x = module((x, feat))
            elif module_def["type"] == "route":
                layers = module_def["layers"].split(",")
                combined_outputs = torch.cat(
                    [layer_outputs[int(layer_i)] for layer_i in layers], 1)
                group_size = combined_outputs.shape[1] // int(module_def.get("groups", 1))
                group_id = int(module_def.get("group_id", 0))
                x = combined_outputs[:,
                    group_size * group_id: group_size * (group_id + 1)]  # Slice groupings used by yolo v4
            elif module_def["type"] == "shortcut":
                layer_i = int(module_def["from"])
                x = x + layer_outputs[layer_i]
            elif module_def["type"] == "yolo":
                x = module[0](x, img_size)
                yolo_outputs.append(x)
            elif module_def["type"] == "detect":
                pres = module_def["pres"].split(",")
                x = [layer_outputs[int(layer_i)] for layer_i in pres]
                x = module(x)
            layer_outputs.append(x)
        return x

    def load_darknet_weights(self, weights_path):
        """Parses and loads the weights stored in 'weights_path'"""

        # Open the weights file
        with open(weights_path, "rb") as f:
            # First five are header values
            header = np.fromfile(f, dtype=np.int32, count=5)
            self.header_info = header  # Needed to write header when saving weights
            self.seen = header[3]  # number of images seen during training
            weights = np.fromfile(f, dtype=np.float32)  # The rest are weights

        # Establish cutoff for loading backbone weights
        cutoff = None
        # If the weights file has a cutoff, we can find out about it by looking at the filename
        # examples: darknet53.conv.74 -> cutoff is 74
        filename = os.path.basename(weights_path)
        if ".conv." in filename:
            try:
                cutoff = int(filename.split(".")[-1])  # use last part of filename
            except ValueError:
                pass

        ptr = 0
        for i, (module_def, module) in enumerate(zip(self.module_defs, self.module_list)):
            if i == cutoff:
                break
            if module_def["type"] == "convolutional":
                conv_layer = module[0]
                if module_def["batch_normalize"]:
                    # Load BN bias, weights, running mean and running variance
                    bn_layer = module[1]
                    num_b = bn_layer.bias.numel()  # Number of biases
                    # Bias
                    bn_b = torch.from_numpy(
                        weights[ptr: ptr + num_b]).view_as(bn_layer.bias)
                    bn_layer.bias.data.copy_(bn_b)
                    ptr += num_b
                    # Weight
                    bn_w = torch.from_numpy(
                        weights[ptr: ptr + num_b]).view_as(bn_layer.weight)
                    bn_layer.weight.data.copy_(bn_w)
                    ptr += num_b
                    # Running Mean
                    bn_rm = torch.from_numpy(
                        weights[ptr: ptr + num_b]).view_as(bn_layer.running_mean)
                    bn_layer.running_mean.data.copy_(bn_rm)
                    ptr += num_b
                    # Running Var
                    bn_rv = torch.from_numpy(
                        weights[ptr: ptr + num_b]).view_as(bn_layer.running_var)
                    bn_layer.running_var.data.copy_(bn_rv)
                    ptr += num_b
                else:
                    # Load conv. bias
                    num_b = conv_layer.bias.numel()
                    conv_b = torch.from_numpy(
                        weights[ptr: ptr + num_b]).view_as(conv_layer.bias)
                    conv_layer.bias.data.copy_(conv_b)
                    ptr += num_b
                # Load conv. weights
                num_w = conv_layer.weight.numel()
                conv_w = torch.from_numpy(
                    weights[ptr: ptr + num_w]).view_as(conv_layer.weight)
                conv_layer.weight.data.copy_(conv_w)
                ptr += num_w

    def save_darknet_weights(self, path, cutoff=-1):
        """
            @:param path    - path of the new weights file
            @:param cutoff  - save layers between 0 and cutoff (cutoff = -1 -> all are saved)
        """
        fp = open(path, "wb")
        self.header_info[3] = self.seen
        self.header_info.tofile(fp)

        # Iterate through layers
        for i, (module_def, module) in enumerate(zip(self.module_defs[:cutoff], self.module_list[:cutoff])):
            if module_def["type"] == "convolutional":
                conv_layer = module[0]
                # If batch norm, load bn first
                if module_def["batch_normalize"]:
                    bn_layer = module[1]
                    bn_layer.bias.data.cpu().numpy().tofile(fp)
                    bn_layer.weight.data.cpu().numpy().tofile(fp)
                    bn_layer.running_mean.data.cpu().numpy().tofile(fp)
                    bn_layer.running_var.data.cpu().numpy().tofile(fp)
                # Load conv bias
                else:
                    conv_layer.bias.data.cpu().numpy().tofile(fp)
                # Load conv weights
                conv_layer.weight.data.cpu().numpy().tofile(fp)

        fp.close()


def load_model(model_path, weights_path=None, cuda_idx: int=0):
    """Loads the yolo model from file.

    :param model_path: Path to model definition file (.cfg)
    :type model_path: str
    :param weights_path: Path to weights or checkpoint file (.weights or .pth)
    :type weights_path: str
    :return: Returns model
    :rtype: Darknet
    """
    # device = torch.device("cuda:{}".format(args.cuda_idx))
    # torch.cuda.set_device(device)
    os.environ["CUDA_VISIBLE_DEVICES"] = str(cuda_idx)
    model = Darknet(model_path).cuda()

    model.apply(weights_init_normal)

    # If pretrained weights are specified, start from checkpoint or weight file
    if weights_path:
        if weights_path.endswith(".pth"):
            # Load checkpoint weights
            model.load_state_dict(torch.load(weights_path))
        else:
            # Load darknet weights
            model.load_darknet_weights(weights_path)
    return model
