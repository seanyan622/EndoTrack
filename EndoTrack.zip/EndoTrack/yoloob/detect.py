#! /usr/bin/env python3

from __future__ import division

import os
import argparse
import tqdm
import random
import numpy as np

from PIL import Image
import cv2
import csv
import re

import torch
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torch.autograd import Variable

from yoloob.models import load_model
from yoloob.utils.utils import load_classes, rescale_boxes, non_max_suppression, print_environment_info
from yoloob.utils.datasets import ImageFolder
from yoloob.utils.transforms import Resize, DEFAULT_TRANSFORMS

import matplotlib.pyplot as plt

import glob
import multiprocessing as mp


def detect_directory(model_path, weights_path, img_path, classes, output_path, args,
                     batch_size=8, img_size=416, n_cpu=0, conf_thres=0.5, nms_thres=0.5):
    """Detects objects on all images in specified directory and saves output images with drawn detections.

    :param model_path: Path to model definition file (.cfg)
    :type model_path: str
    :param weights_path: Path to weights or checkpoint file (.weights or .pth)
    :type weights_path: str
    :param img_path: Path to directory with images to inference
    :type img_path: str
    :param classes: List of class names
    :type classes: [str]
    :param output_path: Path to output directory
    :type output_path: str
    :param batch_size: Size of each image batch, defaults to 8
    :type batch_size: int, optional
    :param img_size: Size of each image dimension for yolo, defaults to 416
    :type img_size: int, optional
    :param n_cpu: Number of cpu threads to use during batch generation, defaults to 8
    :type n_cpu: int, optional
    :param conf_thres: Object confidence threshold, defaults to 0.5
    :type conf_thres: float, optional
    :param nms_thres: IOU threshold for non-maximum suppression, defaults to 0.5
    :type nms_thres: float, optional
    """
    dataloader = _create_data_loader(img_path, batch_size, img_size, n_cpu)
    # model = load_model(model_path, weights_path, args)
    model = load_model(model_path, weights_path)
    img_detections, imgs = detect(
        model,
        dataloader,
        conf_thres,
        nms_thres)
    _draw_and_save_output_images(
        img_detections, imgs, img_size, output_path, classes)

    print(f"---- Detections were saved to: '{output_path}' ----")


def detect_image(model, image, img_size=416, conf_thres=0.15, nms_thres=0.1, do_not_prep=False):
    """Inferences one image with model.

    :param model: Model for inference
    :type model: models.Darknet
    :param image: Image to inference
    :type image: nd.array
    :param img_size: Size of each image dimension for yolo, defaults to 416
    :type img_size: int, optional
    :param conf_thres: Object confidence threshold, defaults to 0.5
    :type conf_thres: float, optional
    :param nms_thres: IOU threshold for non-maximum suppression, defaults to 0.5
    :type nms_thres: float, optional
    :return: Detections on image with each detection in the format: [x1, y1, x2, y2, confidence, class]
    :rtype: nd.array
    """
    model.eval()  # Set model to evaluation mode

    # Configure input
    if not do_not_prep:
        input_img = transforms.Compose([
            DEFAULT_TRANSFORMS,
            Resize(img_size)])(
            (image, np.zeros((1, 5))))[0].unsqueeze(0)

    if torch.cuda.is_available():
        input_img = input_img.to("cuda")

    # Get detections
    with torch.no_grad():
        detections = model(input_img)
        detections = non_max_suppression(detections, conf_thres, nms_thres)
        detections = rescale_boxes(detections[0], img_size, image.shape[:2])


        # hiconf_dets = non_max_suppression(detections, 0.001, 0)
        # hiconf_dets = rescale_boxes(hiconf_dets[0], img_size, image.shape[:2])
        # plt.imshow(image)
        # from matplotlib.patches import Rectangle
        # # 绘制所有矩形框（使用matplotlib的Rectangle）
        # for i in range(len(hiconf_dets)):
        #     box = hiconf_dets[i]
        #     x1, y1, x2, y2 = box[:4]
        #
        #     # 创建矩形补丁
        #     rect = Rectangle(
        #         (x1, y1),  # 左下角坐标
        #         (x2 - x1),  # 宽度
        #         (y2 - y1),  # 高度
        #         fill=False,  # 不填充
        #         edgecolor='green',  # 边框颜色（红色）
        #         linewidth=2,  # 线宽
        #         alpha=0.5  # 透明度（50%）
        #     )
        #
        #     # 将矩形添加到当前坐标轴
        #     plt.gca().add_patch(rect)
        # plt.show()

    return detections.numpy()


def detect(model, dataloader, conf_thres, nms_thres):
    """Inferences images with model.

    :param model: Model for inference
    :type model: models.Darknet
    :param dataloader: Dataloader provides the batches of images to inference
    :type dataloader: DataLoader
    :param output_path: Path to output directory
    :type output_path: str
    :param conf_thres: Object confidence threshold, defaults to 0.5
    :type conf_thres: float, optional
    :param nms_thres: IOU threshold for non-maximum suppression, defaults to 0.5
    :type nms_thres: float, optional
    :return: List of detections. The coordinates are given for the padded image that is provided by the dataloader.
        Use `utils.rescale_boxes` to transform them into the desired input image coordinate system before its transformed by the dataloader),
        List of input image paths
    :rtype: [Tensor], [str]
    """

    model.eval()  # Set model to evaluation mode

    Tensor = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor

    img_detections = []  # Stores detections for each image index
    imgs = []  # Stores image paths

    for (img_paths, input_imgs) in tqdm.tqdm(dataloader, desc="Detecting"):
        # Configure input
        input_imgs = Variable(input_imgs.type(Tensor))

        # Get detections
        with torch.no_grad():
            detections = model(input_imgs)
            detections = non_max_suppression(detections, conf_thres, nms_thres)
            img_size = input_imgs.shape[-1]
            # ori_shape = cv2.imread(img_paths[0]).shape[:2]
            ori_shape = Image.open(img_paths[0]).size[::-1]
            # Rescale boxes to original image
            detections = [rescale_boxes(detections[i], img_size, ori_shape) for i in range(len(detections))]

        # Store image and detections
        img_detections.extend(detections)
        imgs.extend(img_paths)
    return img_detections, imgs


def _draw_and_save_output_images(img_detections, imgs, img_size, output_path, classes):
    """Draws detections in output images and stores them.

    :param img_detections: List of detections
    :type img_detections: [Tensor]
    :param imgs: List of paths to image files
    :type imgs: [str]
    :param img_size: Size of each image dimension for yolo
    :type img_size: int
    :param output_path: Path of output directory
    :type output_path: str
    :param classes: List of class names
    :type classes: [str]
    """

    # conf = []
    # # Iterate through images and save plot of detections
    # for (image_path, detections) in zip(imgs, img_detections):
    #     print(f"Image {image_path}:")
    #     _draw_and_save_output_image(
    #         image_path, detections, img_size, output_path, classes)
    # #     conf += c.item()
    # # print("mean confidence:", sum(conf)/len(conf))
    os.makedirs(output_path, exist_ok=True)
    with open(os.path.join(output_path, 'det.txt'), 'w+') as detection_file:
        writer = csv.writer(detection_file, lineterminator='\r')
        for (img_path, detections) in zip(imgs, img_detections):
            frame_id = re.search('[0-9]+', os.path.basename(img_path).split('.')[0]).group()
            frame_id = int(float(frame_id))
            for detection in detections:
                oneline = [frame_id, -1, float(detection[0]), float(detection[1]), float(detection[2] - detection[0]),
                           float(detection[3] - detection[1]), float(detection[4]), -1, -1, -1]
                for i in range(len(oneline)):
                    oneline[i] = str(oneline[i])
                writer.writerow(oneline)


def _draw_and_save_output_image(image_path, detections, img_size, output_path, classes):
    """Draws detections in output image and stores this.

    :param image_path: Path to input image
    :type image_path: str
    :param detections: List of detections on image
    :type detections: [Tensor]
    :param img_size: Size of each image dimension for yolo
    :type img_size: int
    :param output_path: Path of output directory
    :type output_path: str
    :param classes: List of class names
    :type classes: [str]
    """
    # Create plot
    img = np.array(Image.open(image_path))
    # plt.figure()
    # fig, ax = plt.subplots(1)
    # ax.imshow(img)

    unique_labels = detections[:, -1].cpu().unique()
    n_cls_preds = len(unique_labels)
    # Bounding-box colors
    cmap = plt.get_cmap("tab20b")
    colors = [cmap(i) for i in np.linspace(0, 1, n_cls_preds)]
    bbox_colors = random.sample(colors, n_cls_preds)
    # conf = []
    for x1, y1, x2, y2, conf, cls_pred in detections:
        print(f"\t+ Label: {classes[int(cls_pred)]} | Confidence: {conf.item():0.4f}")
        # conf += round(float(conf), 3)
        # box_w = x2 - x1
        # box_h = y2 - y1

        ptLeftTop = (int(x1), int(y1))
        ptRightBottom = (int(x2), int(y2))

        cv2.rectangle(img, ptLeftTop, ptRightBottom, (255, 0, 0), 2, 4)
        cls_conf = classes[int(cls_pred)] + ':' + str(round(float(conf), 3))
        cv2.putText(img, cls_conf, (int(x1) + 2, int(y1) + 20), cv2.FONT_HERSHEY_SIMPLEX, 1.00, (255, 0, 0), 3)
        # color = bbox_colors[int(np.where(unique_labels == int(cls_pred))[0])]
        # Create a Rectangle patch
        # bbox = patches.Rectangle((x1, y1), box_w, box_h, linewidth=2, edgecolor=color, facecolor="none")
        # Add the bbox to the plot
        # ax.add_patch(bbox)
        # Add label
        # plt.text(
        #     x1,
        #     y1,
        #     s=classes[int(cls_pred)],
        #     color="white",
        #     verticalalignment="top",
        #     bbox={"color": color, "pad": 0})

    # Save generated image with detections
    # plt.axis("off")
    # plt.gca().xaxis.set_major_locator(NullLocator())
    # plt.gca().yaxis.set_major_locator(NullLocator())
    img = img[:, :, ::-1]  # BGR to RGB
    filename = os.path.basename(image_path).split(".")[0]
    output_path = os.path.join(output_path, f"{filename}.jpg")
    cv2.imwrite(output_path, img)
    # return conf
    # plt.savefig(output_path, bbox_inches="tight", pad_inches=0.0)
    # plt.close()


def _create_data_loader(img_path, batch_size, img_size, n_cpu):
    """Creates a DataLoader for inferencing.

    :param img_path: Path to file containing all paths to validation images.
    :type img_path: str
    :param batch_size: Size of each image batch
    :type batch_size: int
    :param img_size: Size of each image dimension for yolo
    :type img_size: int
    :param n_cpu: Number of cpu threads to use during batch generation
    :type n_cpu: int
    :return: Returns DataLoader
    :rtype: DataLoader
    """
    dataset = ImageFolder(
        img_path,
        transform=transforms.Compose([DEFAULT_TRANSFORMS, Resize(img_size)]))
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=n_cpu,
        pin_memory=False)
    return dataloader


def run():
    print_environment_info()
    parser = argparse.ArgumentParser(description="Detect objects on images.")
    parser.add_argument("-m", "--model", type=str, default="config/yolov3-custom-BiFPN-OB.cfg",
                        help="Path to model definition file (.cfg)")
    parser.add_argument("-w", "--weights", type=str,
                        default="/mnt/data2/zyf/netout/221201|OB|0001|bs16/checkpoints/yolov3_ckpt_63_ap_0.99553.pth",
                        help="Path to weights or checkpoint file (.weights or .pth)")
    parser.add_argument("-i", "--images", type=str,
                        default="/mnt/data1/zyf/Union/all_test",
                        help="Path to directory with images to inference")
    parser.add_argument("-c", "--classes", type=str, default="data/custom/classes.names",
                        help="Path to classes label file (.names)")
    parser.add_argument("-o", "--output", type=str, default="/mnt/data2/zyf/Union/Output/test-OBall0207",
                        # valid-OBch000116
                        help="Path to output directory")
    parser.add_argument("-b", "--batch_size", type=int, default=1, help="Size of each image batch")
    parser.add_argument("--img_size", type=int, default=416, help="Size of each image dimension for yolo")
    parser.add_argument("--n_cpu", type=int, default=1, help="Number of cpu threads to use during batch generation")
    parser.add_argument("--conf_thres", type=float, default=0.15, help="Object confidence threshold")
    parser.add_argument("--nms_thres", type=float, default=0.1, help="IOU threshold for non-maximum suppression")
    parser.add_argument('--cuda_idx', type=str, default='6', help='cuda')
    args = parser.parse_args()
    print(f"Command line arguments: {args}")

    # Extract class names from file
    classes = load_classes(args.classes)  # List of class names

    detect_directory(
        args.model,
        args.weights,
        args.images,
        classes,
        args.output,
        args,
        batch_size=args.batch_size,
        img_size=args.img_size,
        n_cpu=args.n_cpu,
        conf_thres=args.conf_thres,
        nms_thres=args.nms_thres)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--start', type=int, default=1)
    parser.add_argument('-e', '--end', type=int, default=29)
    args = parser.parse_args()
    model_path = r'P:\MOTracker\yoloob\config\yolov3-custom-BiFPN-OB.cfg'
    weight = r'P:\MOTracker\yoloob\weights\yolov3_ckpt_15_ap_0.99570.pth'
    datasets_dir = r'D:\CVC-ClinicDB'
    output_dir = r'P:\MOTracker\output\det\CVC-ClinicDB\3'
    conf = 0.1
    nms = 0.2
    tsize = 416
    # detect_directory(
    #     model_path=model_path,
    #     weights_path=weight,
    #     img_path=r'P:\MOTracker\datasets\SUN-SEG\test\seq_030\img',
    #     classes=load_classes(r'P:\MOTracker\yoloob\data\custom\classes.names'),
    #     output_path='temp',
    #     args=None,
    #     batch_size=16,
    #     img_size=tsize,
    #     conf_thres=conf,
    #     nms_thres=nms
    # )
    # for sub in ['test', 'train']:
    for sub in ['test']:
        subdatasets_dir = [os.path.join(datasets_dir, sub, sd) for sd in os.listdir(os.path.join(datasets_dir, sub)) if
                           sd.startswith('seq')]
        for sd in subdatasets_dir:
            idx = int(re.search('\d+', os.path.basename(sd)).group())
            if not args.start <= idx <= args.end:
                continue
            print(f'Detecting image folder {sd}\n')
            with open(os.path.join(sd, 'seqinfo.ini')) as seqfile:
                file_content = seqfile.readlines()
                for line in file_content:
                    if line.startswith('imDir'):
                        img_dir_name = line[:-1].split('=')[1]
            img_dir = os.path.join(sd, img_dir_name)
            out_path = os.path.join(output_dir, os.path.basename(sd))
            classes = load_classes(r'P:\MOTracker\yoloob\data\custom\classes.names')
            os.makedirs(out_path, exist_ok=True)
            with open(os.path.join(out_path, 'para.txt'), 'w+') as para_file:
                para_file.write('parameters\n')
                para_file.write(f'weight path: {weight}\n')
                para_file.write(f'input size: {tsize}\n')
                para_file.write(f'confidence threshold: {conf}\n')
                para_file.write(f'NMS threshold: {nms}\n')
            detect_directory(
                model_path=model_path,
                weights_path=weight,
                img_path=img_dir,
                classes=classes,
                output_path=out_path,
                args=None,
                batch_size=16,
                img_size=tsize,
                conf_thres=conf,
                nms_thres=nms
            )

    # subdataset_list = glob.glob(os.path.join(datasets_dir, 't*', 'Colon-??'))
    # gpu_mem_total = torch.cuda.mem_get_info()[0] / 1024 / 1024
    # mem_per_task = 1600
    # num_cores = min(len(subdataset_list), int(mp.cpu_count()), int(gpu_mem_total / mem_per_task))
    # pool = mp.Pool(num_cores)
    # para_dict = dict()
    # for i, subdataset_path in enumerate(subdataset_list):
    #     if f'task{i % num_cores}' not in para_dict:
    #         para_dict[f'task{i % num_cores}'] = [subdataset_path]
    #     else:
    #         para_dict[f'task{i % num_cores}'].append(subdataset_path)
    # results = [pool.apply_async(infer_folders, args=[p]) for _, p in para_dict.items()]
    # # results = pool.map(infer_folders, list(para_dict.items()))
    # results = [p.get() for p in results]
    # pool.close()
    # pool.join()
