import cv2
from einops import rearrange
import torch
import math
import torch.nn as nn
import numpy as np
import shutil

from lib.config import config, update_config
from lib.models import cls_cvt
from models import SPPLayer, Darknet
from utils.vit import ViT
from lib.models import TransFuse


def test():
    img = torch.rand((8, 3, 1158, 1008))

    # model_path = "./config/yolov3-custom-TF.cfg"
    # model = Darknet(model_path)
    # total_params = sum(p.numel() for p in model.parameters())
    # print(f'{total_params:,} total parameters.')
    # total_trainable_params = sum(
    #     p.numel() for p in model.parameters() if p.requires_grad)
    # print(f'{total_trainable_params:,} training parameters.')

    # update_config(config, '/home/zyf/DL/Yolo-VIT/config/cvt-21-384x384.yaml')
    #
    # msvit_spec = config.MODEL.SPEC
    # cvt = cls_cvt.ConvolutionalVisionTransformer(in_chans=3, num_classes=1, spec=msvit_spec)
    # x = cvt(img)

    # v = ViT(image_size=416, patch_size=26, num_classes=1, dim=1024, depth=6, heads=16, mlp_dim=2048, dropout=0.1,
    #         emb_dropout=0.1)
    # y = v(img)

    # tf = TransFuse.Vit_S()
    # total_params = sum(p.numel() for p in tf.parameters())
    # print(f'{total_params:,} total parameters.')
    # total_trainable_params = sum(
    #     p.numel() for p in tf.parameters() if p.requires_grad)
    # print(f'{total_trainable_params:,} training parameters.')

    model = Darknet("./config/yolov3-custom-BiFPN-OB.cfg")
    spp = SPPLayer([13], 'max_pool')
    x = spp(img)
    print(x)

    print("stop")


if __name__ == "__main__":
    test()
