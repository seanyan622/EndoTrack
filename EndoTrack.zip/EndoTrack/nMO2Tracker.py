import abc
import argparse
import collections.abc
import csv
import inspect 
import json
import math
import numbers
import os
import shutil
import typing
import warnings

import onnxruntime
import tqdm
import time
import re

import numpy as np
import scipy.stats
import sympy as sp
import yaml
from PIL import Image
from loguru import logger
from pycocotools.coco import COCO
from torch.utils.data.datapipes.utils.decoder import Decoder
from torch.utils.data.dataset import Dataset

# TODO: replace OpenCV with Pillow
from yoloob.detect import detect_image

from tools.utils import plot_with_rectangle


def default_parser():
    parser = argparse.ArgumentParser('Track using MO2Tracker')
    parser.add_argument('--exp_cfg', '-c', help='experiment configuration')
    parser.add_argument('--log', action='store_true')
    args = parser.parse_args()
    return args

class _Queue(collections.abc.Collection):
    def __init__(self, length=100):
        assert length >= 1
        self._queue = []
        self.max_len = length

    def _empty_pos(self):
        return self.max_len - len(self._queue)

    def enqueue(self, *x):
        if self._empty_pos() >= len(x):
            self._queue += list(x)
        elif len(x) < self.max_len:
            idx_to_remove = len(x) - self._empty_pos()
            del self._queue[:idx_to_remove]
            self._queue += list(x)
        else:
            self._queue = list(x[-self.max_len:])

    def dequeue(self, n=1):
        if n <= len(self._queue):
            del self._queue[:n]
        else:
            self._queue = []

    def __iter__(self):
        self._current_idx = 0
        return self

    def __len__(self):
        return len(self._queue)

    def __next__(self):
        if self._current_idx < len(self):
            x = self._queue[self._current_idx]
            self._current_idx += 1
            return x
        raise StopIteration


# new jacobian matrix function
def jacobian(func: collections.abc.Callable) -> sp.Matrix:
    args_in = inspect.signature(func).parameters.keys()
    # in this particular context, all parameters are real numbers
    vars_in = [sp.symbols(arg, real=True) for arg in args_in]

    rows = []
    for i, f_i in enumerate(func(*vars_in)):
        row = []
        for var in vars_in:
            row.append(sp.diff(f_i, var))
        rows.append(row)

    return sp.Matrix(rows)


class MotionPredictor(abc.ABC):
    """
    Predict object's location & size

    """

    def __init__(self,
                 sys_f: typing.Union[collections.abc.Collection, collections.abc.Callable],
                 obs_f: typing.Union[collections.abc.Collection, collections.abc.Callable],
                 linearize: bool = False,
                 Q: collections.abc.Collection[numbers.Real] = None,
                 R: collections.abc.Collection[numbers.Real] = None) -> None:
        pass

    def predict(self, Q: collections.abc.Collection[numbers.Real] = None) -> None:
        pass

    def initialize(self, sys_v: collections.abc.Collection[numbers.Real],
                   sys_cov: collections.abc.Collection[numbers.Real]) -> None:
        pass

    def estimate(self) -> np.ndarray:
        pass

    def update(self, obs_v: collections.abc.Collection[numbers.Real],
               R: collections.abc.Collection[numbers.Real] = None) -> None:
        pass

    def obs_estimate(self) -> np.ndarray:
        pass


class KalmanFilter(MotionPredictor):
    def __init__(self,
                 sys_f: collections.abc.Collection,
                 obs_f: collections.abc.Collection,
                 Q: collections.abc.Collection[numbers.Real] = None,
                 R: collections.abc.Collection[numbers.Real] = None) -> None:
        MotionPredictor.__init__(self, sys_f, obs_f, linearize=False, Q=Q, R=R)
        self.F: np.ndarray = np.array(sys_f).astype(np.float32)
        self.H: np.ndarray = np.array(obs_f).astype(np.float32)
        self.mean = None
        self.cov = None
        assert self.F.ndim == self.H.ndim == 2
        self.ny, self.nx = self.H.shape
        if Q is not None:
            self.Q: np.ndarray = np.array(Q).astype(np.float32)
            assert self.Q.ndim == 2
            assert self.Q.shape == (self.nx, self.nx)
        else:
            self.Q = None
        if R is not None:
            self.R: np.ndarray = np.array(R).astype(np.float32)
            assert self.R.ndim == 2
            assert self.R.shape == (self.ny, self.ny)
        else:
            self.R = None

    def initialize(self, sys_v: collections.abc.Collection[numbers.Real],
                   sys_cov: collections.abc.Collection[numbers.Real]) -> None:
        sys_v: np.ndarray = np.array(sys_v).astype(np.float32)
        assert sys_v.ndim == 1
        assert len(sys_v) == self.nx
        sys_cov: np.ndarray = np.array(sys_cov).astype(np.float32)
        assert sys_cov.ndim == 2
        assert sys_cov.shape == (self.nx, self.nx)
        self.mean = sys_v
        self.cov = sys_cov

    def predict(self, Q: collections.abc.Collection[numbers.Real] = None) -> None:
        if Q is not None:
            self.Q = np.array(Q).astype(np.float32)
            assert self.Q.ndim == 2
            assert self.Q.shape == (self.nx, self.nx)
        if self.Q is None:
            raise ValueError('system variable covariance is required')
        self.mean = self.F @ self.mean
        self.cov = self.F @ self.cov @ self.F.T + self.Q

    def update(self, obs_v: collections.abc.Collection[numbers.Real],
               R: collections.abc.Collection[numbers.Real] = None) -> None:
        if R is not None:
            self.R = np.array(R).astype(np.float32)
            assert self.R.ndim == 2
            assert len(self.R) == self.ny
        if self.R is None:
            raise ValueError('observation variable covariance is required')
        obs_v: np.ndarray = np.array(obs_v).astype(np.float32)
        assert obs_v.ndim == 1
        assert len(obs_v) == self.ny
        K = self.cov @ self.H.T @ np.linalg.inv(self.H @ self.cov @ self.H.T + self.R)
        self.mean = self.mean + K @ (obs_v - self.H @ self.mean)
        self.cov = self.cov - K @ self.H @ self.cov

    def estimate(self) -> np.ndarray:
        return self.mean

    def obs_estimate(self) -> np.ndarray:
        return self.H @ self.mean


class ExtendKalmanFilter(MotionPredictor):
    #TODO: use `sympy` package
    """
    Extend Kalman filter for non-linear system estimation.

    ----------------------

    """

    def __init__(self,
                 sys_f: collections.abc.Callable,
                 obs_f: collections.abc.Callable,
                 Q: collections.abc.Collection[numbers.Real] = None,
                 R: collections.abc.Collection[numbers.Real] = None,
                 eps=1e-6) -> None:
        MotionPredictor.__init__(self, sys_f, obs_f, linearize=True, Q=Q, R=R)
        self.f = sys_f
        self.h = obs_f
        self.mean = None
        self.cov = None
        self.eps = eps
        fcode = self.f.__code__
        hcode = self.h.__code__
        f0 = self.f(*([0] * fcode.co_argcount))
        h0 = self.h(*([0] * hcode.co_argcount))
        # system function gets and returns same number of variable(s)/parameter(s)
        assert fcode.co_argcount == len(f0) == hcode.co_argcount
        self.nx = fcode.co_argcount
        self.ny = len(h0)
        if Q is not None:
            self.Q: np.ndarray = np.array(Q).astype(np.float32)
            assert self.Q.ndim == 2
            assert self.Q.shape == (self.nx, self.nx)
        else:
            self.Q = None
        if R is not None:
            self.R: np.ndarray = np.array(R).astype(np.float32)
            assert self.R.ndim == 2
            assert self.R.shape == (self.ny, self.ny)
        else:
            self.R = None
        self.state_vars = [sp.symbols(arg, real=True) for arg in inspect.signature(self.f).parameters.keys()]
        self.f_jacobian = jacobian(self.f)
        self.h_jacobian = jacobian(self.h)

    @classmethod
    def _jacobian(cls, func: collections.abc.Callable,
                  x: typing.Union[numbers.Real, collections.abc.Collection[numbers.Real]],
                  h: numbers.Real,
                  method: str = 'bidirectional'):
        if method.casefold() not in ['forward', 'backward', 'bidirectional']:
            raise ValueError('expect one of derivative methods in forward, backward, and bidirectional')
        if h <= 0:
            raise ValueError(f'expect positive h, but got {h}')
        curr_y = func(*x)
        m = len(curr_y)
        n = len(x)
        jacobian = np.zeros((m, n))
        if method.casefold() == 'forward':
            for j in range(n):
                v1 = list(x)
                v1[j] += h
                v2 = list(x)
                jacobian[:, j] = (np.array(func(*v1)) - np.array(func(*v2))) / h
        elif method.casefold() == 'backward':
            for j in range(n):
                v1 = list(x)
                v2 = list(x)
                v2[j] -= h
                jacobian[:, j] = (np.array(func(*v1)) - np.array(func(*v2))) / h
        else:
            for j in range(n):
                v1 = list(x)
                v1[j] += h
                v2 = list(x)
                v2[j] -= h
                jacobian[:, j] = (np.array(func(*v1)) - np.array(func(*v2))) / (2 * h)
        return jacobian

    @classmethod
    def _numerical_derivative(cls,
                              func: collections.abc.Callable,
                              x: collections.abc.Collection[numbers.Real],
                              step: numbers.Real,
                              eps: numbers.Real = 1e-6):
        if step <= 0:
            raise ValueError(f'expect positive step, but got {step}')
        table_size = 10
        con = 1.4
        con2 = con ** 2
        curr_step = step
        n = len(x)
        curr_y = func(*x)
        m = len(curr_y)
        tab = np.zeros((m, n, table_size, table_size))
        tab[:, :, 0, 0] = cls._jacobian(func, x, curr_step)
        ret = tab[:, :, 0, 0]
        for j in range(1, table_size):
            curr_step /= con
            tab[:, :, 0, j] = cls._jacobian(func, x, curr_step)
            fac = con2
            for i in range(1, j + 1):
                tab[:, :, i, j] = (tab[:, :, i - 1, j] * fac - tab[:, :, i - 1, j - 1]) / (fac - 1)
                fac *= con2
                errt = np.max([np.abs(tab[:, :, i, j] - tab[:, :, i - 1, j]),
                               np.abs(tab[:, :, i, j] - tab[:, :, i - 1, j - 1])])
                if errt <= eps:
                    eps = errt
                    ret = tab[:, :, i, j]
            if np.min(np.abs(tab[:, :, j, j] - tab[:, :, j - 1, j - 1])) >= 2 * eps:
                break
        return ret

    def initialize(self, sys_v: collections.abc.Collection[numbers.Real],
                   sys_cov: collections.abc.Collection[numbers.Real]) -> None:
        sys_v: np.ndarray = np.array(sys_v).astype(np.float32)
        assert sys_v.ndim == 1
        assert len(sys_v) == self.nx
        sys_cov: np.ndarray = np.array(sys_cov).astype(np.float32)
        assert sys_cov.ndim == 2
        assert sys_cov.shape == (self.nx, self.nx)
        self.mean = sys_v + np.random.uniform(-1e-4, 1e-4, size=sys_v.shape)
        self.cov = sys_cov

    def predict(self, Q: collections.abc.Collection[numbers.Real] = None) -> None:
        if Q is not None:
            self.Q = np.array(Q).astype(np.float32)
            assert self.Q.ndim == 2
            assert self.Q.shape == (self.nx, self.nx)
        if self.Q is None:
            raise ValueError('system variable covariance is required')
        F = self.f_jacobian.subs(
            {var: val for (var, val) in zip(self.state_vars, self.mean)}).evalf()
        F = np.array(F, dtype=float)
        self.mean = np.array(self.f(*self.mean))
        self.cov = F @ self.cov @ F.T + self.Q

    def update(self, obs_v: collections.abc.Collection[numbers.Real],
               R: collections.abc.Collection[numbers.Real] = None) -> None:
        if R is not None:
            self.R = np.array(R).astype(np.float32)
            assert self.R.ndim == 2
            assert len(self.R) == self.ny
        if self.R is None:
            raise ValueError('observation variable covariance is required')
        obs_v: np.ndarray = np.array(obs_v).astype(np.float32)
        assert obs_v.ndim == 1
        assert len(obs_v) == self.ny
        H = self.h_jacobian.subs(
            {var: val for (var, val) in zip(self.state_vars, self.mean)}).evalf()
        H = np.array(H, dtype=float)
        K = self.cov @ H.T @ np.linalg.inv(H @ self.cov @ H.T + self.R)
        self.mean = self.mean + K @ (obs_v - self.h(*self.mean))
        self.cov = self.cov - K @ H @ self.cov

    def estimate(self) -> np.ndarray:
        return self.mean

    def obs_estimate(self) -> np.ndarray:
        return self.h(*self.mean)


class ParticleFilter(MotionPredictor):
    def __init__(self,
                 sys_f: typing.Union[collections.abc.Collection, collections.abc.Callable],
                 obs_f: typing.Union[collections.abc.Collection, collections.abc.Callable],
                 Q: collections.abc.Collection[numbers.Real] = None,
                 R: collections.abc.Collection[numbers.Real] = None,
                 **kwargs) -> None:
        MotionPredictor.__init__(self, sys_f, obs_f, False, Q, R)
        if isinstance(sys_f, collections.abc.Callable):
            self.f = sys_f
        else:
            self.f = lambda p: np.matmul(sys_f, p)
        if isinstance(obs_f, collections.abc.Callable):
            self.h = obs_f
        else:
            self.h = lambda p: np.matmul(obs_f, p)
        self.particles = [None] * kwargs.setdefault('N', 100)
        self.weights = np.ones_like(self.particles)
        self.seed = kwargs.setdefault('seed', 1)
        self.nx = kwargs.setdefault('nx', None)
        self.ny = kwargs.setdefault('ny', None)
        if Q is not None:
            self.Q: np.ndarray = np.array(Q).astype(np.float32)
            self.nx = len(self.Q)
            assert self.Q.ndim == 2
            assert self.Q.shape == (self.nx, self.nx)
        else:
            self.Q = None
        if R is not None:
            self.R: np.ndarray = np.array(R).astype(np.float32)
            self.ny = len(self.R)
            assert self.R.ndim == 2
            assert self.R.shape == (self.ny, self.ny)
        else:
            self.R = None

    def estimate(self) -> np.ndarray:
        return np.average(self.particles, axis=0, weights=self.weights)

    def obs_estimate(self) -> np.ndarray:
        return self.h(self.estimate())

    def initialize(self, sys_v: collections.abc.Collection[numbers.Real],
                   sys_cov: collections.abc.Collection[numbers.Real]) -> None:
        sys_v: np.ndarray = np.array(sys_v).astype(np.float32)  # (nx, )
        if self.nx is None:
            self.nx = len(sys_v)
        assert sys_v.ndim == 1
        assert len(sys_v) == self.nx
        sys_cov: np.ndarray = np.array(sys_cov).astype(np.float32)
        assert sys_cov.ndim == 2
        assert sys_cov.shape == (self.nx, self.nx)
        x_dist = scipy.stats.multivariate_normal(mean=sys_v, cov=sys_cov, seed=self.seed)
        self.particles: np.ndarray = x_dist.rvs(len(self.particles)).astype(float)
        self.weights = np.ones(len(self.particles)) / len(self.particles)

    def predict(self, Q: collections.abc.Collection[numbers.Real] = None) -> None:
        if Q is not None:
            self.Q = np.array(Q).astype(np.float32)
            assert self.Q.ndim == 2
            assert self.Q.shape == (self.nx, self.nx)
        if self.Q is None:
            raise ValueError('system variable covariance is required')
        self.particles: np.ndarray = self.f(self.particles)
        self.particles += scipy.stats.multivariate_normal(cov=self.Q).rvs(len(self.particles))

    def update(self, obs_v: collections.abc.Collection[numbers.Real],
               R: collections.abc.Collection[numbers.Real] = None) -> None:
        obs_v = np.array(obs_v).astype(np.float32)
        if self.ny is None:
            self.ny = len(obs_v)
        if R is not None:
            self.R: np.ndarray = np.array(R).astype(np.float32)
            assert self.R.ndim == 2
            assert len(self.R) == self.ny
        if self.R is None:
            raise ValueError('observation variable covariance is required')
        obs_v: np.ndarray = np.array(obs_v).astype(float)
        # sometimes better particles can overwhelm bad particles
        # pdf of Multi-Variant Normal Dist
        # = 1 / sqrt((2 * pi) ^ k * DET(Sigma)) * exp(-1 / 2 * (x - mu)^T * Sigma^(-1) * (x - mu))
        # only consider the exponential number
        diff = self.h(self.particles) - obs_v
        invR = np.linalg.inv(self.R)
        exp = -1 / 2 * np.hstack([np.linalg.multi_dot((ln, invR, ln)) for ln in diff])
        # empirically define particles with weight <= 1e-6 * max(weights) are dead
        factor = 1e6
        dead_bool = exp <= np.max(exp) - np.log(factor)
        alive_mean = np.mean(exp, where=np.logical_not(dead_bool))
        weight = np.where(dead_bool, 0, np.exp(exp - alive_mean))
        # re-sample
        rng = np.random.default_rng(seed=self.seed)
        self.particles = rng.choice(self.particles, size=len(self.particles), p=weight / np.sum(weight)).astype(float)
        self.weights = np.ones(len(self.particles)) / len(self.particles)


class Detection:
    def __init__(self, cls_id, frame_id, loc: np.ndarray, conf, appearance=None, **kwargs):
        # assert loc.shape == (4,)
        assert loc.__len__() == 4
        self.conf = conf
        self.loc = loc  # ltwh
        self.cls_id = cls_id
        self.frame_id = frame_id
        self.appearance = appearance
        self.other_features = kwargs['others'] if 'others' in kwargs else None
        self.img_shape = kwargs.setdefault('img_shape', [1920, 1080])

    def on_edge(self) -> dict:
        (left, top, width, height) = self.loc
        edge_info = {
            'left'  : left <= 0,
            'top'   : top <= 0,
            'right' : left + width >= self.img_shape[0],
            'bottom': top + height >= self.img_shape[1]
        }
        # edge_info = [edge_info[k] for k in ['left', 'top', 'right', 'bottom']]
        # return ''.join(['1' if v else '0' for v in edge_info])
        return edge_info

    def compensate_loc(self, avg_ah=None) -> None:
        if avg_ah is not None and any(self.on_edge().values()):
            avg_a, avg_h = avg_ah
            old_l, old_t, old_a, old_h = self.loc  # archive
            # Always use average aspect
            self.loc[2] = avg_a

            edge_info = self.on_edge()
            if not (edge_info['left'] or edge_info['right']):  # width to keep
                keep_width = True
            else:
                keep_width = False

            # If height is available, keeps it, else use average height
            if not (edge_info['top'] or edge_info['bottom']):  # height to keep
                keep_height = True
            else:
                keep_height = False
            if not keep_height:
                self.loc[3] = avg_h

            # left
            if edge_info['left'] and not edge_info['right']:  # left bound beyonds edge, keep right bound
                self.loc[0] -= (self.loc[2] * self.loc[3]) - (old_a * old_h)
            elif edge_info['left'] and edge_info['right']:  # left & right bounds beyond edge, keep middle point
                self.loc[0] -= ((self.loc[2] * self.loc[3]) - (old_a * old_h)) / 2

            # top
            if edge_info['top'] and not edge_info['bottom']:  # top bound beyonds edge, keep bottom bound
                self.loc[1] -= self.loc[3] - old_h
            elif edge_info['top'] and edge_info['bottom']:  # top & bottom bounds beyond edge, keep middle point
                self.loc[1] -= (self.loc[3] - old_h) / 2


class Coreset:
    """
    Coreset implementation of https://doi.org/10.1137/18M1209854
    n: number of input points, unknown for the streaming algorithm set
    d: dimension of each point
    j: dimension of linear(affine) subspaces
    k: cardinal(number) of subspaces
    """

    def __init__(self, j=0, k=1):
        assert j >= 0 and k >= 1
        self.j = j
        self.k = k

    def subspace_coreset(self, dataset: np.ndarray, eps: float = 1 / 3):
        assert dataset.ndim == 2 and eps > 0
        n, d = dataset.shape
        m = min([n, d, self.k + math.ceil(self.k / eps) - 1])
        if d <= m or n <= m:
            return dataset, 0.0, np.ones(len(dataset))
        (u, s, vh) = scipy.linalg.svd(dataset)
        ur = u[:, :m]
        vhr = vh[:m, :]
        sr = s[:m]
        S = np.diag(sr) @ vhr
        dm = ur @ S
        delta = np.linalg.norm(dataset - dm)
        return S, delta, np.ones(len(S))

    def affine_subspace_coreset(self, dataset: np.ndarray, w: np.ndarray = None, eps: float = 1 / 3):
        assert dataset.ndim == 2 and w.ndim == 1 and eps > 0
        assert len(w) == len(dataset)
        if w is None:
            w = np.ones(len(dataset))
        W = np.sum(w)
        muA = np.average(dataset, weights=w, axis=0)
        B = np.einsum('ij,i->ij', dataset - muA, np.sqrt(w))
        Sp, delta, _ = self.subspace_coreset(B, eps)
        m = len(Sp)
        S = np.tile(muA, (m, 1)) + np.sqrt(m / W) * np.concatenate((Sp, -Sp), axis=0)
        return S, delta, np.ones(len(S)) * W / (2 * m)

    def subspace_dim_reduction_kclustering(self, dataset: np.ndarray, eps: float = 0.1, alpha: float = 1):
        assert dataset.ndim == 2 and 0 < eps <= 1 / 3 and alpha >= 1
        m = self.k * (self.j + 1) + math.ceil(72 * self.k * (self.j + 1) / eps ** 2) - 1
        n, d = dataset.shape
        if d <= m or n <= m:
            return dataset
        (u, s, vh) = scipy.linalg.svd(dataset)
        vhr = vh[:m, :]
        sr = s[:m]
        C = np.diag(sr) @ vhr

        return C

    def streaming_kmeans(self, data: np.ndarray, eps: float = 1 / 3, delta: float = 0.05):
        return 0


class BaseTrace:
    """

    """
    trace_cnt = 0

    class InfBufferWarning(RuntimeWarning):
        pass

    def __init__(self, *, app_method: str, motion_predictor, **kwargs):
        """
        :param app_method: how to store appearance feature
        :param motion_predictor:
        :param kwargs:
        """
        self.id = BaseTrace.trace_cnt
        self.cls_id = None
        self.shape = None
        self.disappear_agl = None
        self.dt = kwargs.setdefault('dt', 1 / 30)
        BaseTrace.trace_cnt += 1
        self.history: list[dict] = []
        self.feature_method = app_method
        # TODO: define get_motion_predictor function
        self.mp: MotionPredictor = motion_predictor(**kwargs)
        assert self.feature_method.casefold() in ['current', 'bank', 'ema', 'coreset', 'none']
        self.app_bank: list | _Queue
        if self.feature_method.casefold() == 'bank':
            self.bank_size = kwargs.setdefault('bank_size', 100)
            self.app_bank = _Queue(length=self.bank_size)
        elif self.feature_method.casefold() == 'none':
            self.app_bank = None
        else:
            self.app_bank = []
            if self.feature_method.casefold() == 'ema':
                self.alpha = kwargs.setdefault('alpha', 0.9)
            elif self.feature_method.casefold() == 'coreset':
                k = kwargs.setdefault('coreset_k', 3)
                self.coreset = Coreset(j=0, k=k)
            # Do nothing for `current`

        # self.trace_state = 'uninitialized'
        # set lifetime
        # > 0: positive lifetime, count minus 1 after each frame if not been associated
        # = 0: inactive trace, do not perform association
        # < 0: infinite lifetime
        self.lifetime = kwargs.setdefault('track_buffer', -1)
        if self.lifetime < 0:
            warnings.warn(
                message='Infinite lifespan has been assigned to a trace, which may cause many false positives.',
                category=BaseTrace.InfBufferWarning)
        # If we do not add 1, trace with lifetime == 1 will be dead immediately after initializing.
        self.ttl = self.lifetime + 1 if self.lifetime >= 0 else self.lifetime

    def dump(self, mode='w+', output_path=os.getcwd()):
        if os.path.isdir(output_path) or os.path.basename(output_path).count('.') == 0:
            output_path = os.path.join(output_path, f'{self.id}.txt')
        x = np.ones((len(self.history), 9), dtype=float)
        x[:, 1] = int(self.id)
        for (i, v) in enumerate(self.history):
            x[i, 0] = v['frame_id']
            x[i, 2:6] = v['ltwh']
        with open(output_path, mode=mode, newline='') as out_f:
            writer = csv.writer(out_f)
            for line in x:
                line = line.tolist()
                for int_idx in {0, 1, 6, 7, 8}:
                    line[int_idx] = int(line[int_idx])
                writer.writerow(line)

    @property
    def xywh(self):
        return self.mp.obs_estimate()

    @property
    def ltwh(self):
        xywh = self.xywh
        assert xywh.shape == (4,)
        ltwh = xywh.copy()
        ltwh[:2] -= ltwh[2:] / 2
        return ltwh

    @property
    def on_edge(self) -> bool:
        # x-y-w-h
        obs = self.mp.obs_estimate()
        x, y, w, h = obs
        left, top, right, bottom = (x - w / 2, y - h / 2, x + w / 2, y + h / 2)
        return left <= 0 or top <= 0 or right >= self.shape[0] or bottom >= self.shape[1]

    def initialize(self, detection: Detection, **kwargs):
        self.cls_id = detection.cls_id
        self.shape = detection.img_shape
        det_xywh = detection.loc
        # state variable: x-y-asp-h-Psi-psi_s-v-a-v_asp-v_h-v_Psi-v_psi_s
        state_value = [
            det_xywh[0],  # x
            det_xywh[1],  # y
            det_xywh[2] / det_xywh[3],  # a
            det_xywh[3],  # h
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
        ]
        state_std = [
            5,
            5,
            0.1,
            5,
            np.pi / 18,
            np.pi / 18,
            5 * 2 / self.dt,
            5 * 2 ** 2 / self.dt ** 2,
            0.1 / self.dt,
            1 / self.dt,
            np.pi / (36 * self.dt),
            np.pi / (36 * self.dt)
        ]
        self.mp.initialize(sys_v=state_value, sys_cov=np.diag(np.square(state_std)))

    def update(self, detection: Detection):
        assert detection.cls_id == self.cls_id
        assert self.shape == detection.img_shape
        # self.trace_state = 'active'
        current_frame = detection.frame_id

        # compensate out of bound detections
        if len(self.history) > 0 and any(detection.on_edge().values()):
            frame_of_history = [h['frame_id'] for h in self.history]
            frame_of_history.sort(reverse=True)
            frame_of_history = frame_of_history[:25]
            ah = []
            for h in self.history:
                if h['frame_id'] in frame_of_history:
                    ltah = h['ltwh']
                    ltah[2] /= ltah[3]
                    ah.append(ltah[2:])
            avg_ah = np.mean(ah, axis=0).tolist()
            detection.compensate_loc(avg_ah)
        # update location & size
        self.mp.update(obs_v=detection.loc)
        # update appearance
        if self.feature_method.casefold() != 'none':
            assert detection.appearance is not None
        if self.feature_method.casefold() == 'current':
            self.app_bank = [detection.appearance]
        elif self.feature_method.casefold() == 'bank':
            self.app_bank.enqueue(detection.appearance)
        elif self.feature_method.casefold() == 'ema':
            if len(self.app_bank) == 0:
                self.app_bank.append(detection.appearance)
            else:
                for _idx in range(len(self.app_bank[0])):
                    self.app_bank[0][_idx] = (self.alpha * self.app_bank[0][_idx] +
                                              (1 - self.alpha) * detection.appearance[_idx])
        elif self.feature_method.casefold() == 'coreset':
            self.app_bank = self.coreset.streaming_kmeans(detection.appearance)

        info_dict = {
            'frame_id'  : current_frame,
            'ltwh'      : self.ltwh,
            'loc_state' : self.mp.estimate(),
            'appearance': self.app_bank
        }
        self.history.append(info_dict)
        # only reset ttl when associating
        self.ttl = self.lifetime + 1 if self.lifetime >= 0 else self.lifetime

    def after_each_frame(self):
        #
        self.ttl -= 1
        # save disappear angle
        # Be advised, the figure coordinate system is left-handed.
        if self.on_edge:
            x_coordinate = self.ltwh[0] - self.shape[0] / 2
            y_coordinate = self.shape[1] / 2 - self.ltwh[1]
            self.disappear_agl = np.arctan2(y_coordinate, x_coordinate)
        else:
            self.disappear_agl = None


class MatchingObjective:
    """
    Objective when performing data association.
    Example:
        name: IoU
        maximize: True
        function: cython_bbox.bbox_overlaps
    """

    def __init__(self, name: str, maximize: bool, function: collections.abc.Callable):
        self.name = name
        self.maximize = maximize
        self.function = function

    def __call__(self, detections: collections.abc.Collection[Detection],
                 traces: collections.abc.Collection[BaseTrace],
                 **kwargs):
        return self.function(detections, traces, **kwargs)

def iou_float(a, b):
    len_a = len(a)
    len_b = len(b)
    area_a = [w * h for (w, h) in zip(a[:, 2], a[:, 3])]
    area_b = [w * h for (w, h) in zip(b[:, 2], b[:, 3])]
    iou = np.zeros((len_a, len_b), dtype=float)
    for ia in range(len_a):
        for ib in range(len_b):
            left = max([a[ia, 0], b[ib, 0]])
            top = max([a[ia, 1], b[ib, 1]])
            right = min([a[ia, 2], b[ib, 2]])
            bottom = min([a[ia, 3], b[ib, 3]])
            if left < right and top < bottom:
                area_overlap = (right - left) * (bottom - top)
                iou[ia, ib] = area_overlap / (area_a[ia] + area_b[ib] - area_overlap)
    return iou


def iou_augmented(detections: collections.abc.Collection[Detection],
                  traces: collections.abc.Collection[BaseTrace],
                  **kwargs):
    """
    params:
    detections: list of multiple detections
    traces: list of multiple traces 
    ntip: i.e. New Trace Iou Parameter, Offset for new trace inference based on IoU
    ntlp: i.e. New Trace Location Predictor, gives the likelihood that a target at a position, ignore size
    false_positive_coffs
    """
    det_loc = np.array([det.loc[:4] for det in detections])
    tr_loc = np.array(tr.ltwh for tr in traces)
    n = len(detections)
    m = len(traces)
    iou = iou_float(tr_loc, det_loc)
    # assign iou utility for new traces.
    # Possible preference:
    # * low IoU with all traces;
    # detection's aspect that obeys aspect dist;
    # detection's size that obeys size dist;
    # * detection's loc that obeys loc dist
    new_trace_iou_param = kwargs.setdefault('ntip', 1.0)
    new_trace_loc_predictor = kwargs.setdefault('ntlp', None)
    try:
        fpc = kwargs['false_positive_coffs']['iou']
    except KeyError:
        fpc = 0.5
    if iou.size != 0:  # Have some traces to compare, shall be distant
        new_trace_iou_utility = (np.ones(n) * new_trace_iou_param - np.max(iou, axis=0))[None, ...]
    elif not isinstance(new_trace_loc_predictor, collections.abc.Callable):
        # ah-ooh, no trace to compare with and no loc cue, cannot distinguish new trace and false positive by location
        new_trace_iou_utility = np.ones((1, n)) * fpc
    else:
        # associate based on loc, so assign 1 to iou params
        new_trace_iou_utility = np.ones((1, n))

    if not isinstance(new_trace_loc_predictor, collections.abc.Callable):
        new_trace_loc_utility = np.ones(n)[None, ...]
    else:
        xy = det_loc[:, :2] + det_loc[:, 2:4] / 2
        new_trace_loc_utility = np.array([new_trace_loc_predictor(loc) for loc in xy])[None, ...]
    new_trace_utility = new_trace_iou_utility * new_trace_loc_utility

    # assign iou utility for false positives.
    false_positive_utility = np.ones((1, n)) * fpc

    iou = np.concatenate((iou, new_trace_utility, false_positive_utility), axis=0)
    return iou


def conf_augmented(detections: collections.abc.Collection[Detection],
                   traces: collections.abc.Collection[BaseTrace],
                   **kwargs):
    conf = [det.conf for det in detections]
    conf = np.tile(conf, (len(traces) + 1, 1))
    try:
        fpc = kwargs['false_positive_coffs']['conf']
    except KeyError:
        fpc = 0.5
    conf = np.concatenate((conf, np.ones((1, len(detections))) * fpc))

    return conf


def app_augmented(detections: collections.abc.Collection[Detection],
                  traces: collections.abc.Collection[BaseTrace],
                  **kwargs):
    # Each detection has a single app feature vector.
    # Each trace has either:
    # a single app feature vector (for `ema` and `current`)
    # multiple app feature vector (for `bank` and `coreset)
    # none app feature vector (for `none`), but in this condition should not associate based on app.
    m = len(traces)
    n = len(detections)
    app = np.zeros((m + 2, n))
    det_app = [det.appearance for det in detections]
    tr_app = [tr.app_bank for tr in traces]
    try:
        fpc = kwargs['false_positive_coffs']['app']
    except KeyError:
        fpc = 0.5
    if not all(tr_app):  # all not None
        raise ValueError('If appearance is not recorded in trace, association based on appearance cannot be performed.')
    for idx_tr in range(m):
        for idx_det in range(n):
            # scipy.spatial.distance.cdist(..., 'cosine') returning from 0 to 2, thus the distance is divided by 2
            if isinstance(tr_app[idx_tr], list):
                app[idx_tr, idx_det] = scipy.spatial.distance.cdist([det_app[idx_det]], tr_app[idx_tr],
                                                                    'cosine').min() / 2
            else:  # Queue
                app[idx_tr, idx_det] = scipy.spatial.distance.cdist([det_app[idx_det]], list(tr_app[idx_tr]),
                                                                    'cosine').min() / 2

    # assign appearance utility for new traces.
    # low similarity with existing traces (if any).
    # If there is no trace, do not associate based on app, i.e. the same with false positive.
    if m == 0:
        app[m, :] = fpc
    else:
        new_trace_app_param = kwargs.setdefault('ntap', 1.23)
        app[m, :] = new_trace_app_param - np.max(app[:m, :], axis=0)

    # assign appearance utility for false positives
    app[m + 1, :] = fpc

    return app

def get_recursive_dict(d: collections.abc.Mapping) -> dict:
    ret = d.copy()
    for k in d:
        if isinstance(d[k], collections.abc.Mapping):
            ret |= get_recursive_dict(d[k])

    return ret

class ExpConfig(collections.abc.Mapping):
    def __init__(self, yml_path):
        with open(yml_path, 'r') as yml_file:
            self.yml_content = yaml.load(yml_file, Loader=yaml.CLoader)
        self.extended_content = get_recursive_dict(self.yml_content)
    
    def __getitem__(self, name):
        return self.extended_content[name]

    def __iter__(self):
        return iter(self.extended_content)

    def __len__(self):
        return len(self.extended_content)


class ColonDataset(Dataset):
    def __init__(self, data_dir, annotation_file, dataset_type='test', transform=None, public_detector: bool=False):
        self.data_dir = data_dir
        self.ann_dir = annotation_file
        self.dataset_type = dataset_type
        self.public_detector = public_detector
        # self.input_dim =
        self.transform = transform
        abs_ann_path = os.path.abspath(os.path.join(data_dir, annotation_file))
        self.coco = COCO(annotation_file=abs_ann_path)
        self.img_ids = self.coco.getImgIds()
        self.cls_ids = self.coco.getCatIds()
        self.cls_ids.sort()
        # 1st key: video_id
        # 2nd key: frame_id
        self.img_ids = sorted(self.img_ids, key=lambda img_id: self.coco.imgs[img_id]['frame_id'])
        self.img_ids = sorted(self.img_ids, key=lambda img_id: self.coco.imgs[img_id]['video_id'])

    def __len__(self):
        return len(self.img_ids)

    def __getitem__(self, item):
        # get RGB image(numpy.ndarray) and other information about this pic.
        img_id = self.img_ids[item]
        img_info = self.coco.imgs[img_id]
        vid_id = img_info['video_id']
        vid_idx = list(filter(lambda x : self.coco.dataset['videos'][x]['id'] == vid_id,
                              range(len(self.coco.dataset['videos']))))[0]
        img_height = self.coco.dataset['videos'][vid_idx]['height']
        img_width = self.coco.dataset['videos'][vid_idx]['width']
        img_path = os.path.join(self.data_dir, img_info['file_name'])
        img_path = os.path.abspath(img_path)
        if not self.public_detector:
            img_content = np.array(Image.open(img_path).convert('RGB'), dtype=np.uint8)
        else:
            img_content = None
        img_frame_id = img_info['frame_id']
        img_video_id = img_info['video_id']
        other_info = [img_height, img_width, img_frame_id, img_video_id, img_path]
        anno_ret = []
        if self.dataset_type == 'train':
            annos = self.coco.imgToAnns[ img_id]
            for anno in annos:
                bbox = anno['bbox']
                cls_id = anno['category_id']
                if 'group_id' in anno:
                    trace_id = anno['group_id']
                elif 'instance_id' in anno:
                    trace_id = anno['instance_id']
                elif 'track_id' in anno:
                    trace_id = anno['track_id']
                else:
                    raise KeyError("group id or instance id should be provided")
                one_bbox = bbox[:]
                one_bbox.append(cls_id)
                one_bbox.append(trace_id)
                anno_ret.append(one_bbox)

        if self.transform is not None and not self.public_detector:
            img_content = self.transform(img_content)
        return img_content, other_info, anno_ret


class MO2Tracker:
    def __init__(self, tracker_cfg):
        self.trace_list: list[BaseTrace] = []
        self.fpcs_dict = {k: v for (k,v) in zip(
            tracker_cfg['features'],
            tracker_cfg['false positive coffs']
        )}
        self.objectives: list[MatchingObjective] = []  # list of matching objectives
        self.pf_selection: list[collections.abc.Callable] = []  # PF selection strategy

    def update(self, detections: collections.abc.Collection[Detection],
               predictor, **kwargs):
        class_set = set()
        if len(detections) == 0:
            return 
        for det in detections:
            class_set.add(det.cls_id)
        for class_id in class_set:
            current_dets = [det for det in detections if det.cls_id == class_id]
            current_trs = [tr for tr in self.trace_list if tr.cls_id == class_id and tr.ttl != 0]
            utility_matrix_list = []
            for obj in self.objectives:
                utility_matrix_list.append(
                    obj(current_dets, current_trs, 
                    false_positive_coffs=self.fpcs_dict,
                    ntac=1, # TODO:edit
                    ntip=1, # TODO:edit
                    ntlp=1 # TODO:edit
                    ))


    def predict(self):
        pass

def get_center_from_COCO(COCO_dict: dict):
    center_xy = []
    center_val = []
    ann_xy_imgsize = dict()
    vid_size = dict()
    for v in COCO_dict['videos']:
        vid = v['id']
        size = (v['width'], v['height'])
        vid_size[vid] = size
    imgid_vid = dict()
    for i in COCO_dict['images']:
        iid = i['id']
        vid = i['video_id']
        imgid_vid[iid] = vid
    ann_dict = dict()
    for a in COCO_dict['annotations']:
        bbox = a['bbox']
        xy = [bbox[0] + bbox[2] / 2, bbox[1] + bbox[3] / 2]
        iid = a['image_id']
        vid = imgid_vid[iid]
        img_size = vid_size[vid]
        normalized_xy = [xy[0] / img_size[0], xy[1] / img_size[1]]
        center_xy.append(normalized_xy)
        center_val.append(1)
    center_xy = np.concatenate((center_xy, np.random.random((len(center_xy), 2))), axis=0)
    center_val = np.concatenate((center_val,np.ones(len(center_val))),axis=0)

    return center_xy, center_val



class ReIDModel:
    def __init__(self, reid_model_cfg):
        if reid_model_cfg['onnx model path'] is None or not os.path.isfile(reid_model_cfg['onnx model path']):
            self.model = None
            return
        self.model = onnxruntime.InferenceSession(reid_model_cfg['onnx model path'],
                                                  providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
        self.input_name = self.model.get_inputs()[0].name
        self.input_size = reid_model_cfg['input size']

    def preprocess(self, image, target_size):
        img = Image.fromarray(image).resize((target_size, target_size), Image.Resampling.BICUBIC)
        img = np.array(img, dtype=np.float32).transpose(2, 0, 1)
        return img

    def get_feature(self, image, bboxes):
        '''
        Get all features of bounding boxes, according to ReID model.
        :param image:
        :param bboxes: left, top, width, height
        :return:
        '''
        if self.model is None:
            return None
        img_embeddings = np.zeros((len(bboxes), 3, self.input_size, self.input_size), dtype=np.float32)
        img_height, img_width = image.shape[:2]
        for idx, bbox in enumerate(bboxes):
            left = round(np.clip(bbox[0], 0, img_width - 1))
            top = round(np.clip(bbox[1], 0, img_height - 1))
            right = round(np.clip(bbox[2] + bbox[0], 0, img_width - 1))
            bottom = round(np.clip(bbox[3] + bbox[1], 0, img_height - 1))
            img_embeddings[idx] = self.preprocess(image[top:bottom, left:right], self.input_size)
        reid_features = self.model.run(None, {self.input_name: img_embeddings})[0]

        return reid_features


def get_multiple_dets(img: np.ndarray, frame_id: int, bboxes, reid_model: ReIDModel, img_width, img_height) -> list[Detection]:
    if len(bboxes) == 0:
        return None
    if reid_model is None:
        appearances = [None] * len(bboxes)
    else:
        appearances = reid_model.get_feature(img, bboxes)
    # return [Detection(bbox[5], frame_id, bbox[:4], conf=bbox[4], appearance=app) for (bbox, app) in
    #         zip(bboxes, appearances)]
    detections = []
    for bbox, app in zip(bboxes, appearances):
        #
        cls_id = bbox[5]  # 取类别 ID
        bbox_coords = bbox[:4]  # 取边界框的前四个元素（left, top, width, height）
        conf = bbox[4]  # 取置信度
        kwargs = {
            'img_shape': [img_width, img_height]
        }
        detection = Detection(cls_id, frame_id, bbox_coords, conf, app, **kwargs)
        detections.append(detection)
    return detections



@logger.catch
def main():
    args = default_parser()
    cfg = ExpConfig(args.exp_cfg)
    logger.info('Config loaded.\n', cfg)
    with open(os.path.join(cfg['dataset path'], cfg['train annotation path'])) as train_ann_f:
        trainset_content = json.load(train_ann_f)
    center, value = get_center_from_COCO(trainset_content)
    loc_predictor = lambda point : scipy.interpolate.griddata(center, value, point, 'cubic')
    if not cfg['public detector']: # slow
        from yoloob.models import load_model
        # Load detection model, modify the following line(s) according to your custom detector
        model = load_model(cfg['config path'], cfg['weight path'], cuda_idx=cfg['cuda device'])
        model.eval()
        logger.info(f'Model in {cfg["config path"]} and checkpoint in {cfg["weight path"]} loaded.\n', model)
    elif cfg['oracle']:
        logger.info('Tracking results are based on ground truth in each video folder.')
    else:
        logger.info('Tracking results are based on detection in each video folder.')
    output_dir = os.path.join(cfg['dir'], 'track_result')
    os.makedirs(output_dir, exist_ok=True)

    # backup configuration file
    shutil.copyfile(args.exp_cfg, os.path.join(cfg['dir'], os.path.basename(args.exp_cfg) + '.backup'))

    track_features = cfg['features']
    objectives = [MatchingObjective(name=f, maximize=True, function=globals()[f+'_augmented']) for f in track_features]

    track = None
    annotation_paths: list = [cfg[k] for k in cfg if k.count('annotation path')]

    match (cfg['data type'].casefold().count('train') * 2 ** 2 +
           cfg['data type'].casefold().count('val')  * 2 ** 1 +
           cfg['data type'].casefold().count('test')  * 2 ** 0):
        case 4:
            annotation_paths = list(filter(lambda name:name.count('train') == 1, annotation_paths))
        case 2:
            annotation_paths = list(filter(lambda name:name.count('val') == 1, annotation_paths))
        case 1:
            annotation_paths = list(filter(lambda name: name.count('test') == 1, annotation_paths))
        case _:
            raise RuntimeError('Unrecognized data type, should be `train`, `val`, or `test`.')

    if len(annotation_paths) != 1:
        raise RuntimeError('Ambiguous annotation file name.')
    annotation_path: str = annotation_paths[0]
    track_dataset = ColonDataset(data_dir=cfg['dataset path'],
                                 annotation_file=annotation_path,
                                 dataset_type=cfg['data type'],
                                 public_detector=(cfg['public detector'] or cfg['oracle']) and cfg['features'].count('app') == 0)
    reid_model = ReIDModel(cfg['appearance'])
    print('Start tracking'.center(50, '='))
    inference_total_time = 0.0
    postproc_total_time = 0.0
    track_total_time = 0.0
    video_trace = {}


    from torch.utils.data import DataLoader, Subset
    # subset = Subset(track_dataset, list(range(27392, len(track_dataset)))) # train_half
    subset = Subset(track_dataset, list(range(81645, len(track_dataset))))  # val_half
    for i, (ori_img, img_info, _) in enumerate(tqdm.tqdm(subset)):
    # for i, (ori_img, img_info, _) in enumerate(tqdm.tqdm(track_dataset)):
        is_first_frame = False
        infer_img_stime = time.time()
        img_height, img_width, img_frame_id, img_video_id, img_path = img_info
        if img_video_id not in video_trace:
            # Do some initializing work here, like fine-tuning hyper-parameters etc.
            BaseTrace.trace_cnt = 0
            is_first_frame = True
            if cfg['format'].casefold().count('colon'):
                # lifespan = np.loadtxt(os.path.join(img_path, '../../', 'lifespan.txt'))
                lifespan = np.loadtxt(os.path.join(os.path.dirname(os.path.dirname(img_path)), 'lifespan.txt'))
            else:
                lifespan = None
            if track is not None:  # i.e. this is not the first time entering this if-condition
                video_trace[previous_img_video_id] = track
            video_trace[img_video_id] = None
            # CVC dataset needs fine-tuning
            track = MO2Tracker(cfg['tracker'])
            seq_file_path = os.path.join(os.path.dirname(img_path), '../seqinfo.ini')
            seq_file_path = os.path.abspath(seq_file_path)
            with open(seq_file_path, 'r') as f:
                seq_content = f.readlines()
            try:
                frame_rate_line = list(filter(lambda x: x.count('frameRate') > 0, seq_content))[0]
                frame_rate = re.search(r'(?<=frameRate=)\d*(\.\d+)*', frame_rate_line).group()
                frame_rate = float(frame_rate)
            except IndexError or ValueError:
                logger.warning('Cannot infer video frame rate from file `seq_info.ini`, use default 30 fps.')
                frame_rate = 30.0
        if cfg['oracle'] or cfg['public detector']:
            if is_first_frame:
                if cfg['oracle']:
                    relative_path = os.path.join('gt', 'gt.txt')
                else:
                    relative_path = os.path.join('det', 'det.txt')
                # det_content = np.loadtxt(os.path.join(img_path, '../../', relative_path), delimiter=',')
                det_content = np.loadtxt(os.path.join(os.path.dirname(os.path.dirname(img_path)), relative_path), delimiter=',')
                if cfg['oracle']:
                    # if 7th column != 1, ignore
                    det_content = det_content[det_content[:, 6] == 1]
                    # format to det.txt
                    det_content[:, 1] = -1
                    det_content = np.concatenate((det_content, np.ones((len(det_content), 1))), 1)
                    det_content[:, -3:] = -1
            if lifespan is None or lifespan[0] <= img_frame_id <= lifespan[1]:
                current_frame_content = det_content[det_content[:, 0] == img_frame_id]
                # bbox_list = [[left, top, width, height, conf, max(0, cls_id)]
                #              for (cls_id, left, top, width, height, conf) in
                #              zip(current_frame_content[:, 1:7]) if width >= 1 and height >= 1]
                bbox_list = []
                for row in current_frame_content:
                    cls_id, left, top, width, height, conf = row[1:7]
                    # plot_with_rectangle(ori_img, left, top, width, height)
                    if width >= 1 and height >= 1:
                        max_cls_id = max(0, cls_id)
                        bbox_list.append([left, top, width, height, conf, max_cls_id])
            else:
                bbox_list = []
        else:
            # 用YOLO-OB模型实时检测
            # bbox_list = detect_image(model, ori_img, img_size=cfg['input size'], conf_thres=cfg['conf'], nms_thres=cfg['nms'])
            bbox_list = detect_image(model, ori_img, img_size=cfg['detector']['input size'], conf_thres=cfg['conf'], nms_thres=cfg['nms'])
            infer_img_etime = time.time()
            impossible_det = set()
            for bbox_idx, bbox in enumerate(bbox_list):
                left = min(bbox[0], bbox[2])
                right = max(bbox[0], bbox[2])
                top = min(bbox[1], bbox[3])
                bottom = max(bbox[1], bbox[3])
                if left >= img_width or top >= img_height:
                    impossible_det.add(bbox_idx)
                if abs(left - right) < 1 or abs(top - bottom) < 1:
                    impossible_det.add(bbox_idx)
                left = np.clip(left, a_min=0, a_max=img_width)
                right = np.clip(right, a_min=0, a_max=img_width)
                top = np.clip(top, a_min=0, a_max=img_height)
                bottom = np.clip(bottom, a_min=0, a_max=img_height)
                width = right - left
                height = bottom - top
                bbox_list[bbox_idx, :4] = [left, top, width, height]
            bbox_list = np.delete(bbox_list, list(impossible_det), axis=0)
        postproc_etime = time.time()
        det_list = get_multiple_dets(ori_img, img_frame_id, bbox_list, reid_model, img_width, img_height)
        if det_list is not None:
            track.update(det_list, predictor=None)
        track_etime = time.time()
        previous_img_video_id = img_video_id

# if __name__ == '__main__':
    # import matplotlib.pyplot as plt

    # N = 2000
    # dt = 0.1
    # t = np.linspace(start=0, stop=10, num=101, endpoint=True)
    # real_x = 2.1 * t ** 2 + 3.7 * t + 0.3
    # real_y = 4 * np.cos(0.6 * t ** 2 + 1 - 2 * t) + 1 * t ** 2 - 3 * t + 1
    # real_asp = 0.1 * t + 0.5 * np.exp(0.01 * t)
    # real_h = 150 - 121.176 * t + 41.205 * t ** 2 - 5.53333 * t ** 3 + 0.25 * t ** 4
    # # plt.subplots(dpi=1000, )
    # # plt.scatter(real_x, real_y, marker='x')
    # # plt.show()
    # real_psi = np.linspace(13, 157, num=101)
    # rng = np.random.default_rng()
    # obs_x = real_x + rng.uniform(-5, 5, size=real_x.shape)
    # obs_y = real_y + rng.uniform(-2, 2, size=real_y.shape)
    # obs_psi = real_psi + rng.uniform(-8, 8, size=real_psi.shape)
    # obs_h = real_h + rng.uniform(-5, 5, size=real_h.shape)
    # obs_w = real_h * real_asp + rng.uniform(-5, 5, size=real_h.shape)


    # def f(x, y, asp, h, psi, psis, v, a, vasp, vh, vpsi, vpsis):
    #     new_x = x + (v * dt + 0.5 * a * dt ** 2) * sp.cos(psis)
    #     new_y = y + (v * dt + 0.5 * a * dt ** 2) * sp.sin(psis)
    #     new_asp = asp + vasp * dt
    #     new_h = h + vh * dt
    #     new_psi = psi + vpsi * dt
    #     new_psis = psis + vpsis * dt
    #     new_v = v + a * dt
    #     new_a = a
    #     new_vasp = vasp
    #     new_vh = vh
    #     new_vpsi = vpsi
    #     new_vpsis = vpsis
    #     return new_x, new_y, new_asp, new_h, new_psi, new_psis, new_v, new_a, new_vasp, new_vh, new_vpsi, new_vpsis


    # def h(x, y, asp, h, psi, psis, v, a, vasp, vh, vpsi, vpsis):
    #     return x, y, h * abs(sp.sin(psi)) + h * asp * abs(sp.cos(psi)), h * abs(
    #         sp.cos(psi)) + h * asp * abs(sp.sin(psi))


    # def pf_f(particles):
    #     assert particles.shape[1] == 12
    #     (x, y, asp, h, psi, psis, v, a, vasp, vh, vpsi, vpsis) = np.hsplit(particles, 12)
    #     new_x = x + (v * dt + 0.5 * a * dt ** 2) * np.cos(psis)
    #     new_y = y + (v * dt + 0.5 * a * dt ** 2) * np.sin(psis)
    #     new_asp = asp + vasp * dt
    #     new_h = h + vh * dt
    #     new_psi = psi + vpsi * dt
    #     new_psis = psis + vpsis * dt
    #     new_v = v + a * dt
    #     return np.hstack((new_x, new_y, new_asp, new_h, new_psi, new_psis, new_v, a, vasp, vh, vpsi, vpsis))


    # def pf_h(particles):
    #     assert particles.shape[1] == 12
    #     (x, y, asp, h, psi, psis, v, a, vasp, vh, vpsi, vpsis) = np.hsplit(particles, 12)
    #     return np.hstack((x, y, h * np.abs(np.sin(psi)) + h * asp * np.abs(np.cos(psi)), h * np.abs(
    #         np.cos(psi)) + h * asp * np.abs(np.sin(psi))))


    # F = np.eye(8)
    # F[:4, 4:] = dt * np.eye(4)
    # H = np.eye(4, 8)

    # Q = np.diag([25, 25, 0.01, 25, (np.pi / 36) ** 2, (np.pi / 36) ** 2, 25, 100, 4, 100, (np.pi / 36) ** 2,
    #              (np.pi / 36) ** 2])
    # R = np.diag([25, 25, 0.16, 25])
    # ekf = ExtendKalmanFilter(sys_f=f, obs_f=h, Q=Q, R=R, )
    # # pf = ParticleFilter(sys_f=pf_f, obs_f=pf_h, Q=Q, R=R, N=N)
    # tt = 0
    # iv = np.array([obs_x[0], obs_y[0], obs_w[0] / obs_h[0], obs_h[0], 0.0, 0, 0, 0, 0, 0, 0, 0])
    # noise = rng.multivariate_normal(mean=np.zeros(12), cov=Q)
    # err = []
    # # err_pf = []
    # ekf.initialize(iv, Q)
    # for i in range(1, len(t)):
    #     tt = t[i]
    #     ekf.predict()
    #     est_prior = ekf.estimate()
    #     ekf.update([obs_x[i], obs_y[i], obs_w[i], obs_h[i]])
    #     est_post = ekf.estimate()
    #     # print(f't={tt},prior={est_prior},post={est_post}')
    #     err.append(np.array(h(*est_post)) - np.array([real_x[i], real_y[i], real_h[i] * real_asp[i], real_h[i]]))
    # # pf.initialize(iv, Q)
    # # # print(f't={tt},state={ekf.estimate()}')
    # # for i in range(1, len(t)):
    # #     tt = t[i]
    # #     pf.predict()
    # #     est_prior_kf = pf.estimate()
    # #     pf.update([obs_x[i], obs_y[i], obs_w[i], obs_h[i]])
    # #     est_post_pf = pf.estimate()
    # #     print(f'step={i}, active particles: {np.count_nonzero(pf.weights >= 0.1/1000)}')
    # #     err_pf.append(np.array(h(*est_post_pf)) - np.array([real_x[i], real_y[i], real_h[i] * real_asp[i], real_h[i]]))
    # # t3 = time.time()
    # err = np.array(err)
    # # err_pf = np.array(err_pf)
    # print('ekf', np.sum(np.mean(err ** 2, axis=0)))
    # # print('pf:', np.sum(np.mean(err_pf ** 2, axis=0)), f'time={t3-t2}s')
    # # fps = 101 / (t3 - t2)
    # # print(f'fps={fps}')
    # # fig, ax = plt.subplots(2, 2, dpi=1200)
    # # it = 0
    # # for k in range(4):
    # #     ax[0][0].plot(t[it + 1:], err[it:, 0], 'r')
    # #     ax[0][0].plot(t[it + 1:], err_pf[it:, 0], 'b')
    # #     ax[0][1].plot(t[it + 1:], err[it:, 1], 'r')
    # #     ax[0][1].plot(t[it + 1:], err_pf[it:, 1], 'b')
    # #     ax[1][0].plot(t[it + 1:], err[it:, 2], 'r')
    # #     ax[1][0].plot(t[it + 1:], err_pf[it:, 2], 'b')
    # #     ax[1][1].plot(t[it + 1:], err[it:, 3], 'r')
    # #     ax[1][1].plot(t[it + 1:], err_pf[it:, 3], 'b')
    # # fig.show()

if __name__ == '__main__':
    # test 2024年10月29日17:45:36
    main()