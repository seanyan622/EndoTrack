import numpy as np
import os.path
from collections.abc import Sequence

def evaluate_single_det(det_path: str, gt_path: str, metric: Sequence[str] | None):
    # det: [frame_id, -1, left, top, width, height, conf, 1, 1]
    det_content = np.loadtxt(det_path, delimiter=',')
    gt_content = np.loadtxt(gt_path, delimiter=',')

