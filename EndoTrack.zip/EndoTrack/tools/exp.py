import configparser as cp
import pprint
from tabulate import tabulate

class Exp:
    def load_config(self, config_path: str) -> None:
        config = cp.ConfigParser(interpolation=cp.ExtendedInterpolation())
        config.read(config_path)
        self.detector_path = config['detector']['config path']
        self.weight_path = config['detector']['weight path']
        self.public_detector = config.getboolean('detector', 'public detector')
        self.oracle = config.getboolean('detector', 'oracle')
        self.nms = config['detector']['nms']
        self.input_size = config['detector']['input size']
        self.conf = config['detector']['conf']
        self.cuda_idx = config['detector']['cuda device']
        self.data_format = config['dataset']['format']
        self.data_path = config['dataset']['dataset path']
        self.ann_path = config['dataset']['ann path']
        self.dataset_type = config['dataset']['dataset type']
        self.rgb_means = config['dataset']['rgb means']
        self.rgb_std = config['dataset']['rgb std']
        self.features = config['track']['features'].split(',')
        self.predictor = config['track']['predictor']
        self.min_len = config['track']['min_len']
        try:
            # self.gmc = config.getboolean('track', 'gmc')
            self.gmc = config.get('track', 'gmc')
        except cp.NoOptionError:
            self.gmc = None
        self.knee = config.getboolean('track', 'knee')
        self.hi = config.getboolean('track', 'human inspired')
        self.frame_buffer = config['track']['frame_buffer']
        self.exp_name = config['exp']['name']
        self.out_path = config['output']['path']
        self.create_vid = config.getboolean('output', 'create video')
        if 'features_args' in config._sections:
            self.features_args = config._sections['features_args']
        else:
            self.features_args = None
        self.nms = float(self.nms)
        self.input_size = int(self.input_size)
        self.conf = float(self.conf)
        self.cuda_idx = int(self.cuda_idx)
        self.rgb_means = self.rgb_means[1:-1].split(',')
        self.min_len = int(self.min_len)
        self.frame_buffer = int(self.frame_buffer)
        for i in range(len(self.rgb_means)):
            self.rgb_means[i] = float(self.rgb_means[i])
        self.rgb_std = self.rgb_std[1:-1].split(',')
        for i in range(len(self.rgb_std)):
            self.rgb_std[i] = float(self.rgb_std[i])
        delimiter = config.defaults()['delimiter']

    def __str__(self):
        table_header = ["keys", "values"]
        exp_table = [
            (str(k), pprint.pformat(v))
            for k, v in vars(self).items()
        ]
        return tabulate(exp_table, headers=table_header, tablefmt="fancy_grid")

    def __repr__(self):
        return f'Exp: {self.exp_name}'
