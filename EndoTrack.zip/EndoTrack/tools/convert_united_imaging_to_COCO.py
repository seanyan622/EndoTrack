import csv
import glob
import json
import os
import os.path as osp
import re
import argparse

import cv2
from PIL import Image
import numpy as np
import subsetsum as sss
import tqdm

"""
Colon Video Template:
|Original Size|Cropped Size|Clip Position|
|--------------|----------|------------|
|1920x1080|1165x1013|[695:1860, 32:1045]|
|720x576[^1]|519x485|[173:692, 46:531]|
|1280x720|778x677|[463:1241, 21:698]|
|720x576[^2]|398x372|[259:657, 88:460]|
[^1]: Except HMZ
[^2]: HMZ
"""


def generate_det_from_labelme(sub_dataset_path: str) -> None:
    jsons_path = [osp.join(sub_dataset_path, 'json', p) for p in os.listdir(osp.join(sub_dataset_path, 'json')) if
                  p.endswith('.json')]
    # Union Dataset specific, change this with respect to your custom dataset
    # if not osp.exists(osp.join(sub_dataset_path, 'seqinfo.ini')):
    if True:
        img_dir = osp.join(sub_dataset_path, 'images')
        imgs_path = [osp.join(img_dir, p) for p in os.listdir(img_dir) if p.endswith('.jpg')]
        img_cnt = len(imgs_path)
        img_height, img_width = cv2.imread(imgs_path[0]).shape[:2]
        dataset_name = osp.basename(sub_dataset_path)
        with open(osp.join(sub_dataset_path, 'seqinfo.ini'), 'w+') as seq_file:
            seq_file.write('[Sequence]\n')
            seq_file.write(f'name={dataset_name}\n')
            seq_file.write('imDir=images\n')
            seq_file.write('frameRate=25\n')
            seq_file.write(f'seqLength={img_cnt}\n')
            seq_file.write(f'imWidth={img_width}\n')
            seq_file.write(f'imHeight={img_height}\n')
            seq_file.write(f'imExt=.jpg\n')
    real_name = [p for p in os.listdir(sub_dataset_path) if p.endswith('.txt')]
    real_idx = list(filter(lambda x: re.search(r'[A-Z]+(?=\.txt)', x) is not None, real_name))
    if len(real_idx) > 1:
        raise FileExistsError(
            f"At most one explict text file can exists to describe video's real name, but found {len(real_idx)}")
    elif len(real_idx) == 1:
        real_name = real_idx[0]
    else:
        real_name = None
    with open(osp.join(sub_dataset_path, 'seqinfo.ini'), 'r') as seq_file:
        for row in seq_file.readlines():
            if row.count('name'):
                video_name = re.search(r'Colon-[0-9]+', row).group()
            elif row.count('imDir'):
                im_dir = re.search(r'(?<==).+', row).group()
                im_dir = re.sub('^[ ]*', '', im_dir)
            elif row.count('imWidth'):
                img_width = int(re.search(r'[0-9]+', row).group())
            elif row.count('imHeight'):
                img_height = int(re.search(r'[0-9]+', row).group())
            elif row.count('imExt'):
                im_ext = re.search(r'\.[a-zA-Z0-9]+', row).group()
    match (img_width, img_height):
        case (1165, 1013):
            left_offset = 695
            top_offset = 32
        case (778, 677):
            left_offset = 463
            top_offset = 21
        case (398, 372):
            left_offset = 259
            top_offset = 88
        case (519, 485):
            left_offset = 173
            top_offset = 46
        case _:
            left_offset = 0
            top_offset = 0
            print(f'WARNING: Video size not in template, no clip is performed on images and annotations.')
    gt_content = []
    det_content = []
    for json_path in tqdm.tqdm(jsons_path):
        frame_id = int(re.search(r'[0-9]+(?=\.json)', osp.basename(json_path)).group())
        with open(json_path, 'r') as json_file:
            json_content = json.load(json_file)
        for shape in json_content['shapes']:
            group_id = shape['group_id']
            points = np.array(shape['points'])
            left = np.min(points[:, 0]) - left_offset
            right = np.max(points[:, 0]) - left_offset
            top = np.min(points[:, 1]) - top_offset
            bottom = np.max(points[:, 1]) - top_offset
            left = float(np.clip(left, a_min=0, a_max=img_width - 1))
            right = float(np.clip(right, a_min=0, a_max=img_width - 1))
            top = float(np.clip(top, a_min=0, a_max=img_height - 1))
            bottom = float(np.clip(bottom, a_min=0, a_max=img_height - 1))
            width = right - left
            height = bottom - top
            gt_content.append([
                frame_id,
                group_id,
                round(left, 6),
                round(top, 6),
                round(width, 6),
                round(height, 6),
                1,
                1,
                1
            ])
            det_content.append([
                frame_id,
                -1,
                round(left, 6),
                round(top, 6),
                round(width, 6),
                round(height, 6),
                '1.0',
                -1,
                -1,
                -1
            ])
    gt_path = osp.join(sub_dataset_path, 'gt', 'gt.txt')
    det_path = osp.join(sub_dataset_path, 'det', 'det.txt')
    os.makedirs(osp.dirname(gt_path), exist_ok=True)
    os.makedirs(osp.dirname(det_path), exist_ok=True)
    with open(gt_path, 'w+') as gt_file:
        writer = csv.writer(gt_file, lineterminator='\n')
        writer.writerows(gt_content)
    with open(det_path, 'w+') as det_file:
        writer = csv.writer(det_file, lineterminator='\n')
        writer.writerows(det_content)


def generate_COCO_from_labelme(dataset_path: str, output_path: str, ignore_multi_class: bool = False) -> None:
    img_list = []
    ann_list = []
    cat_list = []
    vid_list = []
    os.makedirs(output_path, exist_ok=True)
    for dataset_type in ['train', 'test']:
        for sub_dataset_name in os.listdir(osp.join(dataset_path, dataset_type)):
            sub_dataset_path = osp.join(dataset_path, dataset_type, sub_dataset_name)
            if not osp.isdir(sub_dataset_path):
                continue
            real_name = [p for p in os.listdir(sub_dataset_path) if p.endswith('.txt')]
            real_idx = list(filter(lambda x: re.search(r'[A-Z]+(?=\.txt)', x) is not None, real_name))
            if len(real_idx) > 1:
                raise FileExistsError(
                    f"At most one explict text file can exists to describe video's real name, but found {len(real_idx)}")
            elif len(real_idx) == 1:
                real_name = real_idx[0]
            else:
                real_name = None
            with open(osp.join(sub_dataset_path, 'seqinfo.ini'), 'r') as seq_file:
                for row in seq_file.readlines():
                    if row.count('name'):
                        video_name = re.search(r'Colon-[0-9]+', row).group()
                    if row.count('imDir'):
                        im_dir = re.search(r'(?<==).+', row).group()
                        im_dir = re.sub('^[ ]*', '', im_dir)
                    if row.count("frameRate"):
                        frame_rate = float(re.search(r'[0-9]+', row).group())
                    if row.count('imWidth'):
                        img_width = int(re.search(r'[0-9]+', row).group())
                    if row.count('imHeight'):
                        img_height = int(re.search(r'[0-9]+', row).group())
                    if row.count('imExt'):
                        im_ext = re.search(r'\.[a-zA-Z0-9]+', row).group()
            vid_id = len(vid_list)
            vid_list.append({
                "id"     : vid_id,
                "name"   : video_name,
                "fps"    : frame_rate,
                "width"  : img_width,
                "height" : img_height,
                "seq_dir": sub_dataset_path.replace('\\', '/')
            })
            match (img_width, img_height):
                case (1165, 1013):
                    left_offset = 695
                    top_offset = 32
                case (778, 677):
                    left_offset = 463
                    top_offset = 21
                case (398, 372):
                    left_offset = 259
                    top_offset = 88
                case (519, 485):
                    left_offset = 173
                    top_offset = 46
                case _:
                    left_offset = 0
                    top_offset = 0
                    print(f'WARNING: Video size not in template, no clip is performed on images and annotations.')
            frame2id_dict = {}
            json_dir = osp.join(sub_dataset_path, 'json')
            img_dir = osp.join(sub_dataset_path, im_dir)
            jsons_path = [osp.join(json_dir, p) for p in os.listdir(json_dir) if p.endswith('.json')]
            imgs_path = [osp.join(img_dir, p) for p in os.listdir(img_dir) if p.endswith(im_ext)]
            for img_path in tqdm.tqdm(imgs_path):
                img_path = osp.abspath(img_path)
                img_id = len(img_list)
                frame_id = re.search(f'[0-9]+(?={im_ext})', osp.basename(img_path)).group()
                frame_id = int(frame_id)
                file_name = osp.relpath(img_path, dataset_path)
                if os.name == 'nt':
                    file_name = file_name.replace('\\', '/')
                frame2id_dict[frame_id] = img_id
                img_list.append({
                    "id"       : img_id,
                    "frame_id" : frame_id,
                    "video_id" : vid_id,
                    "file_name": file_name  #
                })
            for json_path in tqdm.tqdm(jsons_path):
                with open(json_path, 'r') as json_file:
                    json_content = json.load(json_file)
                frame_id = int(re.search(r'[0-9]+(?=\.json)', osp.basename(json_path)).group())
                corr_img_id = frame2id_dict[frame_id]
                for shape in json_content['shapes']:
                    ann_id = len(ann_list)
                    if shape['group_id'] is None:
                        raise ValueError(f'{json_path} is incorrect')
                    group_id = int(shape['group_id'])
                    points = np.array(shape['points'])
                    label = shape['label'].casefold()
                    if label not in [l['name'] for l in cat_list] and not ignore_multi_class:
                        cat_id = len(cat_list)
                        cat_list.append({
                            "id"  : cat_id,
                            "name": label
                        })
                        label_id = cat_id
                    elif not ignore_multi_class:
                        label_id = list(filter(lambda x: x['name'] == label, cat_list))
                        label_id = label_id[0]['id']
                    elif len(cat_list) == 0:
                        cat_list.append({
                            "id"  : 0,
                            "name": 'polyp'
                        })
                        label_id = 0
                    else:
                        label_id = 0
                    left = np.min(points[:, 0]) - left_offset
                    right = np.max(points[:, 0]) - left_offset
                    top = np.min(points[:, 1]) - top_offset
                    bottom = np.max(points[:, 1]) - top_offset
                    left = float(np.clip(left, a_min=0, a_max=img_width - 1))
                    right = float(np.clip(right, a_min=0, a_max=img_width - 1))
                    top = float(np.clip(top, a_min=0, a_max=img_height - 1))
                    bottom = float(np.clip(bottom, a_min=0, a_max=img_height - 1))
                    width = right - left
                    height = bottom - top
                    bbox = [left, top, width, height]
                    ann_list.append({
                        "id"         : ann_id,
                        "category_id": label_id,
                        "image_id"   : corr_img_id,
                        "track_id"   : group_id,
                        "bbox"       : bbox,
                        "conf"       : 1.0,
                        "iscrowd"    : 0,
                        "area"       : float(width * height)
                    })
        dataset_info_content = {
            "images"     : img_list,
            "annotations": ann_list,
            "categories" : cat_list,
            "videos"     : vid_list
        }
        if dataset_type == 'train':
            with open(osp.join(output_path, 'train.json'), 'w+') as train_file:
                json.dump(dataset_info_content, train_file)
        else:
            with open(osp.join(output_path, 'test.json'), 'w+') as test_file:
                json.dump(dataset_info_content, test_file)
    with open(osp.join(output_path, 'train.json'), 'r') as train_file:
        train_content = json.load(train_file)
    video_list = train_content['videos']
    img_in_vid = [0] * len(video_list)
    for img in train_content['images']:
        idx = int(np.nonzero(np.array([video['id'] for video in video_list]) == img['video_id'])[0])
        img_in_vid[idx] += 1
    for i in range(len(train_content['images']) // 2, -1, -1):
        if sss.has_solution(img_in_vid, i):
            solution = sss.solutions(img_in_vid, i)
            solution = next(solution)
            break
    train_half_vid = []
    val_half_vid = []
    for i in range(len(video_list)):
        if i in solution:
            train_half_vid.append(video_list[i])
        else:
            val_half_vid.append(video_list[i])
    train_half_vid_id = [vid['id'] for vid in train_half_vid]
    val_half_vid_id = [vid['id'] for vid in val_half_vid]
    train_half_img = [img for img in train_content['images'] if img['video_id'] in train_half_vid_id]
    val_half_img = [img for img in train_content['images'] if img['video_id'] in val_half_vid_id]
    train_half_img_id = [img['id'] for img in train_half_img]
    val_half_img_id = [img['id'] for img in val_half_img]
    train_half_ann = [ann for ann in train_content['annotations'] if
                      ann['image_id'] in train_half_img_id]
    val_half_ann = [ann for ann in train_content['annotations'] if
                    ann['image_id'] in val_half_img_id]
    train_half_content = {
        "images"     : train_half_img,
        "annotations": train_half_ann,
        "videos"     : train_half_vid,
        "categories" : train_content['categories']
    }
    val_half_content = {
        "images"     : val_half_img,
        "annotations": val_half_ann,
        "videos"     : val_half_vid,
        "categories" : train_content['categories']
    }
    with open(osp.join(output_path, 'train_half.json'), 'w+') as train_half_file:
        json.dump(train_half_content, train_half_file)
    with open(osp.join(output_path, 'val_half.json'), 'w+') as val_half_file:
        json.dump(val_half_content, val_half_file)


def combine_COCO_jsons(output_path, *args):
    json_file_cnt = len(args)
    assert json_file_cnt > 0
    jsons_content = []
    for i in range(len(args)):
        with open(args[i], 'r') as file:
            jsons_content.append(json.load(file))
    imgs_cnt = []
    anns_cnt = []
    vids_cnt = []
    cats_cnt = []
    for json_content in jsons_content:
        imgs_cnt.append(len(json_content['images']))
        anns_cnt.append(len(json_content['annotations']))
        vids_cnt.append(len(json_content['videos']))
        cats_cnt.append(len(json_content['categories']))
    imgs_cumsum = np.cumsum(imgs_cnt).tolist()
    anns_cumsum = np.cumsum(anns_cnt).tolist()
    vids_cumsum = np.cumsum(vids_cnt).tolist()
    cats_set = set()
    cats_list = []
    for json_content in jsons_content:
        for i in range(len(json_content['categories'])):
            if json_content['categories'][i]['name'] not in cats_set:
                cats_set.add(json_content['categories'][i]['name'])
    for idx, name in enumerate(list(cats_set)):
        cats_list.append({
            "id"  : idx,
            "name": name
        })
    for i, json_content in enumerate(jsons_content):
        for vid_idx in range(len(json_content['videos'])):
            jsons_content[i]['videos'][vid_idx]['id'] += vids_cumsum[i - 1]
        for img_idx in range(len(json_content['images'])):
            jsons_content[i]['images'][img_idx]['id'] += imgs_cumsum[i - 1]
            jsons_content[i]['images'][img_idx]['video_id'] += vids_cumsum[i - 1]
        for ann_idx in range(len(json_content['annotations'])):
            cat_id = jsons_content[i]['annotations'][ann_idx]['category_id']
            cat_name = list(filter(lambda x: x['id'] == cat_id, cats_list))
            cat_id = cat_name[0]['id']
            jsons_content[i]['annotations'][ann_idx]['id'] += anns_cumsum[i - 1]
            jsons_content[i]['annotations'][ann_idx]['category_id'] = cat_id
            jsons_content[i]['annotations'][ann_idx]['image_id'] += imgs_cumsum[i - 1]
    vid_list = []
    ann_list = []
    img_list = []
    for i in range(json_file_cnt):
        vid_list.extend(jsons_content[i]['videos'])
        img_list.extend(jsons_content[i]['images'])
        ann_list.extend(jsons_content[i]['annotations'])
    total_json_content = {
        "images"     : img_list,
        "annotations": ann_list,
        "categories" : cats_list,
        "videos"     : vid_list
    }
    with open(output_path, 'w+') as file:
        json.dump(total_json_content, file)


def generate_reid(dataset_path: str, output_path: str, test_percentage: float = 80):
    os.makedirs(output_path, exist_ok=True)
    os.makedirs(os.path.join(output_path, 'bounding_box_test'), exist_ok=True)
    os.makedirs(os.path.join(output_path, 'bounding_box_train'), exist_ok=True)
    os.makedirs(os.path.join(output_path, 'query'), exist_ok=True)
    bbox_dict = {}
    obj_id = 0
    rng = np.random.default_rng()
    dataset_type = 'train'
    for dataset_name in os.listdir(os.path.join(dataset_path, dataset_type)):
        # for MOT17 only
        if not dataset_name.endswith('SDP'):
            continue
        # for MOT17 only
        sub_dataset_path = os.path.join(dataset_path, dataset_type, dataset_name)
        bboxes = np.loadtxt(os.path.join(sub_dataset_path, 'gt', 'gt.txt'), delimiter=',', dtype=float)
        bboxes = bboxes[bboxes[:, 6] == 1, :]
        obj_set = set(bboxes[:, 1].astype(int).tolist())
        for obj in obj_set:
            bbox_dict[(sub_dataset_path, obj)] = (bboxes[bboxes[:, 1] == obj, :], obj_id)
            obj_id += 1
    obj_cnt = np.zeros(len(bbox_dict), dtype=int)
    for key in bbox_dict.keys():
        id = bbox_dict[key][1]
        obj_cnt[id] += len(bbox_dict[key][0])
    obj_cnt_total = obj_cnt.sum()
    test_cnt = 0
    for test_cnt in range(round(obj_cnt_total * test_percentage / 100), -1, -1):
        if sss.has_solution(obj_cnt.tolist(), test_cnt):
            split_plan = next(sss.solutions(obj_cnt, test_cnt))
            break
    if test_cnt == 0:
        raise ValueError("Cannot split test dataset and training dataset")
    for key in bbox_dict.keys():
        dataset_path, obj = key
        obj_id = bbox_dict[key][1]
        bboxes = bbox_dict[key][0]
        print(f'Processing {os.path.basename(dataset_path)}, object {obj_id}')
        if obj_id in split_plan:
            data_path = os.path.join(output_path, 'bounding_box_test')
            random_idx = rng.choice(range(len(bboxes)))
            bbox = bboxes[random_idx]
            frame_id = int(bbox[0])
            ltwh = bbox[2:6]
            img_path = os.path.join(dataset_path, 'img1', f'{frame_id:0>6}.jpg')
            img = cv2.imread(img_path)
            h, w = img.shape[:2]
            top = round(np.clip(ltwh[1], 0, h))
            left = round(np.clip(ltwh[0], 0, w))
            right = round(np.clip(ltwh[0] + ltwh[2], 0, w))
            bottom = round(np.clip(ltwh[1] + ltwh[3], 0, h))
            embedding = img[top:bottom+1, left:right+1, :]
            if embedding.size == 0:
                raise ValueError(img_path, left, top, right, bottom)
            # img = Image.open(img_path)
            # embedding = img.crop((left, top, right, bottom))
            embedding_path = os.path.join(output_path, 'query', f'{obj_id:0>4}_c2_f{frame_id:0>7}.jpg')
            cv2.imwrite(embedding_path, embedding)
            # embedding.save(embedding_path)
        else:
            data_path = os.path.join(output_path, 'bounding_box_train')
        for bbox in tqdm.tqdm(bboxes):
            frame_id = int(bbox[0])
            ltwh = bbox[2:6]
            img_path = os.path.join(dataset_path, 'img1', f'{frame_id:0>6}.jpg')
            img = cv2.imread(img_path)
            h, w = img.shape[:2]
            top = round(np.clip(ltwh[1], 0, h))
            left = round(np.clip(ltwh[0], 0, w))
            right = round(np.clip(ltwh[0] + ltwh[2], 0, w))
            bottom = round(np.clip(ltwh[1] + ltwh[3], 0, h))
            embedding = img[top:bottom + 1, left:right + 1, :]
            if embedding.size == 0:
                raise ValueError(img_path, left, top, right, bottom)
            # img = Image.open(img_path)
            # embedding = img.crop((left, top, right, bottom))
            embedding_path = os.path.join(data_path, f'{obj_id:0>4}_c1_f{frame_id:0>7}.jpg')
            cv2.imwrite(embedding_path, embedding)
            # embedding.save(embedding_path)


if __name__ == '__main__':
    # parser = argparse.ArgumentParser()
    # parser.add_argument('task', choices=['labelme2gt', 'labelme2json', 'reid'])
    # parser.add_argument('--dataset_path', required=True, type=str,
    #                     help='Absolute path to dataset, which should have standard COCO format structure.')
    # parser.add_argument('--output_path', type=str, default='', help='path to annotation files')
    # parser.add_argument('--ignore_multi_class', action='store_true',
    #                     help='treat any label as the same, this is useful when some subclass labels are provided')
    # parser.add_argument('--test_percentage', type=float)
    # # generate_COCO_json(r'P:\Union', r'P:\Union\annotations', ignore_multi_class=True)
    # args = parser.parse_args()
    # match args.task:
    #     case 'labelme2gt':
    #         generate_det_from_labelme(args.dataset_path)
    #     case 'labelme2json':
    #         generate_COCO_from_labelme(args.dataset_path, args.ouptut_path, args.ignore_multi_class)
    #     case 'reid':
    #         generate_reid(args.dataset_path, args.ouptut_path, args.test_percentage)
    # generate_reid(r'P:\Union', r'P:\Union\reid', 50)
    combine_COCO_jsons(r"datasets/Union/annotations/all.json", r"datasets/Union/annotations/test.json",
                       r"datasets/Union/annotations/train.json")
    # for subpath in glob.glob('dataset/Union/t*/Colon-??'):
    #     generate_det_from_labelme(subpath)
    # generate_reid(r'P:\MOT17', r'P:\MOT17\reid', 50)
