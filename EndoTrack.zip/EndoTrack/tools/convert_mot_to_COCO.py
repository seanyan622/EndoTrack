import os
import json
import re
import shutil
import typing
import numpy as np
import glob
import tqdm

class_list = ["Pedestrian", "Person on vehicle", "Car", "Bicycle", "Motorbike", "Non motorized vehicle",
              "Static person", "Distractor", "Occluder", "Occluder on the ground", "Occluder full", "Reflection"]


def convert_MOT_to_COCO(dataset_dir: str, dataset_type: str, COCO_json_dir: str):
    os.makedirs(COCO_json_dir, exist_ok=True)
    match dataset_type.casefold():
        # In MOT17, each sub-dataset is named as {seq name}-{detector}. Those videos with same sequence name have
        # identical images in `image` folder. However, their `det.txt`s contain detecting result from different
        # detectors.
        case 'mot17':
            all_sub_dataset = []
            detectors_set = set()
            seqs_set = set()
            all_sub_dataset.extend(glob.glob(os.path.join(dataset_dir, 'train', '*')))
            all_sub_dataset.extend(glob.glob(os.path.join(dataset_dir, 'test', '*')))
            for sub_dataset in all_sub_dataset:
                sub_dataset_name = os.path.basename(sub_dataset)
                seq_name = '-'.join(sub_dataset_name.split('-')[:2])
                detector_name = sub_dataset_name.split('-')[-1]
                detectors_set.add(detector_name)
                seqs_set.add(seq_name)
            for detector_name in detectors_set:
                os.makedirs(os.path.join(COCO_json_dir, detector_name), exist_ok=True)
                for split_type in ['train', 'test']:
                    COCO_dict = {
                        'images'    : [],
                        'categories': [],
                        'videos'    : []
                    }
                    for cls_name in class_list:
                        class_id = len(COCO_dict['categories']) + 1
                        class_dict = {
                            'id'  : class_id,
                            'name': cls_name
                        }
                        COCO_dict['categories'].append(class_dict)
                    if split_type == 'train':
                        COCO_dict['annotations'] = []
                    sub_dataset_list = [p for p in os.listdir(os.path.join(dataset_dir, split_type))
                                        if p.count(detector_name)]
                    for sub_dataset_name in sub_dataset_list:
                        sub_dataset_path = os.path.join(dataset_dir, split_type, sub_dataset_name)
                        with open(os.path.join(sub_dataset_path, 'seqinfo.ini')) as seqinfo_file:
                            for row in seqinfo_file.readlines():
                                if row.startswith('imDir'):
                                    img_folder_name = re.search('(?<==)\S+', row).group()
                                elif row.startswith('frameRate'):
                                    frame_rate = float(re.search('(?<==)\S+', row).group())
                                elif row.startswith('imWidth'):
                                    width = int(re.search('(?<==)\d+', row).group())
                                elif row.startswith('imHeight'):
                                    height = int(re.search('(?<==)\d+', row).group())
                                elif row.startswith('imExt'):
                                    img_ext = re.search('(?<==)\.\w+', row).group()
                        video_id = len(COCO_dict['videos'])
                        video_dict = {
                            'id'     : video_id,
                            'name'   : sub_dataset_name,
                            'fps'    : frame_rate,
                            'width'  : width,
                            'height' : height,
                            'seq_dir': os.path.relpath(sub_dataset_path, dataset_dir).replace('\\', '/')
                        }
                        COCO_dict['videos'].append(video_dict)
                        img_list = glob.glob(os.path.join(sub_dataset_path, img_folder_name, '*' + img_ext))
                        img_list_rel = [os.path.relpath(p, dataset_dir).replace('\\', '/') for p in img_list]
                        for img_relpath in img_list_rel:
                            image_id = len(COCO_dict['images'])
                            frame_id = int(os.path.basename(img_relpath).split('.')[0])
                            image_dict = {
                                'id'       : image_id,
                                'frame_id' : frame_id,
                                'video_id' : video_id,
                                'file_name': img_relpath
                            }
                            COCO_dict['images'].append(image_dict)
                        # if split_type == 'test':
                        #     continue
                        gt_content = np.loadtxt(os.path.join(sub_dataset_path, 'gt', 'gt.txt'), delimiter=',')
                        for one_gt in gt_content:
                            anno_id = len(COCO_dict['annotations'])
                            frame_id = int(one_gt[0])
                            category_id = int(one_gt[7])
                            track_id = int(one_gt[1])
                            bbox = one_gt[2:6].tolist()
                            conf = float(one_gt[6])
                            vis = float(one_gt[8])
                            area = float(bbox[2] * bbox[3])
                            potential_image_list = [img_dict for img_dict in COCO_dict['images'] if
                                                    img_dict['frame_id'] == frame_id and
                                                    img_dict['video_id'] == video_id]
                            assert len(potential_image_list) == 1
                            img_id = potential_image_list[0]['id']
                            annotation_dict = {
                                'id'         : anno_id,
                                'category_id': category_id,
                                'image_id'   : img_id,
                                'track_id'   : track_id,
                                'bbox'       : bbox,
                                'conf'       : conf,
                                'iscrowd'    : 0,
                                'area'       : area,
                                'visibility' : vis
                            }
                            COCO_dict['annotations'].append(annotation_dict)
                    if split_type == 'train':
                        out_path = os.path.join(COCO_json_dir, detector_name, 'val.json')
                    else:
                        out_path = os.path.join(COCO_json_dir, detector_name, 'test.json')
                    with open(out_path, 'w+') as out_file:
                        json.dump(COCO_dict, out_file)
        case 'mot16':
            all_sub_dataset = []
            seqs_set = set()
            all_sub_dataset.extend(glob.glob(os.path.join(dataset_dir, 'train', '*')))
            all_sub_dataset.extend(glob.glob(os.path.join(dataset_dir, 'test', '*')))
            for sub_dataset in all_sub_dataset:
                seq_name = os.path.basename(sub_dataset)
                seqs_set.add(seq_name)
            for split_type in ['test', 'train']:
                COCO_dict = {
                    'images'    : [],
                    'categories': [],
                    'videos'    : [],
                    'annotations': []
                }
                for cls_name in class_list:
                    class_id = len(COCO_dict['categories']) + 1
                    class_dict = {
                        'id'  : class_id,
                        'name': cls_name
                    }
                    COCO_dict['categories'].append(class_dict)
                sub_dataset_list = [p for p in os.listdir(os.path.join(dataset_dir, split_type))]
                for sub_dataset_name in sub_dataset_list:
                    sub_dataset_path = os.path.join(dataset_dir, split_type, sub_dataset_name)
                    with open(os.path.join(sub_dataset_path, 'seqinfo.ini')) as seqinfo_file:
                        for row in seqinfo_file.readlines():
                            if row.startswith('imDir'):
                                img_folder_name = re.search('(?<==)\S+', row).group()
                            elif row.startswith('frameRate'):
                                frame_rate = float(re.search('(?<==)\S+', row).group())
                            elif row.startswith('imWidth'):
                                width = int(re.search('(?<==)\d+', row).group())
                            elif row.startswith('imHeight'):
                                height = int(re.search('(?<==)\d+', row).group())
                            elif row.startswith('imExt'):
                                img_ext = re.search('(?<==)\.\w+', row).group()
                    video_id = len(COCO_dict['videos'])
                    video_dict = {
                        'id'     : video_id,
                        'name'   : sub_dataset_name,
                        'fps'    : frame_rate,
                        'width'  : width,
                        'height' : height,
                        'seq_dir': os.path.relpath(sub_dataset_path, dataset_dir).replace('\\', '/')
                    }
                    COCO_dict['videos'].append(video_dict)
                    img_list = glob.glob(os.path.join(sub_dataset_path, img_folder_name, '*' + img_ext))
                    img_list_rel = [os.path.relpath(p, dataset_dir).replace('\\', '/') for p in img_list]
                    for img_relpath in img_list_rel:
                        image_id = len(COCO_dict['images'])
                        frame_id = int(os.path.basename(img_relpath).split('.')[0])
                        image_dict = {
                            'id'       : image_id,
                            'frame_id' : frame_id,
                            'video_id' : video_id,
                            'file_name': img_relpath
                        }
                        COCO_dict['images'].append(image_dict)
                    # if split_type == 'test':
                    #     continue
                    gt_content = np.loadtxt(os.path.join(sub_dataset_path, 'gt', 'gt.txt'), delimiter=',')
                    for one_gt in gt_content:
                        anno_id = len(COCO_dict['annotations'])
                        frame_id = int(one_gt[0])
                        category_id = int(one_gt[7])
                        track_id = int(one_gt[1])
                        bbox = one_gt[2:6].tolist()
                        conf = float(one_gt[6])
                        vis = float(one_gt[8])
                        area = float(bbox[2] * bbox[3])
                        potential_image_list = [img_dict for img_dict in COCO_dict['images'] if
                                                img_dict['frame_id'] == frame_id and
                                                img_dict['video_id'] == video_id]
                        assert len(potential_image_list) == 1
                        img_id = potential_image_list[0]['id']
                        annotation_dict = {
                            'id'         : anno_id,
                            'category_id': category_id,
                            'image_id'   : img_id,
                            'track_id'   : track_id,
                            'bbox'       : bbox,
                            'conf'       : conf,
                            'iscrowd'    : 0,
                            'area'       : area,
                            'visibility' : vis
                        }
                        COCO_dict['annotations'].append(annotation_dict)
                if split_type == 'train':
                    out_path = os.path.join(COCO_json_dir, 'val.json')
                else:
                    out_path = os.path.join(COCO_json_dir, 'test.json')
                with open(out_path, 'w+') as out_file:
                    json.dump(COCO_dict, out_file)
        case _:
            raise ValueError(f"Type should be either 'mot16' or 'mot17', but got {dataset_type}")


if __name__ == '__main__':
    convert_MOT_to_COCO(r'P:\CVC-ClinicDB', 'mot16', r'P:\CVC-ClinicDB\annotations')
