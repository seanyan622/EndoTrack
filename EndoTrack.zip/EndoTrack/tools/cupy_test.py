import numpy as np
import cupy as cp
import time


if __name__ == '__main__':
    seed = 1234
    n = 10
    rng = np.random.default_rng(seed)
    t1 = time.time()
    for k in range(n):
        x_cpu = rng.random((500, 200))
        # (a, b, c) = np.linalg.svd(x_cpu)
        x_gpu = cp.asarray(x_cpu)
        # (ga, gb, gc) = cp.linalg.svd(x_gpu)
        # s = np.sum(np.square(x_cpu))
        s = cp.sum(cp.square(x_gpu))
    t2 = time.time()
    print((t2-t1)/n)