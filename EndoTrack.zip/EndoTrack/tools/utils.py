import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import tools.evaluate_tracking


def plot_with_rectangle(data, left, top, width, height):
    """
    绘制 numpy 矩阵图像，并在指定位置绘制矩形。

    :param data: numpy 矩阵
    :param left: 矩形左侧的 x 坐标
    :param top: 矩形上侧的 y 坐标
    :param width: 矩形的宽度
    :param height: 矩形的高度
    """
    fig, ax = plt.subplots()
    ax.imshow(data, cmap='viridis', aspect='auto')

    # 创建矩形
    rect = patches.Rectangle((left, top), width, height, linewidth=3, edgecolor='r', facecolor='none')

    # 添加矩形到图中
    ax.add_patch(rect)

    plt.colorbar(ax.imshow(data, cmap='viridis', aspect='auto'))
    plt.show()


# 示例用法
# data = np.random.rand(10, 10)  # 生成一个随机的 numpy 矩阵
# plot_with_rectangle(data, left=2, top=3, width=4, height=5)

