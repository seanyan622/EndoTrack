import argparse
import glob

import motmetrics as mm
from collections import OrderedDict
from pathlib import Path
import os

mm.lap.default_solver = 'lap'


def compare_dataframes(gts, ts):
    accs = []
    names = []
    for k, tsacc in ts.items():
        if k in gts:
            print(f'Comparing {k}...')
            accs.append(mm.utils.compare_to_groundtruth(gts[k], tsacc, 'iou', distth=0.5))
            names.append(k)
        else:
            print('No ground truth for {}, skipping.'.format(k))

    return accs, names


def evaluate(track_file_list, ground_truth_list, eva_result_path):
    gt = OrderedDict([(Path(f).parts[-3], mm.io.loadtxt(f, fmt='mot16', min_confidence=1)) for f in ground_truth_list])
    ts = OrderedDict(
        [(os.path.splitext(Path(f).parts[-1])[0], mm.io.loadtxt(f, fmt='mot16', min_confidence=-1)) for f in
         track_file_list])
    mh = mm.metrics.create()
    accs, names = compare_dataframes(gt, ts)
    metrics = ['recall', 'precision', 'num_unique_objects', 'mostly_tracked',
               'partially_tracked', 'mostly_lost', 'num_false_positives', 'num_misses',
               'num_switches', 'num_fragmentations', 'mota', 'motp', 'num_objects']
    summary = mh.compute_many(accs, names=names, metrics=metrics, generate_overall=True)
    div_dict = {
        'num_objects'       : ['num_false_positives', 'num_misses', 'num_switches', 'num_fragmentations'],
        'num_unique_objects': ['mostly_tracked', 'partially_tracked', 'mostly_lost']}
    for divisor in div_dict:
        for divided in div_dict[divisor]:
            summary[divided] = (summary[divided] / summary[divisor])
    fmt = mh.formatters
    change_fmt_list = ['num_false_positives', 'num_misses', 'num_switches', 'num_fragmentations', 'mostly_tracked',
                       'partially_tracked', 'mostly_lost']
    for k in change_fmt_list:
        fmt[k] = fmt['mota']
    print(mm.io.render_summary(summary, formatters=fmt, namemap=mm.io.motchallenge_metric_names))

    metrics = mm.metrics.motchallenge_metrics + ['num_objects']
    summary = mh.compute_many(accs, names=names, metrics=metrics, generate_overall=True)
    summary.to_csv(os.path.join(eva_result_path, 'metrics_result.csv'), mode='a', index=True)
    print(mm.io.render_summary(summary, formatters=mh.formatters, namemap=mm.io.motchallenge_metric_names))


if __name__ == '__main__':
    # parser = argparse.ArgumentParser()
    # parser.add_argument('--name', '-n', type=str)
    # parser.add_argument('--dataset', '-d', type=str, default='Union')
    # args = parser.parse_args()
    # tr_files = glob.glob(os.path.join('output', args.name, 'track_result', '*.txt'))
    # gt_files = glob.glob(os.path.join('datasets', args.dataset, 't*', '*', 'gt', 'gt.txt'))
    # evaluate(tr_files, gt_files)

    tr_files = glob.glob('/mnt/data1/sean/Project/PolypTracking/MOTracker/output/union_yolov3_det6_kalman_knee_20230913-04/track_result/Colon-12.txt')
    gt_files = glob.glob('/mnt/data1/sean/Union-tracking/train/Colon-12/gt/gt.txt')
    evaluate(tr_files, gt_files, '/mnt/data1/sean/Project/PolypTracking/MOTracker/output/union_yolov3_det6_kalman_knee_20230913-04')
