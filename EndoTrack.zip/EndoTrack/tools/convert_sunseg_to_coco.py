import json
import os
import re
import shutil

import cv2
import numpy as np
import subsetsum as sss
import tqdm

# TODO: use argparse
SUN_SEG_path = r'datasets/SUN-SEG-ori'
output_path = 'datasets/SUN-SEG'
img_file_name = 'img'
img_ext = '.jpg'
test_percentage = 50
COCO_anno_path = os.path.join(SUN_SEG_path, 'annotations')

if __name__ == '__main__':
    anno_dir = os.path.join(SUN_SEG_path, 'annotation_txt')
    # Generate standard MOT structure
    cases_path = [os.path.join(SUN_SEG_path, case_path) for case_path in os.listdir(SUN_SEG_path)
                  if os.path.isdir(os.path.join(SUN_SEG_path, case_path)) and case_path.startswith('case')]
    os.makedirs(os.path.join(output_path, 'train'), exist_ok=True)
    os.makedirs(os.path.join(output_path, 'test'), exist_ok=True)
    # load all images, group by their identity
    imgs_dict = {}
    COCO_dict = {
        'images'     : [],
        'videos'     : [],
        'annotations': [],
        'categories' : []
    }
    COCO_dict['categories'].append({
        'id'  : 0,
        'name': 'polyp'
    })
    train_COCO_dict = {
        'images'     : [],
        'videos'     : [],
        'annotations': [],
        'categories' : COCO_dict['categories']
    }
    test_COCO_dict = {
        'images'     : [],
        'videos'     : [],
        'annotations': [],
        'categories' : COCO_dict['categories']
    }
    polyp_id = int(-1)
    for case_path in cases_path:
        case_name = os.path.basename(case_path)
        case_id = int(re.search('\d+', case_name).group())
        seq_in_vid = set()
        for img_name in os.listdir(case_path):
            if not img_name.endswith(img_ext):
                continue
            seq_name = re.search('\S+(?=_image)', img_name).group()
            if seq_name not in seq_in_vid:
                polyp_id += 1
            seq_in_vid.add(seq_name)
            key = (f'{case_name}_{len(seq_in_vid)}', polyp_id)
            if key not in imgs_dict:
                imgs_dict[key] = [os.path.join(case_path, img_name)]
            else:
                imgs_dict[key].append(os.path.join(case_path, img_name))
    imgs_cnt_of_identity = [0] * len(imgs_dict)
    for identity_name, identity_id in imgs_dict:
        imgs_cnt_of_identity[identity_id] = len(imgs_dict[(identity_name, identity_id)])
    total_img_cnt = sum(imgs_cnt_of_identity)

    # Split the dataset to training set and test set
    solution = None
    for test_img_cnt in range(int(total_img_cnt * test_percentage / 100), -1, -1):
        if sss.has_solution(imgs_cnt_of_identity, test_img_cnt):
            solution = sss.solutions(imgs_cnt_of_identity, test_img_cnt)
            solution = next(solution)
            break
    if solution is None:
        raise ValueError('No dataset split scheme is found, you can adjust the proportion and try again.')

    # For each image sequence: iterate on all image within, then load all annotations,
    # then generate `det/det.txt`, `gt/gt.txt`, and `seqinfo.ini`, balabala
    COCO_video_id = int(0)
    COCO_img_id = int(0)
    COCO_ann_id = int(0)
    train_COCO_video_id = int(0)
    train_COCO_img_id = int(0)
    train_COCO_ann_id = int(0)
    test_COCO_video_id = int(0)
    test_COCO_img_id = int(0)
    test_COCO_ann_id = int(0)
    progress_bar = tqdm.tqdm(total=total_img_cnt)
    for identity_name, identity_id in imgs_dict:
        seq_name = f'seq_{identity_id + 1:0>3}'
        seq_type = 'test' if identity_id in solution else 'train'
        seq_path = os.path.join(output_path, seq_type, seq_name)
        seq_path = seq_path.replace('\\', '/')
        os.makedirs(os.path.join(seq_path, img_file_name), exist_ok=True)
        os.makedirs(os.path.join(seq_path, 'det'), exist_ok=True)
        os.makedirs(os.path.join(seq_path, 'gt'), exist_ok=True)
        seq_imgs_path = imgs_dict[(identity_name, identity_id)].copy()
        seq_imgs_path.sort()
        det_content = []
        gt_content = []
        img_sample = cv2.imread(seq_imgs_path[0])
        img_h, img_w = img_sample.shape[:2]
        case_name = os.path.basename(os.path.dirname(seq_imgs_path[0]))
        COCO_dict['videos'].append({
            'id'     : COCO_video_id,
            'name'   : seq_name,
            'fps'    : 30.0,
            'width'  : img_w,
            'height' : img_h,
            'seq_dir': os.path.relpath(seq_path, output_path).replace('\\', '/')
        })
        if seq_type == 'train':
            train_COCO_dict['videos'].append({
                'id'     : train_COCO_video_id,
                'name'   : seq_name,
                'fps'    : 30.0,
                'width'  : img_w,
                'height' : img_h,
                'seq_dir': os.path.relpath(seq_path, output_path).replace('\\', '/')
            })
        else:
            test_COCO_dict['videos'].append({
                'id'     : test_COCO_video_id,
                'name'   : seq_name,
                'fps'    : 30.0,
                'width'  : img_w,
                'height' : img_h,
                'seq_dir': os.path.relpath(seq_path, output_path).replace('\\', '/')
            })
        with open(os.path.join(anno_dir, case_name + '.txt')) as case_anno_file:
            case_anno = case_anno_file.readlines()
        start_frame_id = 2 << 20
        end_frame_id = -1
        for img_path in seq_imgs_path:
            ori_img_name = os.path.basename(img_path)
            frame_id = int(re.search('(?<=image)\d+', ori_img_name).group())
            if frame_id < start_frame_id:
                start_frame_id = frame_id
            if frame_id > end_frame_id:
                end_frame_id = frame_id
            target_path = os.path.join(output_path, seq_type, seq_name, img_file_name, f'{frame_id:0>8}{img_ext}')
            corr_line_content = list(filter(lambda l: l.startswith(ori_img_name), case_anno))
            if len(corr_line_content) > 0:
                corr_line_content = corr_line_content[0]
            else:
                continue
            bbox_cls = corr_line_content.split(' ')[-1]
            bbox_cls = bbox_cls.split(',')
            bbox_cls = [int(x) for x in bbox_cls]
            bbox = bbox_cls[:4]
            top, left, bottom, right = bbox
            width = right - left
            height = bottom - top
            cls = bbox_cls[-1]
            det_content.append([frame_id, -1, left, top, width, height, 1, -1, -1, -1])
            gt_content.append([frame_id, 1, left, top, width, height, 1, 1, 1])

            COCO_dict['images'].append({
                'id'       : COCO_img_id,
                'frame_id' : frame_id,
                'video_id' : COCO_video_id,
                'file_name': os.path.relpath(target_path, output_path).replace('\\', '/')
            })
            COCO_dict['annotations'].append({
                'id'         : COCO_ann_id,
                'category_id': 0,
                'image_id'   : COCO_img_id,
                'track_id'   : 1,
                'bbox'       : [left, top, width, height],
                'conf'       : 1.0,
                'iscrowd'    : 0,
                'area'       : width * height
            })
            COCO_img_id += 1
            COCO_ann_id += 1
            if seq_type == 'train':
                train_COCO_dict['images'].append({
                    'id'       : train_COCO_img_id,
                    'frame_id' : frame_id,
                    'video_id' : train_COCO_video_id,
                    'file_name': os.path.relpath(target_path, output_path).replace('\\', '/')
                })
                train_COCO_dict['annotations'].append({
                    'id'         : train_COCO_ann_id,
                    'category_id': 0,
                    'image_id'   : train_COCO_img_id,
                    'track_id'   : 1,
                    'bbox'       : [left, top, width, height],
                    'conf'       : 1.0,
                    'iscrowd'    : 0,
                    'area'       : width * height
                })
                train_COCO_img_id += 1
                train_COCO_ann_id += 1
            else:
                test_COCO_dict['images'].append({
                    'id'       : test_COCO_img_id,
                    'frame_id' : frame_id,
                    'video_id' : test_COCO_video_id,
                    'file_name': os.path.relpath(target_path, output_path).replace('\\', '/')
                })
                test_COCO_dict['annotations'].append({
                    'id'         : test_COCO_ann_id,
                    'category_id': 0,
                    'image_id'   : test_COCO_img_id,
                    'track_id'   : 1,
                    'bbox'       : [left, top, width, height],
                    'conf'       : 1.0,
                    'iscrowd'    : 0,
                    'area'       : width * height
                })
                test_COCO_img_id += 1
                test_COCO_ann_id += 1
            shutil.copyfile(img_path, target_path)
            progress_bar.update()
        det_content = np.array(det_content, dtype=int)
        gt_content = np.array(gt_content, dtype=int)
        np.savetxt(os.path.join(seq_path, 'gt', 'gt.txt'),
                   gt_content, delimiter=',', newline='\n', fmt='%f')
        np.savetxt(os.path.join(seq_path, 'det', 'det.txt'),
                   det_content, delimiter=',', newline='\n', fmt='%f')
        with open(os.path.join(seq_path, 'seqinfo.ini'), 'w+') as seq_file:
            seq_file.write('[Sequence]\n')
            seq_file.write(f'name={seq_name}\n')
            seq_file.write(f'imDir={img_file_name}\n')
            seq_file.write('frameRate=30\n')
            seq_file.write(f'seqLength={end_frame_id - start_frame_id + 1}\n')
            seq_file.write(f'imWidth={img_w}\n')
            seq_file.write(f'imHeight={img_h}\n')
            seq_file.write(f'imExt={img_ext}\n')
        COCO_video_id += 1
        if seq_type == 'train':
            train_COCO_video_id += 1
        else:
            test_COCO_video_id += 1
    os.makedirs(COCO_anno_path, exist_ok=True)
    with open(os.path.join(COCO_anno_path, 'all.json'), 'w+') as all_json:
        json.dump(COCO_dict, all_json)
    with open(os.path.join(COCO_anno_path, 'train.json'), 'w+') as train_json:
        json.dump(train_COCO_dict, train_json)
    with open(os.path.join(COCO_anno_path, 'test.json'), 'w+') as test_json:
        json.dump(test_COCO_dict, test_json)
