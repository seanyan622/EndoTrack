import argparse
import re
import sys
import time
import tqdm
import os
import numpy as np
import shutil
import glob

from torch.utils.data import Subset

import tools.evaluate_tracking

import tracker.base_tracker
from data.dataset import ColonDataset
from tools.utils import plot_with_rectangle
from tracker.objective import IoUObjective, ConfObjective, LBPSimilarityObjective, ReIDObjective
from loguru import logger
from tools.exp import Exp
from tracker.MOTracker import MOTracker
from tracker.base_tracker import Detection, BaseTrace
from tools.create_video import create_video


def delete_short_clips(det_mat, min_len):
    if det_mat.size == 0:
        return np.array(det_mat)
    clipped_mat = np.empty((0, det_mat.shape[1]))
    obj_set = set(det_mat[:, 1].tolist())
    obj_list = list(obj_set)
    obj_list.sort()
    for obj in obj_list:
        lines = det_mat[det_mat[:, 1] == obj]
        frames = lines[:, 0]
        argsort = np.argsort(frames)
        frames = frames[argsort]
        lines = lines[argsort]
        continuous_frame_cnt = 0
        last_frame_id = -1
        for idx, (line, frame_id) in enumerate(zip(lines, frames)):
            is_first_frame = idx == 0
            is_last_frame = idx == len(frames) - 1
            if is_first_frame or frame_id == last_frame_id + 1:
                continuous_frame_cnt += 1
            else:
                continuous_frame_cnt = 1
            if continuous_frame_cnt > min_len and (is_last_frame or frames[idx + 1] != frame_id + 1):
                clipped_mat = np.append(clipped_mat, lines[idx - continuous_frame_cnt + 1: idx + 1], axis=0)
            last_frame_id = frame_id
    return clipped_mat


def load_args():
    parser = argparse.ArgumentParser(description='Track using MOTracker')
    parser.add_argument('--exp_cfg', '-c', help='experiment configuration file path', type=str, required=True)
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--gui', action='store_true')
    parser.add_argument('--log', action='store_true')
    args = parser.parse_args()
    return args


@logger.catch
def main():
    # os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    args = load_args()
    if args.gui:
        pass
    exp = Exp()
    exp.load_config(args.exp_cfg)
    if args.log:
        logger.remove()
        save_file = os.path.join(exp.out_path, 'track_log.txt')
    logger.info(f'Configuration loaded.\n{exp}')
    if not exp.public_detector:
        from yoloob.detect import detect_image
        from yoloob.models import load_model
        model = load_model(exp.detector_path, exp.weight_path, cuda_idx=exp.cuda_idx)
        model.eval()
        # logger.info(f'Model and checkpoint loaded.\n{model}')
    result_dir = os.path.join(exp.out_path, 'track_result')
    os.makedirs(result_dir, exist_ok=True)
    shutil.copyfile(args.exp_cfg, os.path.join(exp.out_path, os.path.basename(args.exp_cfg) + '.backup'))

    # matching objectives, i.e. the chosen and best match is the match makes objectives optimized.
    objectives = []
    for i, feature in enumerate(exp.features):
        args_dict = exp.features_args.copy()
        args_dict['pf_coff'] = float([a for a in re.split('[\[\], ]', args_dict['pf_coff']) if len(a) > 0][i])
        args_dict['data_format'] = exp.data_format
        if feature + 'Objective' in globals():
            objectives.append(globals()[feature + 'Objective'](**args_dict))
        else:
            raise NotImplementedError(f'{feature}Objective is not implemented.')

    track = None
    # dataset_name = os.path.basename(exp.data_path)
    annotation_path = exp.ann_path  # designate annotation used in this experiment
    # For online tracking, batch size equals to 1. In this circumstance a dataloader is not requisite.
    eval_dataset = ColonDataset(data_dir=exp.data_path,
                                annotation_file=annotation_path,
                                dataset_type=exp.dataset_type,
                                public_detector=exp.public_detector)
    print("Start tracking".center(50, '-'))
    inference_total_time = 0.0
    postproc_total_time = 0.0
    track_total_time = 0.0
    video_trace = {}
    time_list = []
    # debug
    prev_seq_num = 0
    # TODO: add continuous frame judgement
    # subset = Subset(eval_dataset, list(range(81645, len(eval_dataset))))  # val_half
    start_frame = 6200 # val_half  Colon-11
    end_frame = 6400
    # start_frame = 114685 #114685 # val_half  Colon-11
    # end_frame = 117000
    subset = Subset(eval_dataset, list(range(start_frame, end_frame)))  # val_half
    for i, (ori_img, img_info, _) in enumerate(tqdm.tqdm(subset)):
    # for i, (ori_img, img_info, _) in enumerate(tqdm.tqdm(eval_dataset)):
        is_first_frame = False
        infer_img_start_time = time.time()
        img_height, img_width, img_frame_id, img_video_id, img_path = img_info
        sub_dataset_dir = os.path.abspath(os.path.join(img_path, '../', '../').replace('\\', '/'))
        img_path = img_path.replace('\\', '/')
        if img_video_id not in video_trace:
            BaseTrace.trace_cnt = 0
            is_first_frame = True
            if track is not None:
                video_trace[prev_img_vid_id] = track
            video_trace[img_video_id] = None
            if img_path.count('CVC-ClinicDB'):
                if img_path.count('seq_001')+img_path.count('seq_006')+img_path.count('seq_010')+img_path.count('seq_013')+img_path.count('seq_023')+img_path.count('seq_020')+img_path.count('seq_026'):
                    objectives[1].pf_coff = 0.45
                else:
                    objectives[1].pf_coff = 0.35
            track = MOTracker(objectives=objectives, gmc=exp.gmc)
            seq_file_path = os.path.join(os.path.dirname(img_path), '..', 'seqinfo.ini')
            seq_file_path = os.path.abspath(seq_file_path)
            with open(seq_file_path, 'r') as f:
                seq_content = f.readlines()
            try:
                frame_rate_line = list(filter(lambda x: x.count('frameRate') > 0, seq_content))[0]
                frame_rate = re.search('(?<=frameRate=)\d*(\.\d+)*', frame_rate_line).group()
                frame_rate = float(frame_rate)
            except IndexError or ValueError:
                logger.warning('Cannot infer video frame rate from file `seq_info.ini`, use default 30 fps.')
                frame_rate = 30.0
        # Reading {dataset name}/det/det.txt as detection result. This file can be provided by public detector,
        # or simply for time saving propose when parameters of detector are constants.
        if exp.public_detector:
            if is_first_frame:
                video_name = os.path.basename(os.path.dirname(os.path.dirname(img_path)))
                if exp.oracle:
                    det_path = os.path.abspath(
                        os.path.join(os.path.dirname(img_path), '../', 'gt', 'gt.txt')).replace(
                        '\\', '/')
                    det_content = np.loadtxt(det_path, delimiter=',')
                    det_content = det_content[det_content[:, 6] == 1]
                    det_content[:, 1] = -1
                    det_content = np.concatenate((det_content, np.ones((len(det_content), 1))), 1)
                    det_content[:, -3:] = -1
                else:
                    det_path = os.path.abspath(
                        os.path.join(os.path.dirname(img_path), '../', 'det', 'det.txt')).replace(
                        '\\', '/')
                    det_content = np.loadtxt(det_path, delimiter=',')
                if exp.data_format.casefold() == 'colonoscopy':
                    # lifespan = np.loadtxt(os.path.join(img_path, '../', '../', 'lifespan.txt'))
                    lifespan = np.loadtxt(os.path.join(os.path.dirname(os.path.dirname(img_path)), 'lifespan.txt'))
            current_frame_content = det_content[:, 0] == img_frame_id
            bbox_list = np.zeros((0, 6))
            if exp.data_format.casefold() != 'colonoscopy' or lifespan[0] <= img_frame_id <= lifespan[1]:
                for row_content in det_content[current_frame_content]:
                    cls_id = row_content[1]
                    left = row_content[2]
                    width = row_content[4]
                    top = row_content[3]
                    height = row_content[5]
                    confidence = row_content[6]
                    # plot_with_rectangle(ori_img, left, top, width, height)
                    if width < 1 or height < 1:
                        continue
                    oneline = np.array([[left + width / 2, top + height / 2, width / height, height, confidence, max(0, cls_id)]])
                    bbox_list = np.append(bbox_list, oneline,
                                          axis=0)  # [[center_x, center_y, width, aspect, conf, cls]]
        else:
            bbox_list = detect_image(model, ori_img, img_size=exp.input_size, conf_thres=exp.conf, nms_thres=exp.nms)
            infer_img_end_time = time.time()
            impossible_det = set()
            for bbox_idx, bbox in enumerate(bbox_list):
                left = min(bbox[0], bbox[2])
                right = max(bbox[0], bbox[2])
                top = min(bbox[1], bbox[3])
                bottom = max(bbox[1], bbox[3])

                # 检查边框合法性之前, 就应该对边框进行预处理
                left = np.clip(left, a_min=0, a_max=img_width)
                right = np.clip(right, a_min=0, a_max=img_width)
                top = np.clip(top, a_min=0, a_max=img_height)
                bottom = np.clip(bottom, a_min=0, a_max=img_height)

                if left >= img_width or top >= img_height:
                    impossible_det.add(bbox_idx)
                if abs(left - right) < 1 or abs(top - bottom) < 1:
                    impossible_det.add(bbox_idx)
                # left = np.clip(left, a_min=0, a_max=img_width)
                # right = np.clip(right, a_min=0, a_max=img_width)
                # top = np.clip(top, a_min=0, a_max=img_height)
                # bottom = np.clip(bottom, a_min=0, a_max=img_height)
                width = right - left
                height = bottom - top
                aspect = width / height
                # [left, top, width, height] -> [center x, center y, aspect ratio, height]
                bbox_list[bbox_idx, :4] = [left + width / 2, top + height / 2, aspect, height]
            bbox_list = np.delete(bbox_list, list(impossible_det), axis=0)
        postprocess_end_time = time.time()
        det_list = [Detection(bbox[5], img_frame_id, bbox[4], img_path, loc=(bbox[:4])) for bbox in bbox_list]
        # for trace_idx, trace in enumerate(track.trace_list):  # NOTE: edited
        #     if img_frame_id - trace.last_frame() <= 25:
        #         track.trace_list[trace_idx].predict()
        if len(det_list) > 0:
            # warp = track.gmc.apply(ori_img, det_list)
            for trace_idx, trace in enumerate(track.trace_list):
                if tracker.MOTracker.check_trace(trace, img_width, img_height) and \
                        img_frame_id - trace.last_frame() <= 1:  # NOTE: edited
                    # xyah = trace.features_predictor['loc'].mean[0:4]
                    # xywh = np.array(xyah) * np.array([1, 1, xyah[3], 1])
                    # ltwh = xywh
                    # ltwh[:2] -= ltwh[2:4] / 2
                    #
                    track.trace_list[trace_idx].predict()
            track.update(det_list, predictor=exp.predictor,
                         t=1 / frame_rate, img_width=img_width,
                         img_height=img_height, knee=exp.knee,
                         hi=exp.hi,
                         frame_buffer=exp.frame_buffer)

        track_end_time = time.time()

        prev_img_path = img_path
        prev_img_vid_id = img_video_id
        if exp.public_detector:
            postproc_total_time += postprocess_end_time - infer_img_start_time
            track_total_time += track_end_time - postprocess_end_time
        else:
            inference_total_time += infer_img_end_time - infer_img_start_time
            postproc_total_time += postprocess_end_time - infer_img_end_time
            track_total_time += track_end_time - postprocess_end_time
        time_list.append(track_end_time - infer_img_start_time)
    video_trace[prev_img_vid_id] = track
    video_list = eval_dataset.coco.dataset['videos']
    logger.info(f'Track {len(eval_dataset)} images sequence complete. ')
    logger.info(f'Infer with {inference_total_time / len(eval_dataset) * 1000.0} ms per image.')
    logger.info(f'Post process with {postproc_total_time / len(eval_dataset) * 1000.0} ms per image.')
    logger.info(f'Track with {track_total_time / len(eval_dataset) * 1000.0} ms per image.')
    logger.info(f'Total FPS: {len(eval_dataset) / (postproc_total_time + track_total_time + inference_total_time)}')
    np.savetxt(os.path.join(exp.out_path, 'iter_time.txt'), np.array(time_list)[..., None], newline='\n')
    for vid_dict in video_list:
    # for vid_dict in video_list[:1]:
        vid_name = vid_dict['name']
        vid_id = vid_dict['id']
        track_file_path = os.path.join(result_dir, f'{vid_name}.txt')
        os.makedirs(os.path.dirname(track_file_path), exist_ok=True)
        writing_content = []
        # for trace in video_trace[vid_id].trace_list:
        #     writing_content.extend(trace.loc_history)
        try:
            for trace in video_trace[vid_id].trace_list:
                writing_content.extend(trace.loc_history)
        except Exception as e:
            # 使用中间一小段frames 用于调试
            print(f"An error occurred: {e}")
            break
        writing_content = delete_short_clips(np.array(writing_content), exp.min_len)
        if len(writing_content) > 0:
            np.savetxt(track_file_path, writing_content, delimiter=',', newline='\n',
                       fmt=['%d', '%d', '%f', '%f', '%f', '%f', '%d', '%d', '%d'])
        else:
            np.savetxt(track_file_path, writing_content)
        if exp.create_vid:
            print(f'Creating video for {vid_name}'.center(50, '-'))
            print('track - red bounding box\ngt - green bounding box')
            with open(os.path.join(exp.data_path, vid_dict['seq_dir'], 'seqinfo.ini'), 'r') as seq_file:
                for row in seq_file:
                    if row.count('imDir'):
                        im_dir = re.search(r'(?<==).+', row).group()
                        im_dir = re.sub('^ *', '', im_dir)
            im_dir = os.path.join(exp.data_path, vid_dict['seq_dir'], im_dir)
            create_video(img_dir=im_dir,
                         track_file=track_file_path,
                         gt_file=os.path.join(exp.data_path, vid_dict['seq_dir'], 'gt', 'gt.txt'),
                         output_dir=exp.out_path,
                         start_frame=start_frame,
                         end_frame=end_frame)
    tr_file = glob.glob(os.path.join(exp.out_path, 'track_result',  '*.txt'))
    gt_files = glob.glob(os.path.join(exp.data_path, 't*', '*', 'gt', 'gt.txt'))
    tools.evaluate_tracking.evaluate(tr_file, gt_files, exp.out_path)


if __name__ == '__main__':
    main()
