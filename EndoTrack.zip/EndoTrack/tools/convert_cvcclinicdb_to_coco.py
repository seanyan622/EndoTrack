# DEPRECATED

import csv
import glob
import os.path
import cv2
import re

import numpy as np


def generate_annotations(dataset_path: str, output_path: str):
    assert os.path.isdir(dataset_path)
    os.makedirs(os.path.join(output_path, 'test'), exist_ok=True)
    json_content = {'images': [], 'annotations': [], 'videos': [], 'categories': [
        {
            'id'  : 0,
            'name': 'polyp'
        },
    ]}

    seq_meta = np.loadtxt(
        os.path.join(dataset_path, 'metadata.csv'),
        delimiter=',',
        skiprows=1,
        dtype=str
    )

    json_content = {
        'image': [],
        'videos': [],
        'annotations': [],
        'categories': [{'id': 0, 'name': 'polyp'}]
    }
    seq_set = set()
    img_id = 0
    ann_id = 0
    for line in seq_meta:
        vid = int(line[1])
        img_ext = '.' + os.path.join(dataset_path, line[4]).split('.')[-1]
        if vid not in seq_set:
            seq_set.add(vid)
            # Generate standard MOT folder
            seq_dir = os.path.join(output_path, 'test', f'seq_{vid:0<3}')
            os.makedirs(os.path.join(seq_dir, 'images'), exist_ok=True)
            os.makedirs(os.path.join(seq_dir, 'gt'), exist_ok=True)
            os.makedirs(os.path.join(seq_dir, 'det'), exist_ok=True)

            # Get video info
            img = cv2.imread(os.path.join(dataset_path, line[4]))
            json_content['videos'].append({
                'id': vid,
                'fps': 30,
                'height': img.shape[0],
                'width': img.shape[1],
                'name': f'seq_{vid:0<3}',
                'seq_dir': os.path.join(output_path, 'test', f'seq_{vid:0<3}').replace('\\', '/')
            })

            # Generate `seqinfo.ini`
            with open(os.path.join(seq_dir, 'seqinfo.ini'), 'w+') as seqinfo_file:
                seqinfo_content = [
                    '[Sequence]\n',
                    f'name=seq_{vid:0>3}\n',
                    'imDir=images\n',
                    'frameRate=30\n',
                    f'seqLength={len(glob.glob(os.path.join(dataset_path, os.path.dirname(line[4]), f"*{img_ext}")))}\n',
                    f'imWidth={img.shape[1]}\n',
                    f'imHeight={img.shape[0]}\n',
                    f'imExt={img_ext}\n'
                ]
                seqinfo_file.writelines(seqinfo_content)
        frame_id = int(re.search('\d+', os.path.basename(line[4])).group())
        json_content['images'].append({
            'id': img_id,
            'frame_id': frame_id,
            'video_id': vid,
            'file_name': os.path.join('test', f'seq_{vid:0>3}', 'images', f'{frame_id:0>8}{img_ext}').replace('\\', '/'),
        })
        gt_img = cv2.imread(os.path.join(dataset_path, line[5]))[..., 0]  # size: H x W
        (bbox_cnt, labeled_gt, bboxes, COM_xy) = cv2.connectedComponentsWithStats(gt_img, connectivity=8)
        bboxes = bboxes[np.argsort(bboxes[:, -1])]
        bboxes = bboxes[:-1]
        for bbox in bboxes:
            left, top, width, height = bbox[:4]
            right = left + width
            bottom = top + height
            left, top, right, bottom = map(int, [left, top, right, bottom])
            json_content['annotations'].append({
                'id': ann_id,
                'category_id': 0,
                'image_id': img_id,
                'track_id': 1
            })
            ann_id += 1
        img_id += 1



if __name__ == '__main__':
    generate_annotations()
