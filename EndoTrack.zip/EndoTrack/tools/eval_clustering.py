import glob

import numpy as np
import scipy
import tqdm
import matplotlib.pyplot as plt
import sklearn.manifold
from sklearn.cluster import KMeans
from sklearn import metrics
import time
import onnxruntime as ort
import cv2

from tools.coreset import Coreset

min_img_cnt = 50


def eval_clustering(dataset: np.ndarray, j: int, eps: float, k: int):
    ori_dataset = dataset.copy()
    plt.subplots(dpi=600)
    tsne = sklearn.manifold.TSNE(perplexity=20)
    coreset = Coreset.generate(dataset, j, eps)
    tsne_result = tsne.fit_transform(ori_dataset)
    plt.scatter(tsne_result[:, 0], tsne_result[:, 1], c='r')
    tsne_result = tsne.fit_transform(coreset)
    plt.scatter(tsne_result[:, 0], tsne_result[:, 1], c='b')
    plt.show()
    time1 = time.time()
    kmeansO = KMeans(n_clusters=k, random_state=42, n_init=10).fit(ori_dataset)
    ori_kmeans_time = time.time() - time1
    labelO = kmeansO.labels_
    time2 = time.time()
    kmeansC = KMeans(n_clusters=k, random_state=42, n_init=10).fit(coreset)
    coreset_kmeans_time = time.time() - time2
    labelC = kmeansC.labels_
    print(f'timeO: {ori_kmeans_time}')
    print(f'timeC: {coreset_kmeans_time}')
    for f in [metrics.silhouette_score, metrics.calinski_harabasz_score]:
        print(f'{f.__name__} of ori: {f(ori_dataset, labelO)}')
        print(f'{f.__name__} of coreset: {f(coreset, labelC)}')


def eval_appearance(n):
    flist = glob.glob(f'P:\\Union\\reid\\bounding_box_*\\{n:0>4}_*.jpg')
    if len(flist) < min_img_cnt:
        raise ValueError('Too few images')
    model = ort.InferenceSession('P:/MOTracker/output/reid-model/polyp-ce-adasp-db.onnx',
                                 providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
    input_name = model.get_inputs()[0].name
    app_data = []
    for f in tqdm.tqdm(flist):
        img = cv2.imread(f)[:, :, ::-1]
        img = cv2.resize(img, (256, 256), interpolation=cv2.INTER_CUBIC)
        img = img.astype("float32").transpose(2, 0, 1)[np.newaxis]  # (b, c, h, w)
        app = model.run(None, {input_name: img})[0][0]
        app_data.append(app)
    app_data = np.array(app_data)
    app_data = scipy.cluster.eval_clustering(app_data, 2, 0.01, 3)


if __name__ == '__main__':
    # rng = np.random.default_rng()
    # x = rng.random((10000, 1000))
    # eval_clustering(x, 2, 0.1, 3)
    eval_appearance(42)
