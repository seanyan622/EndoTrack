import cv2
import os
import numpy as np
import tqdm
import glob
import datetime


def create_video(img_dir: str, track_file: str, gt_file: str, output_dir: str, start_frame: int, end_frame: int):
    assert os.path.isdir(img_dir)
    assert os.path.isfile(track_file)
    assert os.path.isfile(gt_file)
    assert os.path.isdir(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    gt_file = gt_file.replace('\\', '/')
    track_file = track_file.replace('\\', '/')
    output_dir = output_dir.replace('\\', '/')
    video_path = os.path.join(output_dir, f'{gt_file.split("/")[-3]}_{track_file.split("/")[-3]}.avi')
    img_paths = glob.glob(os.path.join(img_dir, '*.jpg'))
    img_paths.sort()
    frame = cv2.imread(img_paths[0])
    height, width, layers = frame.shape
    fourcc = cv2.VideoWriter_fourcc(*'DIVX')
    video = cv2.VideoWriter(video_path, fourcc, 25, (width, height))
    track_content = np.loadtxt(track_file, delimiter=',')
    gt_content = np.loadtxt(gt_file, delimiter=',')
    gt_content = gt_content[gt_content[:, -3] == 1, :]
    # for img_path in tqdm.tqdm(img_paths):
    for img_path in tqdm.tqdm(img_paths[start_frame : end_frame]):
        frame_id = int(os.path.basename(img_path).split('.')[0])
        track_rows = track_content[np.asarray(track_content[:, 0] == frame_id).nonzero()]
        gt_rows = gt_content[np.asarray(gt_content[:, 0] == frame_id).nonzero()]
        img_content = cv2.imread(img_path)
        for track_row in track_rows:
            bbox = track_row[2:6]
            pt1 = (round(bbox[0]), round(bbox[1]))
            pt2 = (round(bbox[0] + bbox[2]), round(bbox[1] + bbox[3]))
            text_pt = (pt1[0], pt2[1] - 3)
            group_id = int(track_row[1])
            cv2.rectangle(img_content, pt1, pt2, (0, 0, 255), 2)
            cv2.putText(img_content, str(group_id), text_pt, cv2.FONT_HERSHEY_PLAIN, 1, (0, 0, 255))
        for gt_row in gt_rows:
            bbox = gt_row[2:6]
            pt1 = (round(bbox[0]), round(bbox[1]))
            pt2 = (round(bbox[0] + bbox[2]), round(bbox[1] + bbox[3]))
            text_pt = (pt1[0], pt2[1] - 3)
            group_id = int(gt_row[1])
            cv2.rectangle(img_content, pt1, pt2, (0, 255, 0), 2)
            cv2.putText(img_content, str(group_id), text_pt, cv2.FONT_HERSHEY_PLAIN, 1, (0, 255, 0), 2)
        video.write(img_content)
    video.release()


if __name__ == '__main__':
    # create_video(r"datasets/MOT17/train/MOT17-02-FRCNN/img1",
    #              r"output/mot17_yolox_nms05_hi_kalman_20240115-02/track_result/MOT17-02-FRCNN.txt",
    #              # r"datasets/Union/train/Colon-11/gt/gt.txt",
    #              r"datasets/MOT17/train/MOT17-02-FRCNN/gt/gt.txt",
    #              r"P:\Union\temp_output")

    create_video(r"datasets/Union-tracking/train/Colon-11/images",
                 r"output/union_yolov3_det6_kalman_knee_20230913-04/track_result/Colon-11.txt",
                 # r"datasets/Union/train/Colon-11/gt/gt.txt",
                 r"datasets/Union-tracking/train/Colon-11/gt/gt.txt",
                 r"output/union_yolov3_det6_kalman_knee_20230913-04",
                 0, -1)
