import glob
import os.path
import cv2
import onnxruntime
import tqdm

import numpy as np
import matplotlib.pyplot as plt


def iou(b1, b2):
    tl = max(b1[0], b2[0])
    tt = max(b1[1], b2[1])
    tr = min(b1[0] + b1[2], b2[0] + b2[2])
    tb = min(b1[1] + b1[3], b2[1] + b2[3])
    if tl >= tr or tt >= tb:
        return 0
    else:
        a1 = b1[2] * b1[3]
        a2 = b2[2] * b2[3]
        ai = (tb - tt) * (tr - tl)
        return ai / (a1 + a2 - ai)


def l2_sim(x1, x2):
    x1 = np.array(x1) / np.linalg.norm(x1, 2)
    x2 = np.array(x2) / np.linalg.norm(x2, 2)
    return np.linalg.norm(x1 - x2, 2)


def cos_sim(x1, x2):
    inner_p = np.dot(x1, x2)
    norm1 = np.linalg.norm(x1, 2)
    norm2 = np.linalg.norm(x2, 2)
    cos = inner_p / (norm1 * norm2)
    return (cos + 1) / 2


if __name__ == '__main__':
    N = 100000
    M = 100000
    F = 0
    iou_t = 0.5
    intra_sim = []
    inter_sim = []
    fp_sim = []
    onnx_model_path = 'output/reid-model/polyp-ce-adasp.onnx'
    onnx_model = onnxruntime.InferenceSession(onnx_model_path,
                                              providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
    input_size = 256
    rng = np.random.default_rng()
    dataset_dir = 'datasets/Union'
    split_type = 't*'
    seq_list = glob.glob(os.path.join(dataset_dir, split_type, 'Colon-??'))
    bbox_dict = dict()
    seq_obj_dict = dict()
    seq_cnt = len(seq_list)
    for seq in seq_list:
        gt_content = np.loadtxt(os.path.join(seq, 'gt', 'gt.txt'), delimiter=',')
        gt_content = gt_content[gt_content[:, 6] == 1, :]
        obj_list = list(set(gt_content[:, 1].tolist()))
        for obj in obj_list:
            bbox_dict[seq_cnt * seq_list.index(seq) + obj_list.index(obj)] = gt_content[gt_content[:, 1] == obj, :]
            seq_obj_dict[seq_cnt * seq_list.index(seq) + obj_list.index(obj)] = (seq, obj)
    print('total objs: ', len(bbox_dict))
    for i in tqdm.trange(N):
        while True:
            random_id = rng.choice(list(bbox_dict.keys()))
            obj_bboxes = bbox_dict[random_id]
            if len(obj_bboxes) > 1:
                break
        random_i, random_j = rng.choice(range(len(obj_bboxes)), size=2, replace=False)
        bbox1 = obj_bboxes[random_i]
        bbox2 = obj_bboxes[random_j]
        seq_path, _ = seq_obj_dict[random_id]
        features = []
        for bbox in [bbox1, bbox2]:
            frame_id = int(bbox[0])
            left, top, width, height = bbox[2:6]
            right = left + width
            bottom = top + height
            # print(os.path.join(seq_path, 'img1', f'{frame_id:0>6}.jpg'))
            img = cv2.imread(os.path.join(seq_path, 'images', f'{frame_id:0>8}.jpg'))[:, :, ::-1]
            h, w = img.shape[:2]
            left = np.clip(left, 0, w)
            right = np.clip(right, 0, w)
            top = np.clip(top, 0, h)
            bottom = np.clip(bottom, 0, h)
            img_embedding = img[round(top):round(bottom), round(left):round(right), :]
            # if img_embedding.size == 0:
            #     raise ValueError(left, top, right, bottom)
            img_embedding = cv2.resize(img_embedding, (input_size, input_size), interpolation=cv2.INTER_CUBIC)
            img_embedding = img_embedding.astype(np.float32).transpose(2, 0, 1)[np.newaxis]
            features.append(onnx_model.run(None, {onnx_model.get_inputs()[0].name: img_embedding})[0][0])
        # intra_sim.append(
        #     np.linalg.norm(features[0] / np.linalg.norm(features[0]) - features[1] / np.linalg.norm(features[1]), 2))
        intra_sim.append(cos_sim(features[0], features[1]))
    for i in tqdm.trange(M):
        random_id1, random_id2 = rng.choice(list(bbox_dict.keys()), size=2, replace=False)
        bbox1 = rng.choice(bbox_dict[random_id1], axis=0)
        bbox2 = rng.choice(bbox_dict[random_id2], axis=0)
        seq_path1, _ = seq_obj_dict[random_id1]
        seq_path2, _ = seq_obj_dict[random_id2]
        features = []
        for bbox, seq_path in zip([bbox1, bbox2], [seq_path1, seq_path2]):
            frame_id = int(bbox[0])
            left, top, width, height = bbox[2:6]
            right = left + width
            bottom = top + height
            img = cv2.imread(os.path.join(seq_path, 'images', f'{frame_id:0>8}.jpg'))[:, :, ::-1]
            h, w = img.shape[:2]
            left = np.clip(left, 0, w)
            right = np.clip(right, 0, w)
            top = np.clip(top, 0, h)
            bottom = np.clip(bottom, 0, h)
            img_embedding = img[round(top):round(bottom), round(left):round(right), :]
            img_embedding = cv2.resize(img_embedding, (input_size, input_size), interpolation=cv2.INTER_CUBIC)
            img_embedding = img_embedding.astype(np.float32).transpose(2, 0, 1)[np.newaxis]
            features.append(onnx_model.run(None, {onnx_model.get_inputs()[0].name: img_embedding})[0][0])
        # inter_sim.append(np.dot(features[0], features[1]) / np.sqrt(
        #     np.dot(features[0], features[0]) * np.dot(features[1], features[1])))
        inter_sim.append(cos_sim(features[0], features[1]))
    # for i in tqdm.trange(F):
    #     random_id1, random_id2 = rng.choice(list(bbox_dict.keys()), size=2, replace=False)
    #     seq_path1, _ = seq_obj_dict[random_id1]
    #     seq_path2, _ = seq_obj_dict[random_id2]
    #     features = []
    #     bbox1 = rng.choice(bbox_dict[random_id1], axis=0)
    #     bbox2 = rng.choice(bbox_dict[random_id2], axis=0)
    #     frame_id1 = int(bbox1[0])
    #     frame_id2 = int(bbox2[0])
    #     img1 = cv2.imread(os.path.join(seq_path1, 'images', f'{frame_id1:0>8}.jpg'))[:, :, ::-1]
    #     img2 = cv2.imread(os.path.join(seq_path2, 'images', f'{frame_id2:0>8}.jpg'))[:, :, ::-1]
    #     left1, top1, width1, height1 = bbox1[2:6]
    #     right1 = left1 + width1
    #     bottom1 = top1 + height1
    #     h1, w1 = img1.shape[:2]
    #     left1 = np.clip(left1, 0, w1)
    #     right1 = np.clip(right1, 0, w1)
    #     top1 = np.clip(top1, 0, h1)
    #     bottom1 = np.clip(bottom1, 0, h1)
    #     img_embedding1 = img1[round(top1):round(bottom1), round(left1):round(right1), :]
    #     img_embedding1 = cv2.resize(img_embedding1, (input_size, input_size), interpolation=cv2.INTER_CUBIC)
    #     img_embedding1 = img_embedding1.astype(np.float32).transpose(2, 0, 1)[np.newaxis]
    #     features.append(onnx_model.run(None, {onnx_model.get_inputs()[0].name: img_embedding1})[0][0])
    #     h2, w2 = img2.shape[:2]
    #     while True:
    #         left2, right2 = np.sort(rng.random(2) * (w2 - 1))
    #         top2, bottom2 = np.sort(rng.random(2) * (h2 - 1))
    #         iou_vec = np.zeros(len(bbox_dict[random_id2]))
    #         for idx, bx in enumerate(bbox_dict[random_id2]):
    #             iou_vec[idx] = iou(bx, [left2, top2, right2 - left2, bottom2 - top2])
    #         if np.all(iou_vec < iou_t):
    #             break
    #     img_embedding2 = img2[round(top2):round(bottom2), round(left2):round(right2), :]
    #     img_embedding2 = cv2.resize(img_embedding2, (input_size, input_size), interpolation=cv2.INTER_CUBIC)
    #     img_embedding2 = img_embedding2.astype(np.float32).transpose(2, 0, 1)[np.newaxis]
    #     features.append(onnx_model.run(None, {onnx_model.get_inputs()[0].name: img_embedding2})[0][0])
    #     fp_sim.append(
    #         np.linalg.norm(features[0] / np.linalg.norm(features[0]) - features[1] / np.linalg.norm(features[1]), 2))
    np.savez('output/cos_sim', inter_sim, intra_sim)
    fig, ax = plt.subplots(dpi=1200)
    ax.hist(intra_sim, bins=1000, color='b', alpha=0.5, label='intra id similarity', density=True)
    ax.hist(inter_sim, bins=1000, color='r', alpha=0.5, label='inter id similarity', density=True)
    ax.set_xlabel('Cosine Distance')
    ax.set_ylabel('Probability Density')
    ax.set_title('Histogram of Appearance Similarity of Different Objects')
    ax.legend(loc=1)
    # ax.hist(fp_sim, bins=1000, color='g')
    fig.show()
