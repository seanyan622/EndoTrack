import csv
import glob
import os.path

import cv2
import numpy as np
import tqdm


def cal_single_core():
    bgr_table = []
    dataset_set = set()
    # path = r"P:\second"
    # for dataset_name in os.listdir(path):
    #     dataset_path = os.path.join(path, dataset_name)
    #     if not os.path.isdir(dataset_path):
    #         continue
    #     image_dir = os.path.join(dataset_path, 'images')
    #     images_path = [os.path.join(image_dir, p) for p in os.listdir(image_dir) if p.endswith('.jpg')]
    #     print(f"{dataset_name}: \n")
    #     for image_path in tqdm.tqdm(images_path):
    #         img = cv2.imread(image_path)
    #         # img = img[:,:,[2, 1, 0]]
    #         mean = np.mean(img, axis=(0, 1)).tolist()
    #         var = np.var(img, axis=(0, 1)).tolist()
    #         size = img.size
    #         oneline = []
    #         oneline.extend(mean)
    #         oneline.extend(var)
    #         oneline.append(size)
    #         bgr_table.append(oneline)
    path = r"P:\MOT17"
    for s in ['test', 'train']:
        for dataset_name in os.listdir(os.path.join(path, s)):
            dataset_path = os.path.join(path, s, dataset_name)
            if not os.path.isdir(dataset_path):
                continue
            dataset_name2 = dataset_name.split('-')
            dataset_name2 = '-'.join(dataset_name2[:2])
            if dataset_name2 in dataset_set:
                continue
            else:
                dataset_set.add(dataset_name2)
            image_dir = os.path.join(dataset_path, 'img1')
            images_path = [os.path.join(image_dir, p) for p in os.listdir(image_dir) if p.endswith('.jpg')]
            print(f"{dataset_name2}: \n")
            for image_path in tqdm.tqdm(images_path):
                img = cv2.imread(image_path)
                # img = img[:,:,[2, 1, 0]]
                mean = np.mean(img, axis=(0, 1)).tolist()
                var = np.var(img, axis=(0, 1)).tolist()
                size = img.size
                oneline = []
                oneline.extend(mean)
                oneline.extend(var)
                oneline.append(size)
                bgr_table.append(oneline)
    bgr_table = np.array(bgr_table, dtype=float)
    bgr_mean_std = np.average(bgr_table[:, :-1], axis=0, weights=bgr_table[:, -1])
    bgr_mean_std[3:] = np.sqrt(bgr_mean_std[3:])
    bgr_mean_std[:3] = bgr_mean_std[[2, 1, 0]]
    bgr_mean_std[3:] = bgr_mean_std[[5, 4, 3]]
    rgb_mean_std = bgr_mean_std.tolist()
    print(rgb_mean_std)
    with open('output/mot17_rgb_mean_std.txt', 'w+') as file:
        writer = csv.writer(file)
        writer.writerow(rgb_mean_std)


def cal_mean_std(images_path):
    rgb_info = []
    for image_path in images_path:
        img = cv2.imread(image_path)
        mean = np.mean(img, axis=(0, 1)).tolist()
        var = np.var(img, axis=(0, 1)).tolist()
        size = img.size
        oneline = []
        oneline.extend(mean[::-1])
        oneline.extend(var[::-1])
        oneline.append(size)
        rgb_info.append(oneline)
    rgb_info = np.array(rgb_info, dtype=float)
    cnt = np.sum(rgb_info[:, -1])
    rgb_mean_var = np.average(rgb_info[:, :-1], axis=0, weights=rgb_info[:, -1])
    rgb_mean_var = np.append(rgb_mean_var, cnt)
    return rgb_mean_var


def cal_by_multi_core(images_path):
    import multiprocessing as mp
    pool = mp.Pool(mp.cpu_count())
    # images_path = images_path[:800]
    rng = np.random.default_rng()
    rng.shuffle(np.array(images_path))
    core_len = int(np.ceil(len(images_path) / mp.cpu_count()))
    param_dict = []
    for i in range(mp.cpu_count()):
        if i == mp.cpu_count() - 1:
            param_dict.append(images_path[core_len * i:])
        param_dict.append(images_path[core_len * i: core_len * (i + 1)])
    results = [pool.apply_async(cal_mean_std, args=[param]) for param in param_dict]
    results = [p.get() for p in results]
    results = np.array(results)
    print(results)
    mean_std = np.average(results[:, :-1], axis=0, weights=results[:, -1])
    mean_std[3:] = np.sqrt(mean_std[3:])
    with open('output/mf_rgb_mean_std.txt', 'w+') as file:
        writer = csv.writer(file)
        writer.writerow(mean_std)


if __name__ == '__main__':
    # imgs_path = glob.glob(r"P:/Union/train/Colon-??/images/*.jpg")
    # imgs_path.extend(glob.glob(r"P:/Union/test/Colon-??/images/*.jpg"))
    imgs_path = glob.glob(r"P:\download\Datasets\files\*\*.jpg")
    cal_by_multi_core(imgs_path)
