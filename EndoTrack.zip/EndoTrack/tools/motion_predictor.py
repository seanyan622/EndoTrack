import collections.abc

import scipy
import numpy as np
import tqdm
import math
import matplotlib.pyplot as plt
from tracker.base_tracker import Predictor
import scipy.stats

rng = np.random.default_rng()


def x0_func():
    return np.array([[0]])


def kalman(x0_func, F, H,
           state_noise, obs_noise, obs):
    # real_state = [None] * (T + 1)
    # real_obs = [None] * (T + 1)
    # t = 0
    # real_state[0] = state_noise[0, 0]
    # for t in range(1, T+1):
    #     real_state[t] = F @ real_state[t-1] + rng.multivariate_normal(np.zeros(len(state_noise[t])), state_noise[t])
    #     real_obs[t] = H @ real_state[t] + rng.multivariate_normal(np.zeros(len(obs_noise[t])), obs_noise[t])
    T = len(obs) - 1
    t = 0
    mean = []
    cov = []
    posterior_mean = x0_func()
    posterior_cov = state_noise[0]
    mean.append(posterior_mean)
    cov.append(posterior_cov)
    for t in range(1, T + 1):
        # predict
        prior_mean = F * posterior_mean
        prior_cov = F * posterior_cov * F.T + state_noise[t]
        # update
        kalman_gain = prior_cov @ H.T @ np.linalg.inv(H @ prior_cov @ H.T + obs_noise[t])
        mean_upd = prior_mean + kalman_gain @ (obs[t] - H @ prior_mean)
        cov_upd = (np.eye(len(kalman_gain)) - kalman_gain @ H) @ prior_cov
        posterior_mean = mean_upd
        posterior_cov = cov_upd
        mean.append(posterior_mean)
        cov.append(posterior_cov)
    return mean, cov


class pf(Predictor):
    def __init__(self, **kwargs):
        t = kwargs.setdefault('t', 1 / 30)
        n = kwargs.setdefault('N', 50)
        self.dim = 8
        self.observation_dim = 4
        self.F = np.eye(self.dim)
        self.F[:self.observation_dim, self.observation_dim:] = np.eye(self.observation_dim) * t
        self.H = np.eye(self.observation_dim, self.dim)
        diagQ = [10, 10, 0.2, 10, 20, 20, 2, 10]
        diagR = [2, 2, 0.1, 2]
        self.Q = np.diag(np.square(diagQ))
        self.R = np.diag(np.square(diagR))
        self.mean = None
        self.particles = [None] * n
        self.w = [1] * n

    def initialize(self, measurement: np.ndarray):
        assert len(measurement) == self.observation_dim and measurement.ndim == 1
        x00 = np.concatenate((measurement, np.zeros(self.dim - self.observation_dim)), 0)
        self.particles = [x00 + scipy.stats.multivariate_normal(np.zeros(self.dim), self.Q).rvs()
                          for _ in self.particles]
        self.mean = np.mean(np.array(self.particles), 0)

    def predict(self):
        self.particles = [self.F @ p + scipy.stats.multivariate_normal(np.zeros(self.dim), self.Q).rvs()
                          for p in self.particles]
        self.mean = np.mean(np.array(self.particles), 0)

    def update(self, measurement: np.ndarray):
        assert len(measurement) == self.observation_dim and measurement.ndim == 1
        residual = [measurement - self.H @ p for p in self.particles]
        w = [scipy.stats.multivariate_normal(np.zeros(self.observation_dim), self.R).pdf(r) * wi
             for (r, wi) in zip(residual, self.w)]
        self.w = np.array(w) / np.sum(w)
        degeneracy = 1 / np.sum(np.square(self.w)) < 0.5 * len(self.w)
        if degeneracy:
            s_idx = np.random.choice(range(len(self.particles)), len(self.particles),
                                     True, p=w)
            self.w = np.ones_like(self.w)
            self.particles = [self.particles[idx] for idx in s_idx]
        self.mean = np.average(np.array(self.particles), 0, weights=self.w)


if __name__ == '__main__':
    f = np.array([[1]])
    h = np.array([[1]])
    obs = rng.normal(loc=0, scale=1, size=101) + 10 * np.arctan(3 * np.arange(101))
    sn = [np.array([[1]])] * 101
    on = [np.array([[1]])] * 101
    m, c = kalman(x0_func, f, h, sn, on, obs)
    plt.plot(range(101), obs, color='r')
    plt.plot(range(101), np.array(m)[:, 0, 0], color='b')
    plt.show()
