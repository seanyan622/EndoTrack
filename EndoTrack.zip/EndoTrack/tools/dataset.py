import csv
import os
import tqdm
import cv2
import numpy as np
from tracker.objective import LBP, Similarity


def dump_lbp_feature(dataset_dir='../Union/train/', output_dir='output'):
    hists = []
    rng = np.random.default_rng()
    range_start = 0
    os.makedirs(output_dir, exist_ok=True)
    for dataset_name in os.listdir(dataset_dir):
        range_start += round(rng.uniform(100, 200))
        if not dataset_name.casefold().startswith('colon'):
            continue
        img_dir = os.path.join(dataset_dir, dataset_name, 'images')
        gt_path = os.path.join(dataset_dir, dataset_name, 'gt', 'gt.txt')
        gt_content = []
        with open(gt_path, 'r') as gt_file:
            reader = csv.reader(gt_file)
            for row in reader:
                gt_content.append(row)
        lbp = LBP(sample_cnt=8, radius=3)
        for gt in tqdm.tqdm(gt_content):
            frame_id = int(gt[0])
            group_id = int(gt[1]) + range_start
            left = int(gt[2])
            top = int(gt[3])
            bottom = top + int(gt[5])
            right = left + int(gt[4])
            img_path = os.path.join(img_dir, f'{frame_id:0>8}.jpg')
            img = cv2.imread(img_path)
            img_part = img[top:bottom, left:right, ...]
            oneline = [group_id]
            oneline.extend(lbp.compute(img_part, channel='bgr'))
            hists.append(oneline)
    with open(os.path.join(output_dir, 'lbp_feature_8-3.txt'), 'w+') as file:
        writer = csv.writer(file, delimiter=',', lineterminator='\n')
        writer.writerows(hists)


def cmp_indicator(lbp_path):
    lbp_content = np.loadtxt(lbp_path, delimiter=',', dtype=float)
    obj_dict = {}
    for obj in lbp_content:
        if int(obj[0]) not in obj_dict:
            obj_dict[int(obj[0])] = [obj[1:]]
        else:
            obj_dict[int(obj[0])].append(obj[1:])

    indicators = [
        Similarity.js_divergence,
        Similarity.cosine_similarity,
        Similarity.wasserstein_distance,
        Similarity.total_variation_divergence,
    ]
    rng = np.random.default_rng()
    # Same object
    print("====================Same object=======================")
    for indicator in indicators:
        score = []
        for _ in range(10000):
            selected_obj = rng.choice([key for key in obj_dict])
            x1 = rng.choice(obj_dict[selected_obj], replace=False)
            x2 = rng.choice(obj_dict[selected_obj], replace=False)
            score.append(indicator(x1, x2))
        print(f'{indicator.__name__}: {np.mean(score)}')

    # Different object
    print("====================Different object=======================")
    for indicator in indicators:
        score = []
        for _ in range(10000):
            keys = list(obj_dict.keys())
            selected_obj1 = rng.choice(keys, replace=False)
            selected_obj2 = rng.choice(keys, replace=False)
            x1 = rng.choice(obj_dict[selected_obj1])
            x2 = rng.choice(obj_dict[selected_obj2])
            score.append(indicator(x1, x2))
        print(f'{indicator.__name__}: {np.mean(score)}')


if __name__ == '__main__':
    cmp_indicator('output/lbp_feature_8-3.txt')
    # dump_lbp_feature()
