import numpy as np
import matplotlib.pyplot as plt
import scipy


def pareto_sorting(x: np.ndarray, maximize=True):
    assert x.ndim == 2
    n, m = x.shape
    if not maximize:
        x = -x
    dom_ij = np.zeros((n, n), dtype=bool)
    argsort = -1 * np.ones(n, dtype=int)
    sorted_cnt = 0
    k = 0
    for i in range(n):
        dom_ij[i, :] = np.logical_and(np.all(x[i] >= x, axis=1), np.any(x[i] > x, axis=1))
    this_tier_idx = np.where(np.logical_and(np.all(dom_ij == False, axis=1), argsort == -1))
    argsort[this_tier_idx] = k
    sorted_cnt += len(this_tier_idx)
    dom_ij[:, this_tier_idx] = False
    while sorted_cnt < n:
        k += 1
        this_tier_idx = np.where(np.logical_and(np.all(dom_ij == False, axis=1), argsort == -1))
        argsort[this_tier_idx] = k
        dom_ij[:, this_tier_idx] = False
        sorted_cnt += len(this_tier_idx)

    return argsort


if __name__ == '__main__':
    N = 100
    rng = np.random.default_rng(1)
    polor = rng.uniform(low=[0, 0], high=[10, np.pi / 2], size=(N, 2))
    xy = np.c_[polor[:, 0] * np.cos(polor[:, 1]), polor[:, 0] * np.sin(polor[:, 1])]
    sort_idx = pareto_sorting(xy)
    color = []
    for ii, i in enumerate(sort_idx):
        if i >= sort_idx.max() - 2:
            color.append('r')
        else:
            color.append('b')
    color = np.array(color)
    color[[67, 95, 52, 3, 36]] = 'b'
    iilist = np.where(color == 'r')[0]
    print(iilist)
    iilist = np.c_[iilist, xy[iilist]]
    iilist = iilist[np.argsort(iilist[:, 1])]
    # print(iilist)
    spline_data = [xy[i] for i in range(len(color)) if color[i] == 'r']
    spline_data = np.array(spline_data)
    color[[93, 12, 94, 22, 75]] = 'g'
    f = scipy.interpolate.interp1d(spline_data[:, 0], spline_data[:, 1], kind='cubic')
    new_spline_x = np.linspace(start=np.min(spline_data[:, 0]), stop=np.max(spline_data[:, 0]), endpoint=True, num=500)
    new_spline_y = f(new_spline_x)
    plt.subplots(dpi=600)
    plt.scatter(xy[:, 0], xy[:, 1], c=color)
    plt.plot(new_spline_x, new_spline_y, 'g-')
    plt.xlabel('位置相似度', fontdict={'family': 'FangSong'})
    plt.ylabel('外观相似度', fontdict={'family': 'FangSong'})
    plt.arrow(8, 8, 1, 1, width=0.01)
    plt.text(8.3, 8, 'better')
    plt.plot(xy[93, 0], xy[93, 1], 'xk', markersize=10.5)
    plt.show()