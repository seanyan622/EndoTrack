import copy
import math
import random
import typing

import inspyred
import numpy as np
from inspyred import ec
from inspyred.ec import emo
from inspyred.ec.variators.crossovers import crossover
from inspyred.ec.variators.mutators import mutator
import lap

import tracker.objective
import tracker.optimizer
from tracker.base_tracker import Detection, BaseTrace, KalmanFilter, UnscentedKalmanFilter, ParticleFilter, ExtendedKalmanFilter
from tracker.objective import Objective, keep_knee_pop
from tracker.optimizer import Constraint
from tracker.gmc import GMC


class DataAssociation:
    def __init__(self, m, n, constraint: Constraint, objectives: typing.List[typing.Dict]):
        self.dimensions = n
        self.m = m
        self.n = n
        self.constraint = constraint  # TODO: add
        self.maximize = True
        self.objectives = objectives
        for obj in objectives:
            assert obj['orientation'] == 'max'
        self.bounder = ec.DiscreteBounder(self.constraint.bound['integer_domain'])

    # initialize candidate with single objective optimal solution, which could be faster
    def generator(self, random, args) -> typing.List:
        generate_single_optimal = args.setdefault('generate_single_optimal', 0.2)
        if random.random() < generate_single_optimal:
            utilities = args['utilities']
            utility = random.choice(utilities)
            m = utility.shape[0] - 2
            _, _, c = lap.lapjv((1 - utility), extend_cost=True)
            for iv, v in enumerate(c):
                if v == -1:
                    c[iv] = m + np.argmax(utility[m:, iv])
            c = c.tolist()
        else:
            c = [0] * self.n
            unselected_trace = list(range(self.m + 2))
            idxes = np.arange(self.n)
            random.shuffle(idxes)
            for i in idxes:
                c[i] = random.choice(unselected_trace)
                if c[i] < self.m:
                    unselected_trace.remove(c[i])

        return c

    def evaluator(self, candidates, args):
        fitness = []
        for c in candidates:
            if not self.constraint(c):
                f_values = [-1] * len(self.objectives)
            else:
                f_values = []
                decision_mat = np.zeros((self.m + 2, self.n), dtype=float)
                for i, dec in enumerate(c):
                    decision_mat[dec, i] = 1
                for obj in self.objectives:
                    f_values.append(np.sum(obj['func'] * decision_mat))
            fitness.append(emo.Pareto(f_values))

        return fitness

    @staticmethod
    def observer(population, num_generations, num_evaluations, args):
        best = max(population)
        print(f'{num_generations} -- {best.fitness} : {str(best.candidate)}')


@mutator
def flip_trace_and_mutation(rnd, candidate, kwargs):
    flip_rate = kwargs.setdefault('flip_rate', 1.0)
    flip_pair = kwargs.setdefault('flip_pair', 2)
    mutation_rate = kwargs.setdefault('mutation_rate', 0.1)
    mutant = copy.copy(candidate)
    if rnd.random() < flip_rate:
        num_flip_pair = min(len(mutant) // 2, flip_pair)
        flip_dets_idx = rnd.sample(range(len(mutant)), 2 * num_flip_pair)
        flip_sets = np.reshape(flip_dets_idx, (-1, 2))
        for det1, det2 in flip_sets:
            mutant[det1], mutant[det2] = mutant[det2], mutant[det1]
    available_trace = set(range(kwargs['trace_cnt'] + 2))
    for trace in mutant:
        if trace < kwargs['trace_cnt']:
            available_trace.discard(trace)
    for i, trace in enumerate(mutant):
        if rnd.random() < mutation_rate:
            mutant[i] = rnd.choice(list(available_trace))
            if mutant[i] < kwargs['trace_cnt']:
                available_trace.discard(mutant[i])
            available_trace.add(trace)
    return mutant


@crossover
def order_crossover(rnd, mom, dad, args):
    crossover_rate = args.setdefault('crossover_rate', 1.0)
    if rnd.random() < crossover_rate:
        n = len(mom)
        start_loc, end_loc = rnd.sample(range(n + 1), 2)
        if start_loc > end_loc:
            start_loc, end_loc = end_loc, start_loc
        bro = [0] * n
        sis = [0] * n
        bro[start_loc:end_loc] = dad[start_loc:end_loc]
        sis[start_loc:end_loc] = mom[start_loc:end_loc]
        crossover_loc = set(range(start_loc, end_loc))
        non_crossover_loc = set(range(n)) - crossover_loc
        non_crossover_loc = list(non_crossover_loc)
        non_crossover_loc.sort()

        if len(non_crossover_loc) > 0:
            i = 0
            for loc in range(n):
                if loc in non_crossover_loc:
                    sis[non_crossover_loc[i]] = dad[loc]
                    i += 1
            i = 0
            for loc in range(n):
                if loc in non_crossover_loc:
                    bro[non_crossover_loc[i]] = mom[loc]
                    i += 1
        return [bro, sis]
    else:
        return [mom, dad]


class MOTracker:

    def __init__(self, **kwargs):
        self.trace_list = []
        self.current_detection = []  # list of detections/observations
        self.objectives = [kwargs['objectives']] if isinstance(kwargs['objectives'],
                                                               Objective) else kwargs['objectives']  # k objectives
        try:
            self.conf_idx = next(filter(lambda i: isinstance(self.objectives[i], tracker.objective.ConfObjective),
                                        range(len(self.objectives))))
        except StopIteration:
            self.conf_idx = None
        try:
            self.iou_idx = next(filter(lambda i: isinstance(self.objectives[i], tracker.objective.IoUObjective),
                                       range(len(self.objectives))))
        except StopIteration:
            self.iou_idx = None
        try:
            self.reid_idx = next(filter(lambda i: isinstance(self.objectives[i], tracker.objective.ReIDObjective),
                                        range(len(self.objectives))))
        except StopIteration:
            self.reid_idx = None
        try:
            self.lbp_idx = next(
                filter(lambda i: isinstance(self.objectives[i], tracker.objective.LBPSimilarityObjective),
                       range(len(self.objectives))))
        except StopIteration:
            self.lbp_idx = None
        self.gmc = GMC(method='ecc' if kwargs['gmc'] is None else kwargs['gmc'], downscale=1)
        # self.optimizer = kwargs['optimizer']

    def update(self, detections: typing.List[Detection],
               predictor: str, **kwargs):
        class_set = set()
        img_height = kwargs.setdefault('img_height', 1080)
        img_width = kwargs.setdefault('img_width', 1920)
        keep_knee = kwargs.setdefault('knee', False)
        keep_hi = kwargs.setdefault('hi', False)
        frame_buffer = kwargs.setdefault('frame_buffer', 25)
        frame_id = detections[0].frame_id
        for detection in detections:
            class_set.add(detection.class_id)
        for class_id in class_set:
            # deactivate old traces, if appearance feature is robust enough, consider remove this mechanism.
            current_traces = [trace for trace in self.trace_list if
                              trace.class_id == class_id and frame_id - trace.last_frame() <= frame_buffer and
                              check_trace(trace, img_width, img_height)]
            current_detections = [det for det in detections if det.class_id == class_id]
            utilities = [obj(current_traces, current_detections) for obj in self.objectives]  # k-len cost-matrix list
            m = len(current_traces)
            n = len(current_detections)
            opt = tracker.optimizer.Optimizer("GA")
            x_dim = n
            constraints = tracker.optimizer.Constraint(x_dim, trace_cnt=m)
            constraints.add_bound(integer_domain=set(range(m + 2)))
            for obj, utility in zip(self.objectives, utilities):
                opt.add_linear_objective(func=utility, orientation=obj.opt_orientation)
            opt.add_constraint(constraints)
            objs = opt.objectives
            problem = DataAssociation(m, n, constraints, objs)
            problem_size = np.sum([math.perm(m, i) * 2.0 ** (n - i) for i in range(min(m, n) + 1)])
            rand = random.Random()
            rand.seed(2023)
            ea = inspyred.ec.emo.NSGA2(rand)
            # archiver = ec.archivers.best_archiver
            # replacer = ec.replacers.nsga_replacement
            # selector = ec.selectors.tournament_selection
            # ea.variator = [order_crossover,
            #                flip_trace_and_mutation]
            ea.variator = flip_trace_and_mutation
            # ea.terminator = inspyred.ec.terminators.generation_termination
            ea.terminator = inspyred.ec.terminators.no_improvement_termination
            pop_size = 10 * n
            pop_size = np.clip(pop_size, a_min=30, a_max=60).astype(int)
            # pop_size = 10
            max_gen = 10
            # ea.observer = DataAssociation.observer
            final_pop = ea.evolve(
                generator=problem.generator,
                evaluator=problem.evaluator,
                # observer=DataAssociation.observer,
                maximize=problem.maximize,
                pop_size=pop_size,
                max_generations=max_gen,
                bounder=problem.bounder,
                trace_cnt=m,
                utilities=utilities
            )
            if keep_knee:
                final_arc = keep_knee_pop(ea.archive.copy())
            else:
                final_arc = ea.archive
            if keep_hi:
                if m == 0:
                    # If there is no existing track for detections to matching with, simply get the det with
                    # the highest confidence among all.
                    if self.conf_idx is not None:
                        fitness = [f.fitness.values[self.conf_idx] for f in final_arc]
                    else:
                        fitness = [f.fitness.values[self.iou_idx] for f in final_arc]
                    best_designate = final_arc[np.argmax(fitness)].candidate
                else:
                    # When existing tracks, compare their location&size&shape, appearance feature and confidence
                    # in turn.
                    fitness = np.zeros((len(final_arc), len(self.objectives)))
                    obj_list = [o for o in [self.conf_idx, self.reid_idx, self.iou_idx] if o is not None]
                    for i, f in enumerate(final_arc):
                        for j, idx in enumerate(obj_list):
                            fitness[i, j] = f.fitness.values[idx]
                    arglex = np.lexsort(fitness.T)
                    best_designate = final_arc[arglex[-1]].candidate
            else:
                # randomly select one candidate among Pareto Front
                best_designate = rand.choice(final_arc).candidate
            for j in range(n):
                i = best_designate[j]
                if i < m:
                    trace_id = current_traces[i].trace_id
                    trace_idx = \
                        list(filter(lambda _idx: self.trace_list[_idx].trace_id == trace_id,
                                    range(len(self.trace_list))))[0]
                    self.trace_list[trace_idx].update(current_detections[j])
                elif i == m:
                    frame_id = current_detections[j].frame_id
                    pd = globals()[predictor]
                    features_predictor = {
                        'loc': pd(**kwargs)  # edit
                    }
                    new_trace = BaseTrace(features_predictor, measurement=current_detections[j], **kwargs)
                    self.trace_list.append(new_trace)


def check_trace(trace: BaseTrace, width, height):
    xyah = trace.features_predictor['loc'].mean[:4]
    bbox = tracker.base_tracker.xyah2ltrb(xyah)
    if bbox[0] > width or bbox[1] > height or bbox[2] < 0 or bbox[3] < 0:
        return False
    else:
        return True


if __name__ == '__main__':
    p1 = [0,1,2,3,4,5,6,7,8,9]
    p2 = [9,8,7,6,5,4,3,2,1,0]
    # p1=[0]
    # p2=[1]
    # x, y = order_crossover(random, p1, p2, dict())
    x = flip_trace_and_mutation(random, p1, {'trace_cnt':7})
    print(x)
    # print(y)
