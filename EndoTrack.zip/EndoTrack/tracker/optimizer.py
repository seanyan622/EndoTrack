import typing

import numpy as np

bound_type = typing.List[typing.Union[float, type(None)]]


class Constraint:
    def __init__(self, x_dim: int, trace_cnt: int):
        # all constraints are logic_and
        # self._constraint = {
        #     'linear_equ': [],
        #     'linear_inequ_lt': [],
        #     'linear_inequ_le': [],
        #     'linear_inequ_ne': [],
        #     'nonlinear_equ': [],
        #     'nonlinear_inequ_lt': [],
        #     'nonlinear_inequ_le': []
        # }
        self.bound = {
            'lower_bound': None,
            'upper_bound': None,
            'integer_domain': None
        }
        self.variable_dim = x_dim
        self.trace_cnt = trace_cnt

    # def add_linear_equ(self, constraint_matrix: np.ndarray, b: np.ndarray) -> None:
    #     """
    #     Assert linear equality Constraint: Ax=b, where A can be a vector or matrix
    #     :param constraint_matrix: np.ndarray
    #     :param b: np.ndarray
    #     :return: None
    #     """
    #     if not (len(constraint_matrix.shape) == 2 or len(constraint_matrix.shape) == 1):
    #         raise ValueError(r"Constraint must be a matrix or vector")
    #     if not constraint_matrix.shape[-1] == self._variable_dim:
    #         raise ValueError(r"Column of Constraint is not equivalent to length of variables")
    #     if len(constraint_matrix.shape) == 1:
    #         constraint_matrix = np.expand_dims(constraint_matrix, axis=0)
    #         b = np.expand_dims(b, axis=0)
    #     if not constraint_matrix.shape[0] == b.shape[0]:
    #         raise ValueError(r"Row of Constraint is not equivalent to length of vector/scalar b")
    #     constraint_matrix = np.concatenate((constraint_matrix, np.expand_dims(b, axis=1)), axis=1)
    #     self._constraint['linear_equ'].append(constraint_matrix)
    #
    # def add_linear_inequ(self, constraint_matrix: np.ndarray, b: np.ndarray, cmp: str) -> None:
    #     """
    #     Assert linear equality Constraint: Ax?0, where A can be a vector or matrix
    #     :param cmp: str, indicate symbol of inequality
    #     :param constraint_matrix: np.ndarray
    #     :param b: np.ndarray
    #     :return: None
    #     """
    #     if not (len(constraint_matrix.shape) == 2 or len(constraint_matrix.shape) == 1):
    #         raise ValueError(r"Constraint must be a matrix or vector")
    #     if not constraint_matrix.shape[-1] == self._variable_dim:
    #         raise ValueError(r"Column of Constraint is not equivalent to length of variables")
    #     if len(constraint_matrix.shape) == 1:
    #         constraint_matrix = np.expand_dims(constraint_matrix, axis=0)
    #         b = np.expand_dims(b, axis=0)
    #     if not constraint_matrix.shape[0] == b.shape[0]:
    #         raise ValueError(r"Row of Constraint is not equivalent to length of vector/scalar b")
    #     constraint_matrix = np.concatenate((constraint_matrix, np.expand_dims(b, axis=1)), axis=1)
    #     if cmp == "le":
    #         self._constraint['linear_inequ_le'].append(constraint_matrix)
    #     elif cmp == "lt":
    #         self._constraint['linear_inequ_lt'].append(constraint_matrix)
    #     elif cmp == "gt":
    #         self._constraint['linear_inequ_le'].append(-constraint_matrix)
    #     elif cmp == "ge":
    #         self._constraint['linear_inequ_lt'].append(-constraint_matrix)
    #     elif cmp == "ne":
    #         self._constraint['linear_inequ_ne'].append(constraint_matrix)
    #     else:
    #         raise ValueError(r"le, lt, ge, gt, ne is required.")
    #
    # def add_nonlinear_equ(self, constraint: str, variable: str = 'x', *args) -> None:
    #     raise NotImplementedError
    #
    # def add_nonlinear_inequ(self, constraint_matrix: str, cmp: str, variable: str = 'x', *args) -> None:
    #     raise NotImplementedError

    def add_bound(self, bound: typing.Tuple[bound_type, bound_type] = None,
                  integer_domain: typing.Set[int]= None):
        if bound is not None:
            lower_bound = bound[0]
            upper_bound = bound[1]
            if len(lower_bound) != len(upper_bound) or len(lower_bound) != self.variable_dim:
                raise ValueError(r"Every dimension of variable must has upper bound or upper bound."
                                 r"Specify no bound with nan or None")
            for i in range(len(lower_bound)):
                lower_bound[i] = float(lower_bound[i]) if lower_bound[i] is not None else -np.inf
            for i in range(len(upper_bound)):
                upper_bound[i] = float(upper_bound[i]) if upper_bound[i] is not None else np.inf
            self.bound['lower_bound'] = np.array(lower_bound)
            self.bound['upper_bound'] = np.array(upper_bound)
        if integer_domain is not None:
            self.bound['integer_domain'] = integer_domain
            if bound is None:
                self.bound['lower_bound'] = np.ones(self.variable_dim) * min(list(integer_domain))
                self.bound['upper_bound'] = np.ones(self.variable_dim) * max(list(integer_domain))
        if integer_domain is None and bound is None:
            upper_bound = np.ones(self.variable_dim, dtype=float) * np.inf
            lower_bound = np.ones(self.variable_dim, dtype=float) * (-np.inf)
            self.bound['lower_bound'] = np.array(lower_bound)
            self.bound['upper_bound'] = np.array(upper_bound)

    def __call__(self, x, *args, **kwargs) -> bool:
        for designated_trace in x:
            if designated_trace not in self.bound['integer_domain']:
                return False
        hist, _ = np.histogram(x, bins=np.arange(self.trace_cnt + 3))
        if np.any(hist[:-2] > 1):
            return False
        return True


class Optimizer:
    _supported_methods = ["golden", "newton", "GA", ]

    def __init__(self, method):
        self.method = method
        self.objectives = None
        self.constraint = None
        self.maximize = True

    def add_linear_objective(self, func: np.ndarray, orientation: str):
        if orientation == 'min':
            func = -func
            orientation = 'max'
        d = {
            'func': func,
            'orientation': orientation,
        }
        if self.objectives is None:
            self.objectives = [d]
        else:
            self.objectives.append(d)

    def add_constraint(self, constraint: Constraint):
        if self.constraint is not None:
            s = input('At least one Constraint has been designated, replace with new constraints?')
            if s.casefold() == 'yes' or s.casefold() == 'y':
                self.constraint = constraint
        else:
            self.constraint = constraint

    def solve(self):
        if self.objectives is None:
            raise ValueError(r"no objective.")
        if self.constraint is None:
            raise ValueError(r"no constraint.")
