__version__ = '0.1.0'
__author__ = 'Yu Dongming'

import collections.abc

import numpy as np
import typing
import math
from abc import abstractmethod
import matplotlib.pyplot as plt
import scipy
# from tools.coreset import Coreset
from tracker.coreset import Coreset


class Predictor:
    @abstractmethod
    def __init__(self):
        self.mean = None

    @abstractmethod
    def initialize(self, measurement):
        pass

    @abstractmethod
    def predict(self):
        pass

    @abstractmethod
    def update(self, measurement):
        pass


class KalmanFilter(Predictor):
    """
    State variables:
    x: Coordinates of center point of the bounding box, distance to left edge of image.
    y: Coordinates of center point of the bounding box, distance to top edge of image.
    a: aspect of height and width of bounding box
    h: height of bounding box
    vx, vy, va, vh: changing speed of variables above, units are pixels/s, pixels/s, /s, pixels/s, respectively.

    Observation variables:
    x, y, a, h

    Assumptions:
    Polyp is moving along a line at a constant speed
    State equation:
    [x]     [1, 0, 0, 0, t, 0, 0, 0] [x]
    [y]     [0, 1, 0, 0, 0, t, 0, 0] [y]
    [a]     [0, 0, 1, 0, 0, 0, t, 0] [a]
    [h]     [0, 0, 0, 1, 0, 0, 0, t] [h]
    [vx]  = [0, 0, 0, 0, 1, 0, 0, 0] [vx]
    [vy]    [0, 0, 0, 0, 0, 1, 0, 0] [vy]
    [va]    [0, 0, 0, 0, 0, 0, 1, 0] [va]
    [vh]    [0, 0, 0, 0, 0, 0, 0, 1] [vh]

    Observation equation:
                                     [x]
                                     [y]
    [x]     [1, 0, 0, 0, t, 0, 0, 0] [a]
    [y]     [0, 1, 0, 0, 0, t, 0, 0] [h]
    [a]   = [0, 0, 1, 0, 0, 0, t, 0] [vx]
    [h]     [0, 0, 0, 1, 0, 0, 0, t] [vy]
                                     [va]
                                     [vh]
    """

    def __init__(self, **kwargs):
        t = kwargs.setdefault('t', 1 / 30.0)
        self.dim = 8
        self.observation_dim = self.dim // 2
        self.F = np.eye(8)
        self.F[:4, 4:] = t * np.eye(4)
        self.H = np.eye(4, 8)
        # Since we cannot model movement of polyp precisely, Q is large.
        diagQ = [10, 10, 0.2, 10, 200, 200, 2, 200]
        self.Q = np.diag(np.square(diagQ))
        # We trust observation i.e. our detection well, so R is small.
        diagR = [2, 2, 0.1, 2]
        self.R = np.diag(np.square(diagR))
        # xkk is the reference to mean
        self.mean = None
        self.Pkk = None

    def initialize(self, measurement: np.ndarray):
        assert len(measurement) == self.observation_dim and len(measurement.shape) == 1
        x00 = np.concatenate((measurement, np.zeros(4)), 0)
        diagP00 = [2, 2, 0.1, 2, 200, 200, 2, 200]  # do not know speed exactly
        P00 = np.diag(np.square(diagP00))
        self.mean = x00
        self.Pkk = P00

    def predict(self):
        self.mean = self.F @ self.mean
        self.Pkk = self.F @ self.Pkk @ self.F.T + self.Q

    def update(self, measurement: np.ndarray):
        assert len(measurement) == self.observation_dim and len(measurement.shape) == 1
        zk = measurement
        yk = zk - self.H @ self.mean
        Sk = self.H @ self.Pkk @ self.H.T + self.R
        Kk = self.Pkk @ self.H.T @ np.linalg.inv(Sk)
        xkk = self.mean + Kk @ yk
        Pkk = (np.eye(self.dim) - Kk @ self.H) @ self.Pkk
        self.mean = xkk
        self.Pkk = Pkk


class UnscentedKalmanFilter(Predictor):
    def __init__(self, **kwargs):
        # Choosing parameter alpha and kappa is very tricky, because values too small or large
        # will result in a non-semi-positive definitive matrix Pkk.
        t = kwargs.setdefault('t', 1 / 30.0)
        alpha = kwargs.setdefault('alpha', (np.sqrt(5) - 1) / 2)
        beta = 2
        kappa = kwargs.setdefault('kappa', 15)
        self.nx = 8
        self.nz = 4
        self.F = np.eye(self.nx)
        self.F[:self.nz, self.nz:] = t * np.eye(self.nz)
        self.H = np.eye(self.nz, self.nx)
        diagQ = [10, 10, 0.2, 10, 200, 200, 2, 200]
        self.Q = np.diag(np.square(diagQ))
        diagR = [2, 2, 0.1, 2]
        self.R = np.diag(np.square(diagR))
        self.alpha = alpha
        self.beta = beta
        self.mean = np.zeros(self.nx)
        self.Pkk = np.zeros((self.nx, self.nx))
        self.l = alpha ** 2 * self.nx - self.nx + alpha ** 2 * kappa
        self.Wm = np.r_[self.l / (self.l + self.nx), self.l / (2 * (self.nx + self.l)) * np.ones(2 * self.nx)]
        self.Wc = self.Wm.copy()
        self.Wc[0] += 1 - alpha ** 2 + beta

    def initialize(self, measurement: np.ndarray):
        assert measurement.shape == (self.nz,)
        x00 = np.concatenate((measurement, np.zeros(self.nz)), 0)
        diagP00 = [2, 2, 0.1, 2, 200, 200, 2, 200]  # do not know speed exactly
        P00 = np.diag(np.square(diagP00))
        self.mean = x00
        self.Pkk = P00

    def predict(self):
        Xk_1sample = np.repeat(self.mean[..., None], 2 * self.nx + 1, axis=1)
        cho = np.linalg.cholesky((self.nx + self.l) * self.Pkk)
        Xk_1sample[:, 1:self.nx + 1] += cho
        Xk_1sample[:, self.nx + 1:] -= cho
        Xkbar = self.F @ Xk_1sample
        self.mean = np.average(Xkbar, axis=1, weights=self.Wm)
        self.Pkk = self.Q
        Xkbar_center = Xkbar - np.repeat(self.mean[..., None], 2 * self.nx + 1, 1)
        for i in range(len(self.Wc)):
            self.Pkk += self.Wc[i] * Xkbar_center[:, i, None] @ Xkbar_center[:, i, None].T

    def update(self, measurement: np.ndarray):
        assert measurement.shape == (self.nz,)
        Xkhat = np.repeat(self.mean[..., None], 2 * self.nx + 1, axis=1)
        cho = np.linalg.cholesky((self.nx + self.l) * self.Pkk)
        Xkhat[:, 1:self.nx + 1] += cho
        Xkhat[:, self.nx + 1:] -= cho
        zkbar = self.H @ Xkhat
        zkhat = np.average(zkbar, weights=self.Wm, axis=1)
        Sk = self.R
        Xkbar_center = Xkhat - np.repeat(self.mean[..., None], 2 * self.nx + 1, 1)
        Zkbar_center = zkbar - np.repeat(zkhat[..., None], 2 * self.nx + 1, 1)
        Pxz = np.zeros((self.nx, self.nz))
        for i in range(len(self.Wc)):
            Sk += self.Wc[i] * Zkbar_center[:, i, None] @ Zkbar_center[:, i, None].T
            Pxz += self.Wc[i] * Xkbar_center[:, i, None] @ Zkbar_center[:, i, None].T
        Kk = Pxz @ np.linalg.inv(Sk)
        self.mean += Kk @ (measurement - zkhat)
        self.Pkk -= Kk @ Sk @ Kk.T


class ExtendedKalmanFilter(Predictor):
    def __init__(self, **kwargs):
        t = kwargs.setdefault('t', 1 / 30.0)
        self.eps = kwargs.setdefault('eps', 1e-6)
        self.nx = 10
        self.nz = 4
        self.F = np.eye(self.nx)
        self.F[:self.nx // 2, self.nx // 2:] = np.eye(self.nx // 2) * t
        diagQ = [10, 10, 0.2, 5, 10, 200, 200, 2, 200, 20]
        self.Q = np.diag(np.square(diagQ))
        # We trust observation i.e. our detection well, so R is small.
        diagR = [2, 2, 0.1, 2]
        self.R = np.diag(np.square(diagR))
        self.mean = None
        self.state = None
        self.Pkk = None

    def H(self):
        jacobian = np.zeros((self.nz, self.nx))
        t = self.state[4]
        a = self.state[2]
        h = self.state[3]
        sin_t = np.abs(np.sin(np.deg2rad(t)))
        cos_t = np.abs(np.cos(np.deg2rad(t)))
        cos_2t = np.cos(2 * np.deg2rad(t))
        sin_2t = np.sin(2 * np.deg2rad(t))
        jacobian[0, 0] = 1
        jacobian[1, 1] = 1
        jacobian[2, 2] = np.cos(2 * np.deg2rad(t)) / (
                (a * sin_t + cos_t) ** 2)
        jacobian[2, 4] = (sin_2t / (2 * sin_t + self.eps) - a * sin_2t / (2 * cos_2t + self.eps)) / (
                    a * sin_t + cos_t) - (
                                 a * cos_t + sin_t) * (
                                     a * sin_2t / (2 * sin_t + self.eps) - sin_2t / (2 * cos_t + self.eps)) / (
                                     a * sin_t + cos_t) ** 2
        jacobian[3, 2] = h * sin_t
        jacobian[3, 3] = a * sin_t + cos_t
        jacobian[3, 4] = a * h * sin_2t / (2 * sin_t + self.eps) - h * sin_2t / (2 * cos_t + self.eps)
        return jacobian

    def initialize(self, measurement):
        assert measurement.ndim == 1 and len(measurement) == self.nz
        x0 = np.concatenate((measurement, np.zeros(self.nx - self.nz)), 0)
        self.state = x0
        self.Pkk = self.Q
        self.mean = self.estimate()

    def predict(self):
        self.state = self.F @ self.state
        self.Pkk = self.F @ self.Pkk @ self.F.T + self.Q
        self.mean = self.estimate()

    def observe(self):
        obs = np.zeros(self.nz)
        obs[:2] = self.state[:2]
        t = self.state[4]
        sin_t = np.abs(np.sin(np.deg2rad(t)))
        cos_t = np.abs(np.cos(np.deg2rad(t)))
        a = self.state[2]
        h = self.state[3]
        obs[2] = (sin_t + a * cos_t) / (self.eps + cos_t + a * sin_t)
        obs[3] = h * (sin_t * a + cos_t)
        return obs

    def update(self, measurement: np.ndarray):
        assert measurement.ndim == 1 and len(measurement) == self.nz
        linear_H = self.H()
        Kk = self.Pkk @ linear_H.T @ np.linalg.inv(linear_H @ self.Pkk @ linear_H.T + self.R)
        self.state = self.state + Kk @ (measurement - self.observe())
        self.Pkk = (np.eye(self.nx) - Kk @ linear_H) @ self.Pkk
        self.mean = self.estimate()

    def estimate(self):
        return self.observe()


class ParticleFilter(Predictor):
    def __init__(self, **kwargs):
        seed = kwargs.setdefault('seed', 1)
        n_particles = kwargs.setdefault('n', 100)
        t = kwargs.setdefault('t', 1 / 30.0)
        rotation = kwargs.setdefault('rotate', True)
        self.rng = np.random.default_rng(seed)
        # [x, y, a, h]
        self.nz = 4
        if rotation:
            # [x, y, a, h, theta(deg), vx, vy, vw, vh, vt]
            self.nx = 2 * 5
        else:
            # [x, y, a, h, vx, vy, vw, vh]
            self.nx = 2 * 4
        self.t = t
        self.eps = 1e-6
        if self.nx == 10:
            self.Q = np.diag(np.square([20, 20, 0.2, 20, 10, 2 / t, 2 / t, 0.05 / t, 2 / t, 0.1 / t]))
        else:
            self.Q = np.diag(np.square([20, 20, 0.2, 20, 2 / t, 2 / t, 0.05 / t, 2 / t, ]))
        self.R = np.diag(np.square([2, 2, 0.05, 2]))
        self.particles = [None] * n_particles
        self.weights = np.zeros(n_particles)
        self.mean = None

    def transfer(self, prev_state: np.ndarray):
        assert prev_state.ndim == 1 and len(prev_state) == self.nx
        new_state = prev_state.copy()
        new_state[:self.nx // 2] += self.t * new_state[self.nx // 2:]
        new_state += self.rng.multivariate_normal(mean=np.zeros(self.nx), cov=self.Q)
        if self.nx == 10:
            new_state[5] = new_state[5] % 360
        return new_state

    def observe(self, curr_state: np.ndarray):
        assert curr_state.ndim == 1 and len(curr_state) == self.nx
        curr_obs = np.zeros(self.nz)
        if self.nx == 10:
            curr_obs[:2] = curr_state[:2]
            theta = curr_state[4]
            sin_t = np.abs(np.sin(np.deg2rad(theta)))
            cos_t = np.abs(np.cos(np.deg2rad(theta)))
            a = curr_state[2]
            h = curr_state[3]
            curr_obs[2] = ((sin_t + a * cos_t) /
                           (self.eps + cos_t + a * sin_t))
            curr_obs[3] = h * (np.sin(np.deg2rad(theta)) * a + np.cos(np.deg2rad(theta)))
        else:
            curr_obs = curr_state[:self.nz]
        return curr_obs

    def estimate(self):
        for _ in self.particles:
            if _ is None:
                raise ValueError("Uninitialized particle")
        if np.sum(self.weights) == 0:
            raise ValueError("Uninitialized weight")
        weight = np.array(self.weights) / np.sum(self.weights)
        return np.average(np.array([self.observe(p) for p in self.particles]), weights=weight, axis=0)

    def initialize(self, measurement: np.ndarray):
        assert measurement.ndim == 1 and len(measurement) == self.nz
        x0 = np.concatenate((measurement, np.zeros(self.nx - self.nz)), 0)
        self.particles = [x0 + self.rng.multivariate_normal(mean=np.zeros(self.nx), cov=self.Q) for _ in self.particles]
        self.weights = np.ones_like(self.weights, dtype=float)
        self.mean = self.estimate()

    def predict(self):
        self.particles = [self.transfer(p) + self.rng.multivariate_normal(mean=np.zeros(self.nx), cov=self.Q)
                          for p in self.particles]
        self.mean = self.estimate()

    def update(self, measurement: np.ndarray):
        assert measurement.ndim == 1 and len(measurement) == self.nz
        new_weight = np.zeros_like(self.weights, dtype=float)
        residual = [measurement - self.observe(p) for p in self.particles]
        # pdf(R) = (2 pi)^(-n/2)*det(R)^(-1/2)*exp(-1/2*r inv(R) r.T) = c*exp(-1/2*r inv(R) r.T)
        invR = np.linalg.inv(self.R)
        # one can add any value to each element of exp
        exp = [-1 / 2 * r.T @ invR @ r for r in residual]
        exp = np.array(exp) - np.min(exp)
        max_exp = exp.max()
        # eliminate too small value, we think exp(10)>>exp(0)
        small_value = np.array([v < max_exp - 10 for v in exp])
        exp = exp - max_exp + 10
        new_weight[np.nonzero(1 - small_value)] = \
            np.exp(exp[np.nonzero(1 - small_value)]) * self.weights[np.nonzero(1 - small_value)]
        if np.sum(new_weight) == 0:
            new_weight = np.ones_like(new_weight)
        new_weight = new_weight / np.sum(new_weight)
        neff = 1 / np.sum(np.square(new_weight))
        # resample
        if neff < 0.5 * len(new_weight):
            N = len(new_weight)
            s_idx = self.rng.choice(range(N), N, replace=True, p=new_weight)
            self.particles = [self.particles[idx] for idx in s_idx]
            self.weights = np.ones(N)
        else:
            self.weights = new_weight.copy()
        self.mean = self.estimate()


class Detection:
    """
    class id: int
    frame id: int >= 0, the frame where detection takes place
    confidence: float > 0, confidence on the possibility that detected object belong to its class
    img_path: str,
    features_value:
        - loc: Required, list[4], format [x, y, asp, h] where x=distance between left edge of image to center point of bbox,
               in pixel; y=distance between top edge of image to center point of bbox, in pixel; asp=ratio of bbox's
               height and bbox's width; h=bbox's height, in pixel.
        - others: Optional, object.
    """

    def __init__(self, class_id, frame_id, conf, image_path, **kwargs):
        self.class_id = int(class_id)
        self.frame_id = int(frame_id)
        self.confidence = float(conf)
        self.img_pth = str(image_path)
        self.features_value = kwargs  # include position xyah and(or) other features

    def __str__(self):
        height = self.features_value['loc'][3]
        width = self.features_value['loc'][2] * height
        left = self.features_value['loc'][0] - width / 2
        top = self.features_value['loc'][1] - height / 2
        return f'{self.frame_id}, {self.class_id}, {round(left, 3)}, {round(top, 3)}, {round(width, 3)}, {round(height, 3)}, 1, 1, 1'


ObjectClasses = {
    1: 'polyp',
}


class BaseTrace:
    """
    Basic trace class, include its:

    - ID, key of trace, unique
    - class ID, int(in current version, only single-label detector is supported)
    - confidence of prediction, float(only valid for detection)
    - location of format [left, top, width, height], integer or float
    - other features of trace.
    - detection history, list of Detection

    Location and other features should correspond to
    """
    trace_cnt = 0
    app_bank_mode = {
        'None': 0,
        'Current': 1, # Compare appearance with object in current frame, inferred by location
        'DeepSORT': 2, # DeepSORT stores previous appearances, like a sliding window.
        'EMA': 3,
        'Coreset': 4, # compress data with the coreset, then cluster all appearances
    }

    def __init__(self, features_predictor: typing.Union[Predictor, typing.Mapping[str, Predictor]],
                 measurement: Detection, appearance=None, **kwargs):
        current_frame = measurement.frame_id
        self.trace_id = BaseTrace.next_id()
        self.class_id = measurement.class_id
        self.frame_set = {current_frame}
        # self.app_bank_mode = kwargs.setdefault('app_bank_mode', 1)
        self.app_bank_mode = kwargs.setdefault('app_bank_mode', 0)
        if self.app_bank_mode not in BaseTrace.app_bank_mode.values():
            raise ValueError('Unknown appearance bank mode')
        self.app_bank = []
        if self.app_bank_mode != 0 and appearance is None:
            raise ValueError(f'To perform data association without appearance, assign `app_bank_mode` to `None`.')
        # if not isinstance(appearance, collections.abc.Collection):
        #     raise ValueError(f'Appearance should be of vector like, but got {type(appearance)}.')
        # appearance = np.array(appearance)
        # assert appearance.ndim == 1
        # if self.app_bank_mode == 1:
        #     self.bank_size = 1
        #     self.app_bank.append(appearance)
        # elif self.app_bank_mode == 2:
        #     self.bank_size = kwargs.setdefault('bank_size', 100)
        #     if len(self.app_bank) == self.bank_size:
        #         del self.app_bank[0]
        #     self.app_bank.append(appearance)
        # elif self.app_bank_mode == 3:
        #     self.bank_size = 1
        #     self.alpha = kwargs.setdefault('alpha',0.9)
        #     if len(self.app_bank) == 0:
        #         self.app_bank.append(appearance)
        #     else:
        #         self.app_bank[0] = self.alpha * self.app_bank[0] + (1 - self.alpha) * appearance
        # else:
        #     self.buffer = []
        #     self.coreset = None
        #     self.eps = kwargs.setdefault('eps', 0.1)
        #     self.subspace_dim = kwargs.setdefault('subspace_dim', 2)
        #     self.k = kwargs.setdefault('k', 3)
        #     self.m = self.subspace_dim + math.ceil(self.subspace_dim / self.eps) - 1
        #     if len(self.buffer) < 6 * self.m:
        #         self.buffer.append(appearance)
        #         if len(self.buffer) < self.k:
        #             self.app_bank = np.array(self.buffer)
        #         else:
        #             self.app_bank = scipy.cluster.vq.kmeans(np.array(self.buffer), self.k)[0]
        #     else:
        #         if self.coreset is None:
        #             self.coreset = Coreset.generate(np.array(self.buffer), self.subspace_dim, self.eps)
        #         else:
        #             self.coreset = Coreset.generate(np.vstack((self.coreset, self.buffer)), self.subspace_dim, self.eps)
        #         self.buffer = []
        if isinstance(features_predictor, collections.abc.Mapping):
            keys = ' '.join([key for key in features_predictor])
            if keys.count('loc') + keys.count('xyah') == 0:
                raise KeyError(r"Location predictor must be provided")
            self.features_predictor = dict()
            for key in features_predictor:
                self.features_predictor[key] = features_predictor[key]
        else:
            self.features_predictor = {'loc': features_predictor}
        # With initial update, convert predictor class to a predictor object.
        for feature_key in measurement.features_value:
            self.features_predictor[feature_key].initialize(
                measurement=measurement.features_value[feature_key]
            )
        # loc = [frame, group_id, left, top, width, height, 1, 1, 1]
        loc = np.r_[(current_frame, self.trace_id, self.features_predictor['loc'].mean[:4], np.ones(3))]
        loc[4] *= loc[5]
        loc[2:4] -= loc[4:6] / 2
        self.loc_history = [loc]  # store detections' location features

    def __repr__(self):
        bbox = np.array(self.features_predictor['loc'].mean)
        bbox[2] *= bbox[3]
        bbox[0] -= bbox[2] / 2
        bbox[1] -= bbox[3] / 2
        bbox[2] += bbox[0]
        bbox[3] += bbox[1]
        bbox = np.around(bbox, 3)
        return f"Trace_{self.trace_id} : {self.first_frame()}-{self.last_frame()} @ {bbox}"

    def first_frame(self):
        return int(np.min(list(self.frame_set)))

    def last_frame(self):
        return int(np.max(list(self.frame_set)))

    def predict(self):
        for key in self.features_predictor:
            self.features_predictor[key].predict()

    def update(self, measurement: Detection, appearance=None, **kwargs):
        current_frame = measurement.frame_id
        self.frame_set.add(current_frame)

        for key in self.features_predictor:
            self.features_predictor[key].update(
                measurement=measurement.features_value[key]
            )

        if self.app_bank_mode != 0:
            assert 'appearance' in kwargs
            if self.app_bank_mode == 1:
                self.app_bank[0] = appearance
            elif self.app_bank_mode == 2:
                if len(self.app_bank) == self.bank_size:
                    del self.app_bank[0]
                self.app_bank.append(appearance)
            elif self.app_bank_mode == 3:
                if len(self.app_bank) == 0:
                    self.app_bank.append(appearance)
                else:
                    self.app_bank[0] = self.alpha * self.app_bank[0] + (1 - self.alpha) * appearance
            else:
                if len(self.buffer) < 6 * self.m:
                    self.buffer.append(appearance)
                    if len(self.buffer) < self.k:
                        self.app_bank = np.array(self.buffer)
                    else:
                        self.app_bank = scipy.cluster.vq.kmeans(np.array(self.buffer), self.k)[0]
                else:
                    if self.coreset is None:
                        self.coreset = Coreset.generate(np.array(self.buffer), self.subspace_dim, self.eps)
                    else:
                        self.coreset = Coreset.generate(np.vstack((self.coreset, self.buffer)), self.subspace_dim,
                                                        self.eps)
                    self.buffer = []
        loc = np.r_[(current_frame, self.trace_id, self.features_predictor['loc'].mean[:4], np.ones(3))]
        loc[4] *= loc[5]
        loc[2:4] -= loc[4:6] / 2
        self.loc_history.append(loc)

    @staticmethod
    def next_id():
        BaseTrace.trace_cnt += 1
        return BaseTrace.trace_cnt


def ltwh2ltrb(ltwh):
    return np.concatenate((ltwh[:2], [ltwh[2] + ltwh[0]], [ltwh[3] + ltwh[1]]), axis=0)


def ltwh2xyah(ltwh):
    ltwh = np.array(ltwh)
    xy = ltwh[:2] + ltwh[2:] / 2
    a = ltwh[2] / ltwh[3]
    return np.concatenate((xy, a, ltwh[3]), axis=0)


def xyah2ltrb(xyah):
    h = xyah[3]
    w = xyah[2] * xyah[3]
    l = xyah[0] - w / 2
    r = xyah[0] + w / 2
    t = xyah[1] - h / 2
    b = xyah[1] + h / 2
    return np.array([l, t, r, b], dtype=float)


if __name__ == '__main__':
    kf = ParticleFilter()
    # kf = KalmanFilter()
    N = 100
    x = np.zeros((N, 4))
    x[:, 0] = 2 * np.arange(N) + 100
    x[:, 1] = 4 * np.arange(N) - 300
    x[:, 2] = 1.0
    x[:, 3] = 10
    y = []
    rng = np.random.default_rng()
    # kf.initialize(x)
    for i, m in enumerate(x):
        if i == 0:
            kf.initialize(m)
            y.append(kf.mean)
            continue
        kf.predict()
        # kf.update(m + np.array([10, 10, 0.2, 3])*rng.random(4))
        kf.update(m)
        y.append(kf.mean)
    y = np.array(y)
    fig, ax = plt.subplots()
    ax.plot(x[:, 0], x[:, 1], 'r.')
    ax.plot(y[:, 0], y[:, 1], 'kx')
    fig.show()
