import os.path
import re
import typing

import cv2
import numpy as np
import onnxruntime
import scipy.integrate
import scipy.stats
from inspyred.ec import Individual
from skimage import feature as sci_feature

from .base_tracker import BaseTrace, Detection
from .base_tracker import xyah2ltrb


class Similarity:
    distribution = typing.TypeVar('distribution', np.ndarray, typing.Callable[[float], float])

    @classmethod
    def f_divergence(cls, p: distribution,
                     q: distribution,
                     f: typing.Callable[[float], float],
                     *args):
        """
        Calculate F-divergence of two distributions.

        If p and y ore both discrete, sum op is implemented through their length.

        If p and y are both callable, integration op is implemented through the indicated domain.

        :param p: Probability distribution function/Probability mass function of random variable X.
        :param q: Probability distribution function/Probability mass function of random variable Y.
        :param f: A concave function with domain [0, inf) and range [0,1] s.t. f(1)=0, these assumptions will
        not be checked in this function.
        :param args: If p and y are PDF, domain of variable X and Y should be provided as a 2*n size list, every two
        number form a range to integrate.
        :return:
        """
        if isinstance(p, np.ndarray) and isinstance(q, np.ndarray):
            if len(p.shape) != 1 or len(q.shape) != 1:
                raise ValueError(r"Input arrays have improper dimension.")
            return np.sum(f(p / q) * q)
        elif isinstance(p, typing.Callable) and isinstance(q, typing.Callable):
            domain = args[0]

            def g(x):
                x: f(p(x) / q(x)) * q(x)

            ret = 0
            for i in range(0, len(domain), 2):
                start = domain[i]
                end = domain[i + 1]
                ret += scipy.integrate.romberg(g, start, end)
            return ret

    @classmethod
    def kl_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return x * np.log2(x)

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def js_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return 0.5 * (x * np.log2(x) + (x + 1) * np.log2(2 / (x + 1)))

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def l1norm_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return np.abs(x - 1)

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def reverse_kl_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return -np.log2(x)

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def chi2_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return x * x + 1

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def reverse_chi2_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return 1 / x - 1

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def total_variation_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return 0.5 * np.abs(x - 1)

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def hellinger_divergence(cls, p: distribution, q: distribution, *args):
        def f(x):
            return 2 * (1 - np.sqrt(x))

        return Similarity.f_divergence(p, q, f, args)

    @classmethod
    def cosine_similarity(cls, p: np.ndarray, q: np.ndarray):
        cos_theta = np.dot(p, q) / np.sqrt(np.dot(p, p) * np.dot(q, q))
        return (cos_theta + 1) / 2

    @classmethod
    def wasserstein_distance(cls, p: np.ndarray, q: np.ndarray):
        return scipy.stats.wasserstein_distance(p, q)


class Objective:
    def __init__(self, method, opt_orientation: str, **kwargs):
        self.calc = method
        self.opt_orientation = opt_orientation.casefold()
        if opt_orientation.count('max') + opt_orientation.count('large') > 0:
            self.opt_orientation = 'max'
        elif opt_orientation.count('min') + opt_orientation.count('low') + opt_orientation.count('small') > 0:
            self.opt_orientation = 'min'
        else:
            raise ValueError(f"Optimal orientation is not designated of method {method}")

    def __call__(self, traces, detections):
        return self.calc(traces, detections)


class IoUObjective(Objective):
    def iou(self, traces: typing.List[BaseTrace], detections: typing.List[Detection]):
        """
        Calculate IoUs of bounding boxes.

        Each bounding box should be of format [top, left, bottom, right], and bounding boxes array is stacked by boxes
        through axis 0.

        :param traces: list of BaseTrace class
        :param detections: list of Detection class
        :return: numpy.ndarray, value at (i, j) is IoU of ith trace and jth detection if i<N,
        value at (N, j) is false positive pseudo-IoU, which correspond with the size of detection, value at (N+1, j) is
        new trace pseudo-IoU, which is constant 0.5
        """
        m = len(traces)
        n = len(detections)
        iou_matrix = np.zeros((m + 2, n), dtype=float)
        seqinfo_pth = os.path.join(os.path.dirname(detections[0].img_pth), '../', 'seqinfo.ini')
        try:
            seqinfo_file = open(seqinfo_pth, 'r')
            for row in seqinfo_file:
                if row.count('imHeight') > 0:
                    img_h = int(re.search(r'[0-9]+', row).group())
                if row.count('imWidth') > 0:
                    img_w = int(re.search(r'[0-9]+', row).group())
            seqinfo_file.close()
        except FileNotFoundError:
            img_content = cv2.imread(detections[0].img_pth)
            img_h, img_w = img_content.shape[:2]
        if self.data_format != 'mot':
            def f(x):
                # Infer the likelihood that a bounding box is an object from its size.
                if x <= 0.02:
                    # interpolation points: f(0)=0, f(0.02)=1, f(0.01)=0.7
                    A = np.vander([0, 0.01, 0.02])
                    b = np.array([0, 0.7, 1])
                    w = np.linalg.inv(A) @ b
                else:
                    # interpolation points: f(0.02)=1, f(0.2)=0.5, f(0.6)=0.25, f(1)=0
                    A = np.vander([0.02, 0.2, 0.6, 1])
                    b = np.array([1, 0.5, 0.25, 0])
                    w = np.linalg.inv(A) @ b
                return np.sum(w * x ** np.arange(len(w) - 1, -1, -1)) * 0.6
        else:
            def f(x):
                # Infer the likelihood that a bounding box is an object from it aspect
                mean = 2.74
                std = 2.05
                var = std ** 2
                return np.exp(-(x - mean) ** 2 / (2 * var))

        for i, trace in enumerate(traces):
            loc1 = trace.features_predictor['loc'].mean[:4]
            ltrb1 = xyah2ltrb(loc1)
            size_1 = (ltrb1[3] - ltrb1[1]) * (ltrb1[2] - ltrb1[0])
            for j, detection in enumerate(detections):
                ltrb2 = xyah2ltrb(detection.features_value['loc'])
                overlap_left = np.max([ltrb1[0], ltrb2[0]])
                overlap_right = np.min([ltrb1[2], ltrb2[2]])
                overlap_top = np.max([ltrb1[1], ltrb2[1]])
                overlap_bottom = np.min([ltrb1[3], ltrb2[3]])
                if (overlap_left >= overlap_right) or (overlap_top >= overlap_bottom):
                    iou_matrix[i, j] = 0.0
                else:
                    overlap_size = (overlap_bottom - overlap_top) * (overlap_right - overlap_left)
                    size_2 = (ltrb2[3] - ltrb2[1]) * (ltrb2[2] - ltrb2[0])
                    iou_matrix[i, j] = overlap_size / (size_1 + size_2 - overlap_size)
        for j, detection in enumerate(detections):
            if self.data_format != 'mot':
                size = detection.features_value['loc'][2] * detection.features_value['loc'][3] ** 2
                # iou_matrix[m, j] = 6.6 * self.pf_coff * f(size / (img_h * img_w))
                iou_matrix[m, j] = 1.2 * self.pf_coff * f(size / (img_h * img_w))
            else:
                asp = 1 / detection.features_value['loc'][2]
                # if none track, do not infer a new track from iou/asp
                # if we have tracks, infer from aspect and other IoUs jointly
                if m == 0:
                    iou_matrix[m, j] = self.pf_coff
                else:
                    iou_matrix[m, j] = f(asp) * (1 - np.max(iou_matrix[:m, j]))
            iou_matrix[m + 1, j] = self.pf_coff
        return iou_matrix

    def __init__(self, **kwargs):
        self.pf_coff = kwargs.setdefault('pf_coff', 0.5)
        self.data_format = kwargs.setdefault('data_format', 'colonoscopy')
        super(IoUObjective, self).__init__(self.iou, 'max')


class ConfObjective(Objective):
    def conf(self, traces: typing.List[BaseTrace], detections: typing.List[Detection]):
        m = len(traces)
        n = len(detections)
        conf_matrix = np.zeros((m + 2, n))
        for j, detection in enumerate(detections):
            conf_matrix[:m + 1, j] = detection.confidence * np.ones_like(conf_matrix[:m + 1, j])
            conf_matrix[-1, j] = self.pf_coff

        return conf_matrix

    def __init__(self, **kwargs):
        self.pf_coff = kwargs.setdefault('pf_coff', 0.4)
        super(ConfObjective, self).__init__(self.conf, 'max')


class LBP:
    def __init__(self, sample_cnt, radius):
        self.sample_num = sample_cnt
        self.radius = radius

    def compute(self, img: np.ndarray, eps: float = 1e-6, channel: str = 'bgr'):
        if img.size == 0:
            raise ValueError(r"Empty image does not have LBP feature.")
        channel = channel.casefold()
        if channel == 'rgb':
            img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        elif channel == 'bgr':
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        elif not (channel == 'gray' or channel == 'grey'):
            raise ValueError(r"Only RGB and GRAY images are supported.")
        lbp = sci_feature.local_binary_pattern(img, self.sample_num, self.radius, method='uniform')
        (hist, _) = np.histogram(
            lbp.reshape(-1),
            bins=np.arange(self.sample_num + 3),
            range=(0, self.sample_num + 2)
        )
        hist = hist / hist.sum()

        return hist


class LBPSimilarityObjective(Objective):
    def lbp_similarity(self, traces: typing.List[BaseTrace], detections: typing.List[Detection], ):
        m = len(traces)
        n = len(detections)
        image_content = cv2.imread(detections[0].img_pth)
        height, width = image_content.shape[:2]
        lbp = LBP(sample_cnt=16, radius=3)
        lbp_similarity_matrix = np.zeros((m + 2, n))
        hist_traces = []
        hist_dets = []
        for trace in traces:
            loc = trace.features_predictor['loc'].mean[:4]
            loc = xyah2ltrb(loc)
            left = min(loc[0], loc[2])
            top = min(loc[1], loc[3])
            right = max(loc[0], loc[2])
            bottom = max(loc[1], loc[3])
            left = int(np.clip(left, a_min=0, a_max=width - 1))
            top = int(np.clip(top, a_min=0, a_max=height - 1))
            right = int(np.clip(right, a_min=0, a_max=width - 1))
            bottom = int(np.clip(bottom, a_min=0, a_max=height - 1))
            pta_1 = (left, top)  # lt
            pta_2 = (right, bottom)  # rb
            trace_part = image_content[pta_1[1]:pta_2[1], pta_1[0]:pta_2[0]]
            if trace_part.size == 0:
                raise ValueError(f'Image {detections[0].img_pth} with empty trace {trace.trace_id}: {loc}')
            hist_traces.append(lbp.compute(trace_part, channel='bgr'))
        for det in detections:
            loc = det.features_value['loc']
            loc = xyah2ltrb(loc).flatten()
            left = min(loc[0], loc[2])
            top = min(loc[1], loc[3])
            right = max(loc[0], loc[2])
            bottom = max(loc[1], loc[3])
            left = int(np.clip(left, a_min=0, a_max=width - 1))
            top = int(np.clip(top, a_min=0, a_max=height - 1))
            right = int(np.clip(right, a_min=0, a_max=width - 1))
            bottom = int(np.clip(bottom, a_min=0, a_max=height - 1))
            pta_1 = (left, top)  # lt
            pta_2 = (right, bottom)  # rb
            det_part = image_content[pta_1[1]:pta_2[1], pta_1[0]:pta_2[0]]
            if det_part.size == 0:
                raise ValueError(f'Image {detections[0].img_pth} with empty detection: {loc}')
            hist_dets.append(lbp.compute(det_part, channel='bgr'))
        for i in range(len(traces)):
            for j in range(len(detections)):
                lbp_similarity_matrix[i, j] = Similarity.cosine_similarity(hist_traces[i], hist_dets[j])
        if len(traces) == 0:
            lbp_similarity_matrix[m, :] = self.pf_coff
        else:
            for j, detection in enumerate(detections):
                A = np.array(hist_traces).T
                b = np.array(hist_dets[j])
                wstar = np.linalg.inv(A.T @ A) @ A.T @ b
                lbp_similarity_matrix[m, j] = Similarity.wasserstein_distance(wstar, np.ones_like(wstar))
        lbp_similarity_matrix[m + 1, :] = self.pf_coff

        return np.clip(lbp_similarity_matrix, a_min=0, a_max=1)

    def __init__(self, **kwargs):
        self.pf_coff = kwargs.setdefault('pf_coff', 0.92)
        super(LBPSimilarityObjective, self).__init__(self.lbp_similarity, 'max')


class ReIDObjective(Objective):
    model_input_size: int = 416

    @staticmethod
    def preprocess(img, img_size: int):
        img = cv2.resize(img, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
        img = img.astype("float32").transpose(2, 0, 1)[np.newaxis]  # (b, c, h, w)
        return img

    def reid(self, traces: typing.List[BaseTrace], detections: typing.List[Detection]):
        m = len(traces)
        n = len(detections)
        whole_img = cv2.imread(detections[0].img_pth)[..., ::-1] #TODO 是否可以考虑直接将图片作为参数传进来?
        height, width = whole_img.shape[:2]
        total_image_embedding = np.zeros((m + n, 3, self.model_input_size, self.model_input_size),
                                         dtype=np.float32)
        reid_similarity_matrix = np.zeros((m + 2, n))
        ebd_idx = 0
        for trace in traces:
            loc = trace.features_predictor['loc'].mean[:4]
            loc = xyah2ltrb(loc)
            left = min(loc[0], loc[2])
            top = min(loc[1], loc[3])
            right = max(loc[0], loc[2])
            bottom = max(loc[1], loc[3])
            left = int(np.clip(left, a_min=0, a_max=width - 1))
            top = int(np.clip(top, a_min=0, a_max=height - 1))
            right = int(np.clip(right, a_min=0, a_max=width - 1))
            bottom = int(np.clip(bottom, a_min=0, a_max=height - 1))
            total_image_embedding[ebd_idx] = self.preprocess(whole_img[top:bottom + 1, left:right + 1], ReIDObjective.model_input_size)
            ebd_idx += 1
            # reid_traces.append(self.model.run(None, {self.input_name: img_embedding})[0][0])
        for det in detections:
            loc = det.features_value['loc']
            loc = xyah2ltrb(loc).flatten()
            left = min(loc[0], loc[2])
            top = min(loc[1], loc[3])
            right = max(loc[0], loc[2])
            bottom = max(loc[1], loc[3])
            left = int(np.clip(left, a_min=0, a_max=width - 1))
            top = int(np.clip(top, a_min=0, a_max=height - 1))
            right = int(np.clip(right, a_min=0, a_max=width - 1))
            bottom = int(np.clip(bottom, a_min=0, a_max=height - 1))
            total_image_embedding[ebd_idx] = self.preprocess(whole_img[top:bottom + 1, left:right + 1], ReIDObjective.model_input_size)
            ebd_idx += 1
            # reid_dets.append(self.model.run(None, {self.input_name: img_embedding})[0][0])
        reid_features = self.model.run(None, {self.input_name: total_image_embedding})[0]
        reid_traces = reid_features[:m]
        reid_dets = reid_features[m:]
        # for real matches, use their cosine distances as similarity.
        for i in range(len(traces)):
            for j in range(len(detections)):
                reid_similarity_matrix[i, j] = Similarity.cosine_similarity(reid_traces[i], reid_dets[j])

        if len(traces) == 0:
            reid_similarity_matrix[m, :] = self.pf_coff
        else:
            reid_similarity_matrix[m, :] = self.pf_coff * 2 - np.max(reid_similarity_matrix[:m, :], axis=0)
        # else:
        #     for j, detection in enumerate(detections):
        #         A = np.array(reid_traces).T
        #         b = np.array(reid_dets[j])
        #         try:
        #             wstar = np.linalg.inv(A.T @ A) @ A.T @ b
        #         except np.linalg.LinAlgError:
        #             np.savez('output/singular_mat.npz', A, b)
        #             print('singular mat')
        #             for trace in traces:
        #                 print(trace)
        #             for det in detections:
        #                 print(det)
        #         reid_similarity_matrix[m, j] = Similarity.wasserstein_distance(wstar, np.ones_like(wstar))
        reid_similarity_matrix[m + 1, :] = self.pf_coff

        return np.clip(reid_similarity_matrix, a_min=0, a_max=1)

    def __init__(self, **kwargs):
        self.pf_coff = kwargs.setdefault('pf_coff', 0.615)
        onnx_model_path = kwargs.get('onnx_model_path')
        input_size = kwargs.setdefault('input_size', 416)
        input_size = int(float(input_size))
        not_onnx_error_msg = f"onnx model file is expected, but got {onnx_model_path}"
        assert os.path.isfile(onnx_model_path) and onnx_model_path.endswith('.onnx'), not_onnx_error_msg
        non_positive_size_error_msg = "expect a positive img size as input to model."
        assert input_size > 0, non_positive_size_error_msg
        self.model = onnxruntime.InferenceSession(onnx_model_path,
                                                  providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
        self.input_name = self.model.get_inputs()[0].name
        ReIDObjective.model_input_size = int(input_size)
        # self.preprocess = lambda img: cv2.resize(img, (input_size, input_size), interpolation=cv2.INTER_CUBIC).astype(np.float32).transpose(2, 0, 1)[None]
        super().__init__(self.reid, 'max')

    def __call__(self, traces, detections):
        return self.calc(traces, detections)


def keep_knee_pop(population: typing.MutableSequence[Individual]):
    n = len(population)
    if n == 0:
        return population

    # eliminate individuals which not belong to Pareto Front
    should_remove = []
    for i in range(n):
        for j in range(i, n):
            if population[i] < population[j]:
                should_remove.append(population[i])
                break
    for r in should_remove:
        population.remove(r)

    # normalize
    n_obj = len(population[0].fitness.values)
    for i in range(n_obj):
        min_value = np.min([ind.fitness.values[i] for ind in population])
        max_value = np.max([ind.fitness.values[i] for ind in population])
        if min_value != max_value:
            d = max_value - min_value
            for k in range(len(population)):
                population[k].fitness.values[i] = (population[k].fitness.values[i] - min_value) / d
        else:
            for k in range(len(population)):
                population[k].fitness.values[i] = 0.0

    # map fitness to population
    dict_fitness_to_population = dict()
    for pop in population:
        f = tuple(pop.fitness.values)
        if not f in dict_fitness_to_population:
            dict_fitness_to_population[f] = [pop]
        else:
            dict_fitness_to_population[f].append(pop)
    fitness_cnt = len(dict_fitness_to_population)

    # only reserve knee point(s) in range space
    tau = np.diag(np.ones(fitness_cnt) * np.inf)
    for i, ikey in enumerate(dict_fitness_to_population.keys()):
        for j, jkey in enumerate(dict_fitness_to_population.keys()):
            if j == i:
                continue
            diff = np.array(ikey) - np.array(jkey)
            numerator = 0
            denominator = 0
            for v in diff:
                if v > 0:
                    numerator += v
                else:
                    denominator -= v
            tau[i, j] = numerator / denominator
    mu = np.min(tau, axis=1)
    p = np.argwhere(mu == np.max(mu)).flatten()
    ret = []
    for idx, k in enumerate(dict_fitness_to_population.keys()):
        if idx in p:
            for ind in dict_fitness_to_population[k]:
                ret.append(ind)
    return ret
