import numpy as np
import math
import sklearn.cluster
import tqdm


def subspace_coreset(A, j, eps=1e-3, compute_norm=True, compute_w=True):
    n, d = A.shape
    m = min([n, d, j + math.ceil(j / eps) - 1])
    (u, d_diag, vT) = np.linalg.svd(A)
    dm = np.zeros_like(A)
    dm[np.diag_indices(m)] = d_diag[:m]
    ret_v = [dm @ vT]
    if compute_norm:
        ret_v.append(np.linalg.norm(A - u @ dm @ vT))
    if compute_w:
        ret_v.append(np.ones(m))
    return tuple(ret_v)


def affine_j_subspace_coreset(A, j, eps=1e-3, compute_norm=True, compute_w=True):
    n, _ = A.shape
    mean = np.mean(A, axis=0)
    (sp, delta, _) = subspace_coreset(A - mean, j, eps)
    m = sp.shape[0]
    s = np.sqrt(m / n) * np.r_[sp, -sp] + mean
    ret_v = [s]
    if compute_norm:
        ret_v.append(delta)
    if compute_w:
        ret_v.append(np.ones(2 * m) * (n / (2 * m)))
    return tuple(ret_v)


def affine_j_subspace_coreset_w(A, j, w, eps=1e-3, compute_norm=True, compute_w=True):
    W = np.sum(w)
    mean = np.average(A, axis=0, weights=w)
    Am = A - mean
    B = np.diag(np.sqrt(w)) @ Am
    (sp, delta, _) = subspace_coreset(B, j, eps)
    m = sp.shape[0]
    s = np.sqrt(m / W) * np.r_[sp, -sp] + mean
    ret_v = [s]
    if compute_norm:
        ret_v.append(delta)
    if compute_w:
        ret_v.append(np.ones(2 * m) * (W / (2 * m)))
    return tuple(ret_v)


def dim_reduction_k_means(A, k, eps=1e-3, seed=None):
    assert 0 < eps < 0.5
    m = k + math.ceil(72 * k / eps ** 2) - 1
    (u, d_diag, vt) = np.linalg.svd(A)
    dm = np.zeros_like(A)
    dm[np.diag_indices(m)] = d_diag[:m]
    Am: np.ndarray = u @ dm @ vt
    kmeans = sklearn.cluster.Kmeans(n_clusters=k, random_state=seed).fit(np.ascontiguousarray(Am))
    return kmeans.cluster_centers_


def affine_j_subspace_k_clustering(A, j, k, eps):
    m = k * (j + 1) + math.ceil(72 * k * (j + 1) / eps ** 2) - 1
    (u, d_diag, vt) = np.linalg.svd(A)
    dm = np.zeros_like(A)
    dm[np.diag_indices(m)] = d_diag[:m]
    Am = u @ dm @ vt
    #TODO: ...


def coreset_size(eps, j):
    return j - 1 + math.ceil(j / eps)


class StreamingSubspaceApproximation:
    def __init__(self, j, eps):
        self.Q = []
        self.d = None
        self.j = j
        self.eps = eps
        self.h = 1
        self.i = 0
        self.Si = [None]
        self.DS = [0]
        self.sS = []
        self.sDS = 0
        self.T = None
        self.DT = 0
        self.Ti = [None] * self.h
        self.DiT = [0] * self.h
        self.gamma = self.eps / (10 * self.h)
        self.m = coreset_size(self.gamma, j)
        self.k = 0

    def input_streaming_data(self, x: np.ndarray):
        if self.d is None:
            self.d = len(x)
        else:
            assert self.d == len(x)
        if self.k < 2 ** self.h * self.m:
            self.Q.append(x)
            if len(self.Q) == 2 * self.m:
                (self.T, self.DT, w) = subspace_coreset(np.array(self.Q), self.j, self.gamma)
                self.i = 0
                while self.Ti[self.i] is not None:
                    (self.T, self.DT, w) = subspace_coreset(np.append(self.T, self.Ti[self.i], axis=0), self.j,
                                                            self.gamma)
                    self.DT += self.DiT[self.i]
                    self.Ti[self.i] = None
                    self.DiT[self.i] = 0
                    self.i += 1
                self.Ti[self.i] = self.T
                self.DiT[self.i] = self.DT
                self.sS = np.zeros((0, self.d))
                for self.i in range(self.h):
                    if self.Si[self.i] is not None:
                        # self.sS.append(self.Si[self.i])
                        self.sS = np.r_[self.sS, self.Si[self.i]]
                    if self.Ti[self.i] is not None:
                        # self.sS.append(self.Ti[self.i])
                        self.sS = np.r_[self.sS, self.Ti[self.i]]
                    self.sDS += self.DS[self.i] + self.DiT[self.i]
                self.Q = []
            self.k += 1
        else:
            self.Si[self.h - 1] = self.T
            self.DS[self.h - 1] = self.DT
            self.h += 1
            self.Si.append(None)
            self.DS.append(0)
            self.i = 0
            self.Ti = [None] * self.h
            self.DiT = [0] * self.h
            self.gamma = self.eps / (10 * self.h)
            self.k = 0

    def output_coreset(self, j, eps, compute_norm=True, compute_w=True):
        if len(self.sS) == 0:
            u = np.array(self.Q)
        elif len(self.Q) == 0:
            u = np.array(self.sS)
        else:
            u = np.r_[np.array(self.Q), np.array(self.sS)]
        (self.T, self.DT, w) = subspace_coreset(u, j, eps)
        self.DT += self.sDS
        ret_v = [self.T]
        if compute_norm:
            ret_v.append(self.DT)
        if compute_w:
            ret_v.append(w)
        return tuple(ret_v)


if __name__ == '__main__':
    rng = np.random.default_rng(1234)
    n = 1000
    d = 2000
    j = 2
    eps = 0.1
    A = rng.random((n, d))
    sa = StreamingSubspaceApproximation(j, eps)
    csize = []
    for i in tqdm.trange(len(A)):
        v = A[i]
        sa.input_streaming_data(v)
        (a, b, c) = sa.output_coreset(j, eps)
        csize.append(len(a))
    np.savetxt('csize.txt', csize)


class Coreset:
    """
    Coreset implementation of https://doi.org/10.1137/18M1209854
    n: number of input points, unknown for the streaming algorithm set
    d: dimension of each point
    j: dimension of linear(affine) subspaces
    k: cardinal(number) of subspaces
    """

    def __init__(self, j=0, k=1):
        assert j >= 0 and k >= 1
        self.j = j
        self.k = k

    def subspace_coreset(self, dataset: np.ndarray, eps: float = 1 / 3):
        assert dataset.ndim == 2 and eps > 0
        n, d = dataset.shape
        m = min([n, d, self.k + math.ceil(self.k / eps) - 1])
        if d <= m or n <= m:
            return dataset, 0.0, np.ones(len(dataset))
        (u, s, vh) = scipy.linalg.svd(dataset)
        ur = u[:, :m]
        vhr = vh[:m, :]
        sr = s[:m]
        S = np.diag(sr) @ vhr
        dm = ur @ S
        delta = np.linalg.norm(dataset - dm)
        return S, delta, np.ones(len(S))

    def affine_subspace_coreset(self, dataset: np.ndarray, w: np.ndarray = None, eps: float = 1 / 3):
        assert dataset.ndim == 2 and w.ndim == 1 and eps > 0
        assert len(w) == len(dataset)
        if w is None:
            w = np.ones(len(dataset))
        W = np.sum(w)
        muA = np.average(dataset, weights=w, axis=0)
        B = np.einsum('ij,i->ij', dataset - muA, np.sqrt(w))
        Sp, delta, _ = self.subspace_coreset(B, eps)
        m = len(Sp)
        S = np.tile(muA, (m, 1)) + np.sqrt(m / W) * np.concatenate((Sp, -Sp), axis=0)
        return S, delta, np.ones(len(S)) * W / (2 * m)

    def subspace_dim_reduction_kclustering(self, dataset: np.ndarray, eps: float = 0.1, alpha: float = 1):
        assert dataset.ndim == 2 and 0 < eps <= 1 / 3 and alpha >= 1
        m = self.k * (self.j + 1) + math.ceil(72 * self.k * (self.j + 1) / eps ** 2) - 1
        n, d = dataset.shape
        if d <= m or n <= m:
            return dataset
        (u, s, vh) = scipy.linalg.svd(dataset)
        vhr = vh[:m, :]
        sr = s[:m]
        C = np.diag(sr) @ vhr

        return C

    def streaming_kmeans(self, data: np.ndarray, eps: float = 1 / 3, delta: float = 0.05):
        return 0